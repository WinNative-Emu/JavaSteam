package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ApproveFeatureAccess_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ApproveFeatureAccess_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ApprovePlaytime_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ApprovePlaytime_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_DisableParentalSettings_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_DisableParentalSettings_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_EnableParentalSettings_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_EnableParentalSettings_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_GetParentalSettings_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_GetParentalSettings_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_GetRequests_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_GetRequests_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_GetSignedParentalSettings_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_GetSignedParentalSettings_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_LockClient_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_LockClient_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ReportPlaytimeAndNotify_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ReportPlaytimeAndNotify_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_RequestFeatureAccess_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_RequestFeatureAccess_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_RequestPlaytime_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_RequestPlaytime_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_RequestRecoveryCode_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_RequestRecoveryCode_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_SetParentalSettings_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_SetParentalSettings_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ValidatePassword_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ValidatePassword_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ValidateToken_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ValidateToken_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class Parental : UnifiedService {
  override val serviceName: String
    get() = "Parental"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "EnableParentalSettings" -> postResponseMsg<CParental_EnableParentalSettings_Response.Builder>(
          CParental_EnableParentalSettings_Response::class.java,
          packetMsg
          )
      "DisableParentalSettings" -> postResponseMsg<CParental_DisableParentalSettings_Response.Builder>(
          CParental_DisableParentalSettings_Response::class.java,
          packetMsg
          )
      "GetParentalSettings" -> postResponseMsg<CParental_GetParentalSettings_Response.Builder>(
          CParental_GetParentalSettings_Response::class.java,
          packetMsg
          )
      "GetSignedParentalSettings" -> postResponseMsg<CParental_GetSignedParentalSettings_Response.Builder>(
          CParental_GetSignedParentalSettings_Response::class.java,
          packetMsg
          )
      "SetParentalSettings" -> postResponseMsg<CParental_SetParentalSettings_Response.Builder>(
          CParental_SetParentalSettings_Response::class.java,
          packetMsg
          )
      "ValidateToken" -> postResponseMsg<CParental_ValidateToken_Response.Builder>(
          CParental_ValidateToken_Response::class.java,
          packetMsg
          )
      "ValidatePassword" -> postResponseMsg<CParental_ValidatePassword_Response.Builder>(
          CParental_ValidatePassword_Response::class.java,
          packetMsg
          )
      "LockClient" -> postResponseMsg<CParental_LockClient_Response.Builder>(
          CParental_LockClient_Response::class.java,
          packetMsg
          )
      "RequestRecoveryCode" -> postResponseMsg<CParental_RequestRecoveryCode_Response.Builder>(
          CParental_RequestRecoveryCode_Response::class.java,
          packetMsg
          )
      "RequestFeatureAccess" -> postResponseMsg<CParental_RequestFeatureAccess_Response.Builder>(
          CParental_RequestFeatureAccess_Response::class.java,
          packetMsg
          )
      "ApproveFeatureAccess" -> postResponseMsg<CParental_ApproveFeatureAccess_Response.Builder>(
          CParental_ApproveFeatureAccess_Response::class.java,
          packetMsg
          )
      "RequestPlaytime" -> postResponseMsg<CParental_RequestPlaytime_Response.Builder>(
          CParental_RequestPlaytime_Response::class.java,
          packetMsg
          )
      "ApprovePlaytime" -> postResponseMsg<CParental_ApprovePlaytime_Response.Builder>(
          CParental_ApprovePlaytime_Response::class.java,
          packetMsg
          )
      "GetRequests" -> postResponseMsg<CParental_GetRequests_Response.Builder>(
          CParental_GetRequests_Response::class.java,
          packetMsg
          )
      "ReportPlaytimeAndNotify" -> postResponseMsg<CParental_ReportPlaytimeAndNotify_Response.Builder>(
          CParental_ReportPlaytimeAndNotify_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CParental_EnableParentalSettings_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_EnableParentalSettings_Response]>>
   */
  public fun enableParentalSettings(request: CParental_EnableParentalSettings_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_EnableParentalSettings_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_EnableParentalSettings_Response.Builder::class.java,
  "Parental.EnableParentalSettings#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_DisableParentalSettings_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_DisableParentalSettings_Response]>>
   */
  public fun disableParentalSettings(request: CParental_DisableParentalSettings_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_DisableParentalSettings_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_DisableParentalSettings_Response.Builder::class.java,
  "Parental.DisableParentalSettings#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_GetParentalSettings_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_GetParentalSettings_Response]>>
   */
  public fun getParentalSettings(request: CParental_GetParentalSettings_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_GetParentalSettings_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_GetParentalSettings_Response.Builder::class.java,
  "Parental.GetParentalSettings#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_GetSignedParentalSettings_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_GetSignedParentalSettings_Response]>>
   */
  public fun getSignedParentalSettings(request: CParental_GetSignedParentalSettings_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_GetSignedParentalSettings_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_GetSignedParentalSettings_Response.Builder::class.java,
  "Parental.GetSignedParentalSettings#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_SetParentalSettings_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_SetParentalSettings_Response]>>
   */
  public fun setParentalSettings(request: CParental_SetParentalSettings_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_SetParentalSettings_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_SetParentalSettings_Response.Builder::class.java,
  "Parental.SetParentalSettings#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_ValidateToken_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_ValidateToken_Response]>>
   */
  public fun validateToken(request: CParental_ValidateToken_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_ValidateToken_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_ValidateToken_Response.Builder::class.java,
  "Parental.ValidateToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_ValidatePassword_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_ValidatePassword_Response]>>
   */
  public fun validatePassword(request: CParental_ValidatePassword_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_ValidatePassword_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_ValidatePassword_Response.Builder::class.java,
  "Parental.ValidatePassword#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_LockClient_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_LockClient_Response]>>
   */
  public fun lockClient(request: CParental_LockClient_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_LockClient_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_LockClient_Response.Builder::class.java,
  "Parental.LockClient#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_RequestRecoveryCode_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_RequestRecoveryCode_Response]>>
   */
  public fun requestRecoveryCode(request: CParental_RequestRecoveryCode_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_RequestRecoveryCode_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_RequestRecoveryCode_Response.Builder::class.java,
  "Parental.RequestRecoveryCode#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_RequestFeatureAccess_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_RequestFeatureAccess_Response]>>
   */
  public fun requestFeatureAccess(request: CParental_RequestFeatureAccess_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_RequestFeatureAccess_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_RequestFeatureAccess_Response.Builder::class.java,
  "Parental.RequestFeatureAccess#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_ApproveFeatureAccess_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_ApproveFeatureAccess_Response]>>
   */
  public fun approveFeatureAccess(request: CParental_ApproveFeatureAccess_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_ApproveFeatureAccess_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_ApproveFeatureAccess_Response.Builder::class.java,
  "Parental.ApproveFeatureAccess#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_RequestPlaytime_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_RequestPlaytime_Response]>>
   */
  public fun requestPlaytime(request: CParental_RequestPlaytime_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_RequestPlaytime_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_RequestPlaytime_Response.Builder::class.java,
  "Parental.RequestPlaytime#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_ApprovePlaytime_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_ApprovePlaytime_Response]>>
   */
  public fun approvePlaytime(request: CParental_ApprovePlaytime_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_ApprovePlaytime_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_ApprovePlaytime_Response.Builder::class.java,
  "Parental.ApprovePlaytime#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_GetRequests_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_GetRequests_Response]>>
   */
  public fun getRequests(request: CParental_GetRequests_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_GetRequests_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_GetRequests_Response.Builder::class.java,
  "Parental.GetRequests#1",
  request
  )

  /**
   * @param request The request.
   * @see [CParental_ReportPlaytimeAndNotify_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CParental_ReportPlaytimeAndNotify_Response]>>
   */
  public fun reportPlaytimeAndNotify(request: CParental_ReportPlaytimeAndNotify_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesParentalSteamclient.CParental_ReportPlaytimeAndNotify_Response.Builder>> = unifiedMessages!!.sendMessage(
  CParental_ReportPlaytimeAndNotify_Response.Builder::class.java,
  "Parental.ReportPlaytimeAndNotify#1",
  request
  )
}
