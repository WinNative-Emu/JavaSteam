package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_CancelFamilyGroupInvite_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_CancelFamilyGroupInvite_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ClearCooldownSkip_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ClearCooldownSkip_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ConfirmInviteToFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ConfirmInviteToFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ConfirmJoinFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ConfirmJoinFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_CreateFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_CreateFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_DeleteFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_DeleteFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ForceAcceptInvite_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ForceAcceptInvite_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetChangeLog_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetChangeLog_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetFamilyGroupForUser_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetFamilyGroupForUser_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetInviteCheckResults_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetInviteCheckResults_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPlaytimeSummary_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPlaytimeSummary_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPreferredLenders_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPreferredLenders_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPurchaseRequests_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPurchaseRequests_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetSharedLibraryApps_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetSharedLibraryApps_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetUsersSharingDevice_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetUsersSharingDevice_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_InviteToFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_InviteToFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_JoinFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_JoinFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ModifyFamilyGroupDetails_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ModifyFamilyGroupDetails_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RemoveFromFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RemoveFromFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RequestPurchase_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RequestPurchase_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ResendInvitationToFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_ResendInvitationToFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RespondToRequestedPurchase_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RespondToRequestedPurchase_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RollbackFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_RollbackFamilyGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_SetFamilyCooldownOverrides_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_SetFamilyCooldownOverrides_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_SetPreferredLender_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_SetPreferredLender_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_UndeleteFamilyGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroups_UndeleteFamilyGroup_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class FamilyGroups : UnifiedService {
  override val serviceName: String
    get() = "FamilyGroups"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "CreateFamilyGroup" -> postResponseMsg<CFamilyGroups_CreateFamilyGroup_Response.Builder>(
          CFamilyGroups_CreateFamilyGroup_Response::class.java,
          packetMsg
          )
      "GetFamilyGroup" -> postResponseMsg<CFamilyGroups_GetFamilyGroup_Response.Builder>(
          CFamilyGroups_GetFamilyGroup_Response::class.java,
          packetMsg
          )
      "GetFamilyGroupForUser" -> postResponseMsg<CFamilyGroups_GetFamilyGroupForUser_Response.Builder>(
          CFamilyGroups_GetFamilyGroupForUser_Response::class.java,
          packetMsg
          )
      "ModifyFamilyGroupDetails" -> postResponseMsg<CFamilyGroups_ModifyFamilyGroupDetails_Response.Builder>(
          CFamilyGroups_ModifyFamilyGroupDetails_Response::class.java,
          packetMsg
          )
      "InviteToFamilyGroup" -> postResponseMsg<CFamilyGroups_InviteToFamilyGroup_Response.Builder>(
          CFamilyGroups_InviteToFamilyGroup_Response::class.java,
          packetMsg
          )
      "ConfirmInviteToFamilyGroup" -> postResponseMsg<CFamilyGroups_ConfirmInviteToFamilyGroup_Response.Builder>(
          CFamilyGroups_ConfirmInviteToFamilyGroup_Response::class.java,
          packetMsg
          )
      "ResendInvitationToFamilyGroup" -> postResponseMsg<CFamilyGroups_ResendInvitationToFamilyGroup_Response.Builder>(
          CFamilyGroups_ResendInvitationToFamilyGroup_Response::class.java,
          packetMsg
          )
      "JoinFamilyGroup" -> postResponseMsg<CFamilyGroups_JoinFamilyGroup_Response.Builder>(
          CFamilyGroups_JoinFamilyGroup_Response::class.java,
          packetMsg
          )
      "ConfirmJoinFamilyGroup" -> postResponseMsg<CFamilyGroups_ConfirmJoinFamilyGroup_Response.Builder>(
          CFamilyGroups_ConfirmJoinFamilyGroup_Response::class.java,
          packetMsg
          )
      "RemoveFromFamilyGroup" -> postResponseMsg<CFamilyGroups_RemoveFromFamilyGroup_Response.Builder>(
          CFamilyGroups_RemoveFromFamilyGroup_Response::class.java,
          packetMsg
          )
      "CancelFamilyGroupInvite" -> postResponseMsg<CFamilyGroups_CancelFamilyGroupInvite_Response.Builder>(
          CFamilyGroups_CancelFamilyGroupInvite_Response::class.java,
          packetMsg
          )
      "GetUsersSharingDevice" -> postResponseMsg<CFamilyGroups_GetUsersSharingDevice_Response.Builder>(
          CFamilyGroups_GetUsersSharingDevice_Response::class.java,
          packetMsg
          )
      "DeleteFamilyGroup" -> postResponseMsg<CFamilyGroups_DeleteFamilyGroup_Response.Builder>(
          CFamilyGroups_DeleteFamilyGroup_Response::class.java,
          packetMsg
          )
      "UndeleteFamilyGroup" -> postResponseMsg<CFamilyGroups_UndeleteFamilyGroup_Response.Builder>(
          CFamilyGroups_UndeleteFamilyGroup_Response::class.java,
          packetMsg
          )
      "GetPlaytimeSummary" -> postResponseMsg<CFamilyGroups_GetPlaytimeSummary_Response.Builder>(
          CFamilyGroups_GetPlaytimeSummary_Response::class.java,
          packetMsg
          )
      "RequestPurchase" -> postResponseMsg<CFamilyGroups_RequestPurchase_Response.Builder>(
          CFamilyGroups_RequestPurchase_Response::class.java,
          packetMsg
          )
      "GetPurchaseRequests" -> postResponseMsg<CFamilyGroups_GetPurchaseRequests_Response.Builder>(
          CFamilyGroups_GetPurchaseRequests_Response::class.java,
          packetMsg
          )
      "RespondToRequestedPurchase" -> postResponseMsg<CFamilyGroups_RespondToRequestedPurchase_Response.Builder>(
          CFamilyGroups_RespondToRequestedPurchase_Response::class.java,
          packetMsg
          )
      "GetChangeLog" -> postResponseMsg<CFamilyGroups_GetChangeLog_Response.Builder>(
          CFamilyGroups_GetChangeLog_Response::class.java,
          packetMsg
          )
      "SetFamilyCooldownOverrides" -> postResponseMsg<CFamilyGroups_SetFamilyCooldownOverrides_Response.Builder>(
          CFamilyGroups_SetFamilyCooldownOverrides_Response::class.java,
          packetMsg
          )
      "GetSharedLibraryApps" -> postResponseMsg<CFamilyGroups_GetSharedLibraryApps_Response.Builder>(
          CFamilyGroups_GetSharedLibraryApps_Response::class.java,
          packetMsg
          )
      "SetPreferredLender" -> postResponseMsg<CFamilyGroups_SetPreferredLender_Response.Builder>(
          CFamilyGroups_SetPreferredLender_Response::class.java,
          packetMsg
          )
      "GetPreferredLenders" -> postResponseMsg<CFamilyGroups_GetPreferredLenders_Response.Builder>(
          CFamilyGroups_GetPreferredLenders_Response::class.java,
          packetMsg
          )
      "ForceAcceptInvite" -> postResponseMsg<CFamilyGroups_ForceAcceptInvite_Response.Builder>(
          CFamilyGroups_ForceAcceptInvite_Response::class.java,
          packetMsg
          )
      "GetInviteCheckResults" -> postResponseMsg<CFamilyGroups_GetInviteCheckResults_Response.Builder>(
          CFamilyGroups_GetInviteCheckResults_Response::class.java,
          packetMsg
          )
      "ClearCooldownSkip" -> postResponseMsg<CFamilyGroups_ClearCooldownSkip_Response.Builder>(
          CFamilyGroups_ClearCooldownSkip_Response::class.java,
          packetMsg
          )
      "RollbackFamilyGroup" -> postResponseMsg<CFamilyGroups_RollbackFamilyGroup_Response.Builder>(
          CFamilyGroups_RollbackFamilyGroup_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CFamilyGroups_CreateFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_CreateFamilyGroup_Response]>>
   */
  public fun createFamilyGroup(request: CFamilyGroups_CreateFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_CreateFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_CreateFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.CreateFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetFamilyGroup_Response]>>
   */
  public fun getFamilyGroup(request: CFamilyGroups_GetFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.GetFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetFamilyGroupForUser_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetFamilyGroupForUser_Response]>>
   */
  public fun getFamilyGroupForUser(request: CFamilyGroups_GetFamilyGroupForUser_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetFamilyGroupForUser_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetFamilyGroupForUser_Response.Builder::class.java,
  "FamilyGroups.GetFamilyGroupForUser#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_ModifyFamilyGroupDetails_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_ModifyFamilyGroupDetails_Response]>>
   */
  public fun modifyFamilyGroupDetails(request: CFamilyGroups_ModifyFamilyGroupDetails_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_ModifyFamilyGroupDetails_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_ModifyFamilyGroupDetails_Response.Builder::class.java,
  "FamilyGroups.ModifyFamilyGroupDetails#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_InviteToFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_InviteToFamilyGroup_Response]>>
   */
  public fun inviteToFamilyGroup(request: CFamilyGroups_InviteToFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_InviteToFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_InviteToFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.InviteToFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_ConfirmInviteToFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_ConfirmInviteToFamilyGroup_Response]>>
   */
  public fun confirmInviteToFamilyGroup(request: CFamilyGroups_ConfirmInviteToFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_ConfirmInviteToFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_ConfirmInviteToFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.ConfirmInviteToFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_ResendInvitationToFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_ResendInvitationToFamilyGroup_Response]>>
   */
  public fun resendInvitationToFamilyGroup(request: CFamilyGroups_ResendInvitationToFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_ResendInvitationToFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_ResendInvitationToFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.ResendInvitationToFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_JoinFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_JoinFamilyGroup_Response]>>
   */
  public fun joinFamilyGroup(request: CFamilyGroups_JoinFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_JoinFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_JoinFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.JoinFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_ConfirmJoinFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_ConfirmJoinFamilyGroup_Response]>>
   */
  public fun confirmJoinFamilyGroup(request: CFamilyGroups_ConfirmJoinFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_ConfirmJoinFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_ConfirmJoinFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.ConfirmJoinFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_RemoveFromFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_RemoveFromFamilyGroup_Response]>>
   */
  public fun removeFromFamilyGroup(request: CFamilyGroups_RemoveFromFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_RemoveFromFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_RemoveFromFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.RemoveFromFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_CancelFamilyGroupInvite_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_CancelFamilyGroupInvite_Response]>>
   */
  public fun cancelFamilyGroupInvite(request: CFamilyGroups_CancelFamilyGroupInvite_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_CancelFamilyGroupInvite_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_CancelFamilyGroupInvite_Response.Builder::class.java,
  "FamilyGroups.CancelFamilyGroupInvite#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetUsersSharingDevice_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetUsersSharingDevice_Response]>>
   */
  public fun getUsersSharingDevice(request: CFamilyGroups_GetUsersSharingDevice_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetUsersSharingDevice_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetUsersSharingDevice_Response.Builder::class.java,
  "FamilyGroups.GetUsersSharingDevice#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_DeleteFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_DeleteFamilyGroup_Response]>>
   */
  public fun deleteFamilyGroup(request: CFamilyGroups_DeleteFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_DeleteFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_DeleteFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.DeleteFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_UndeleteFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_UndeleteFamilyGroup_Response]>>
   */
  public fun undeleteFamilyGroup(request: CFamilyGroups_UndeleteFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_UndeleteFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_UndeleteFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.UndeleteFamilyGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetPlaytimeSummary_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetPlaytimeSummary_Response]>>
   */
  public fun getPlaytimeSummary(request: CFamilyGroups_GetPlaytimeSummary_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPlaytimeSummary_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetPlaytimeSummary_Response.Builder::class.java,
  "FamilyGroups.GetPlaytimeSummary#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_RequestPurchase_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_RequestPurchase_Response]>>
   */
  public fun requestPurchase(request: CFamilyGroups_RequestPurchase_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_RequestPurchase_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_RequestPurchase_Response.Builder::class.java,
  "FamilyGroups.RequestPurchase#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetPurchaseRequests_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetPurchaseRequests_Response]>>
   */
  public fun getPurchaseRequests(request: CFamilyGroups_GetPurchaseRequests_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPurchaseRequests_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetPurchaseRequests_Response.Builder::class.java,
  "FamilyGroups.GetPurchaseRequests#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_RespondToRequestedPurchase_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_RespondToRequestedPurchase_Response]>>
   */
  public fun respondToRequestedPurchase(request: CFamilyGroups_RespondToRequestedPurchase_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_RespondToRequestedPurchase_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_RespondToRequestedPurchase_Response.Builder::class.java,
  "FamilyGroups.RespondToRequestedPurchase#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetChangeLog_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetChangeLog_Response]>>
   */
  public fun getChangeLog(request: CFamilyGroups_GetChangeLog_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetChangeLog_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetChangeLog_Response.Builder::class.java,
  "FamilyGroups.GetChangeLog#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_SetFamilyCooldownOverrides_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_SetFamilyCooldownOverrides_Response]>>
   */
  public fun setFamilyCooldownOverrides(request: CFamilyGroups_SetFamilyCooldownOverrides_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_SetFamilyCooldownOverrides_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_SetFamilyCooldownOverrides_Response.Builder::class.java,
  "FamilyGroups.SetFamilyCooldownOverrides#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetSharedLibraryApps_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetSharedLibraryApps_Response]>>
   */
  public fun getSharedLibraryApps(request: CFamilyGroups_GetSharedLibraryApps_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetSharedLibraryApps_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetSharedLibraryApps_Response.Builder::class.java,
  "FamilyGroups.GetSharedLibraryApps#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_SetPreferredLender_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_SetPreferredLender_Response]>>
   */
  public fun setPreferredLender(request: CFamilyGroups_SetPreferredLender_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_SetPreferredLender_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_SetPreferredLender_Response.Builder::class.java,
  "FamilyGroups.SetPreferredLender#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetPreferredLenders_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetPreferredLenders_Response]>>
   */
  public fun getPreferredLenders(request: CFamilyGroups_GetPreferredLenders_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetPreferredLenders_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetPreferredLenders_Response.Builder::class.java,
  "FamilyGroups.GetPreferredLenders#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_ForceAcceptInvite_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_ForceAcceptInvite_Response]>>
   */
  public fun forceAcceptInvite(request: CFamilyGroups_ForceAcceptInvite_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_ForceAcceptInvite_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_ForceAcceptInvite_Response.Builder::class.java,
  "FamilyGroups.ForceAcceptInvite#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_GetInviteCheckResults_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_GetInviteCheckResults_Response]>>
   */
  public fun getInviteCheckResults(request: CFamilyGroups_GetInviteCheckResults_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_GetInviteCheckResults_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_GetInviteCheckResults_Response.Builder::class.java,
  "FamilyGroups.GetInviteCheckResults#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_ClearCooldownSkip_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_ClearCooldownSkip_Response]>>
   */
  public fun clearCooldownSkip(request: CFamilyGroups_ClearCooldownSkip_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_ClearCooldownSkip_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_ClearCooldownSkip_Response.Builder::class.java,
  "FamilyGroups.ClearCooldownSkip#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFamilyGroups_RollbackFamilyGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFamilyGroups_RollbackFamilyGroup_Response]>>
   */
  public fun rollbackFamilyGroup(request: CFamilyGroups_RollbackFamilyGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFamilygroupsSteamclient.CFamilyGroups_RollbackFamilyGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFamilyGroups_RollbackFamilyGroup_Response.Builder::class.java,
  "FamilyGroups.RollbackFamilyGroup#1",
  request
  )
}
