package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesRemoteclientServiceMessages.CRemoteClient_RegisterStatusUpdate_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesRemoteclientServiceMessages.CRemoteClient_RemotePacket_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesRemoteclientServiceMessages.CRemoteClient_SteamBroadcast_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesRemoteclientServiceMessages.CRemoteClient_SteamToSteam_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesRemoteclientServiceMessages.CRemoteClient_TaskList_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesRemoteclientServiceMessages.CRemoteClient_UnregisterStatusUpdate_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesRemoteclientServiceMessages.CRemotePlayTogether_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class RemoteClientSteamClient : UnifiedService {
  override val serviceName: String
    get() = "RemoteClientSteamClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyRegisterStatusUpdate" -> postNotificationMsg<CRemoteClient_RegisterStatusUpdate_Notification.Builder>(
          CRemoteClient_RegisterStatusUpdate_Notification::class.java,
          packetMsg
          )
      "NotifyUnregisterStatusUpdate" -> postNotificationMsg<CRemoteClient_UnregisterStatusUpdate_Notification.Builder>(
          CRemoteClient_UnregisterStatusUpdate_Notification::class.java,
          packetMsg
          )
      "NotifyRemotePacket" -> postNotificationMsg<CRemoteClient_RemotePacket_Notification.Builder>(
          CRemoteClient_RemotePacket_Notification::class.java,
          packetMsg
          )
      "NotifySteamBroadcastPacket" -> postNotificationMsg<CRemoteClient_SteamBroadcast_Notification.Builder>(
          CRemoteClient_SteamBroadcast_Notification::class.java,
          packetMsg
          )
      "NotifySteamToSteamPacket" -> postNotificationMsg<CRemoteClient_SteamToSteam_Notification.Builder>(
          CRemoteClient_SteamToSteam_Notification::class.java,
          packetMsg
          )
      "NotifyRemotePlayTogetherPacket" -> postNotificationMsg<CRemotePlayTogether_Notification.Builder>(
          CRemotePlayTogether_Notification::class.java,
          packetMsg
          )
      "NotifyTaskList" -> postNotificationMsg<CRemoteClient_TaskList_Notification.Builder>(
          CRemoteClient_TaskList_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CRemoteClient_RegisterStatusUpdate_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyRegisterStatusUpdate(request: CRemoteClient_RegisterStatusUpdate_Notification) {
    unifiedMessages!!.sendNotification<CRemoteClient_RegisterStatusUpdate_Notification.Builder>(
        "RemoteClientSteamClient.NotifyRegisterStatusUpdate#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CRemoteClient_UnregisterStatusUpdate_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyUnregisterStatusUpdate(request: CRemoteClient_UnregisterStatusUpdate_Notification) {
    unifiedMessages!!.sendNotification<CRemoteClient_UnregisterStatusUpdate_Notification.Builder>(
        "RemoteClientSteamClient.NotifyUnregisterStatusUpdate#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CRemoteClient_RemotePacket_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyRemotePacket(request: CRemoteClient_RemotePacket_Notification) {
    unifiedMessages!!.sendNotification<CRemoteClient_RemotePacket_Notification.Builder>(
        "RemoteClientSteamClient.NotifyRemotePacket#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CRemoteClient_SteamBroadcast_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifySteamBroadcastPacket(request: CRemoteClient_SteamBroadcast_Notification) {
    unifiedMessages!!.sendNotification<CRemoteClient_SteamBroadcast_Notification.Builder>(
        "RemoteClientSteamClient.NotifySteamBroadcastPacket#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CRemoteClient_SteamToSteam_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifySteamToSteamPacket(request: CRemoteClient_SteamToSteam_Notification) {
    unifiedMessages!!.sendNotification<CRemoteClient_SteamToSteam_Notification.Builder>(
        "RemoteClientSteamClient.NotifySteamToSteamPacket#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CRemotePlayTogether_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyRemotePlayTogetherPacket(request: CRemotePlayTogether_Notification) {
    unifiedMessages!!.sendNotification<CRemotePlayTogether_Notification.Builder>(
        "RemoteClientSteamClient.NotifyRemotePlayTogetherPacket#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CRemoteClient_TaskList_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyTaskList(request: CRemoteClient_TaskList_Notification) {
    unifiedMessages!!.sendNotification<CRemoteClient_TaskList_Notification.Builder>(
        "RemoteClientSteamClient.NotifyTaskList#1",
        request
        )
  }
}
