package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_OnNotificationsRequested_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_OnUserStatusChanged_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class GameNotificationsClient : UnifiedService {
  override val serviceName: String
    get() = "GameNotificationsClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "OnNotificationsRequested" -> postNotificationMsg<CGameNotifications_OnNotificationsRequested_Notification.Builder>(
          CGameNotifications_OnNotificationsRequested_Notification::class.java,
          packetMsg
          )
      "OnUserStatusChanged" -> postNotificationMsg<CGameNotifications_OnUserStatusChanged_Notification.Builder>(
          CGameNotifications_OnUserStatusChanged_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CGameNotifications_OnNotificationsRequested_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun onNotificationsRequested(request: CGameNotifications_OnNotificationsRequested_Notification) {
    unifiedMessages!!.sendNotification<CGameNotifications_OnNotificationsRequested_Notification.Builder>(
        "GameNotificationsClient.OnNotificationsRequested#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CGameNotifications_OnUserStatusChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun onUserStatusChanged(request: CGameNotifications_OnUserStatusChanged_Notification) {
    unifiedMessages!!.sendNotification<CGameNotifications_OnUserStatusChanged_Notification.Builder>(
        "GameNotificationsClient.OnUserStatusChanged#1",
        request
        )
  }
}
