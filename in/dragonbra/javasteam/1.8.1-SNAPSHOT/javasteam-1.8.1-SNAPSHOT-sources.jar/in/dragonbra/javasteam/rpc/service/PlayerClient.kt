package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_CommunityPreferencesChanged_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_FriendEquippedProfileItemsChanged_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_FriendNicknameChanged_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_LastPlayedTimes_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_NewSteamAnnouncementState_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_PerFriendPreferencesChanged_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_PrivacySettingsChanged_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_TextFilterWordsChanged_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class PlayerClient : UnifiedService {
  override val serviceName: String
    get() = "PlayerClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyLastPlayedTimes" -> postNotificationMsg<CPlayer_LastPlayedTimes_Notification.Builder>(
          CPlayer_LastPlayedTimes_Notification::class.java,
          packetMsg
          )
      "NotifyFriendNicknameChanged" -> postNotificationMsg<CPlayer_FriendNicknameChanged_Notification.Builder>(
          CPlayer_FriendNicknameChanged_Notification::class.java,
          packetMsg
          )
      "NotifyFriendEquippedProfileItemsChanged" -> postNotificationMsg<CPlayer_FriendEquippedProfileItemsChanged_Notification.Builder>(
          CPlayer_FriendEquippedProfileItemsChanged_Notification::class.java,
          packetMsg
          )
      "NotifyNewSteamAnnouncementState" -> postNotificationMsg<CPlayer_NewSteamAnnouncementState_Notification.Builder>(
          CPlayer_NewSteamAnnouncementState_Notification::class.java,
          packetMsg
          )
      "NotifyCommunityPreferencesChanged" -> postNotificationMsg<CPlayer_CommunityPreferencesChanged_Notification.Builder>(
          CPlayer_CommunityPreferencesChanged_Notification::class.java,
          packetMsg
          )
      "NotifyTextFilterWordsChanged" -> postNotificationMsg<CPlayer_TextFilterWordsChanged_Notification.Builder>(
          CPlayer_TextFilterWordsChanged_Notification::class.java,
          packetMsg
          )
      "NotifyPerFriendPreferencesChanged" -> postNotificationMsg<CPlayer_PerFriendPreferencesChanged_Notification.Builder>(
          CPlayer_PerFriendPreferencesChanged_Notification::class.java,
          packetMsg
          )
      "NotifyPrivacyPrivacySettingsChanged" -> postNotificationMsg<CPlayer_PrivacySettingsChanged_Notification.Builder>(
          CPlayer_PrivacySettingsChanged_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CPlayer_LastPlayedTimes_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyLastPlayedTimes(request: CPlayer_LastPlayedTimes_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_LastPlayedTimes_Notification.Builder>(
        "PlayerClient.NotifyLastPlayedTimes#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPlayer_FriendNicknameChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyFriendNicknameChanged(request: CPlayer_FriendNicknameChanged_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_FriendNicknameChanged_Notification.Builder>(
        "PlayerClient.NotifyFriendNicknameChanged#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPlayer_FriendEquippedProfileItemsChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyFriendEquippedProfileItemsChanged(request: CPlayer_FriendEquippedProfileItemsChanged_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_FriendEquippedProfileItemsChanged_Notification.Builder>(
        "PlayerClient.NotifyFriendEquippedProfileItemsChanged#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPlayer_NewSteamAnnouncementState_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyNewSteamAnnouncementState(request: CPlayer_NewSteamAnnouncementState_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_NewSteamAnnouncementState_Notification.Builder>(
        "PlayerClient.NotifyNewSteamAnnouncementState#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPlayer_CommunityPreferencesChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyCommunityPreferencesChanged(request: CPlayer_CommunityPreferencesChanged_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_CommunityPreferencesChanged_Notification.Builder>(
        "PlayerClient.NotifyCommunityPreferencesChanged#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPlayer_TextFilterWordsChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyTextFilterWordsChanged(request: CPlayer_TextFilterWordsChanged_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_TextFilterWordsChanged_Notification.Builder>(
        "PlayerClient.NotifyTextFilterWordsChanged#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPlayer_PerFriendPreferencesChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyPerFriendPreferencesChanged(request: CPlayer_PerFriendPreferencesChanged_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_PerFriendPreferencesChanged_Notification.Builder>(
        "PlayerClient.NotifyPerFriendPreferencesChanged#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPlayer_PrivacySettingsChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyPrivacyPrivacySettingsChanged(request: CPlayer_PrivacySettingsChanged_Notification) {
    unifiedMessages!!.sendNotification<CPlayer_PrivacySettingsChanged_Notification.Builder>(
        "PlayerClient.NotifyPrivacyPrivacySettingsChanged#1",
        request
        )
  }
}
