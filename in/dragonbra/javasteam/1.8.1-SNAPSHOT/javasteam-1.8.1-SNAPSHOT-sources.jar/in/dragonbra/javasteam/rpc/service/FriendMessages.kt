package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_AckMessage_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_DismissSessionNotice_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_GetRecentMessages_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_GetRecentMessages_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_IsInFriendsUIBeta_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_IsInFriendsUIBeta_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_ReportMessage_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_ReportMessage_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_ResolveReport_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_ResolveReport_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_SendMessage_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_SendMessage_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_UpdateMessageReaction_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_UpdateMessageReaction_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendsMessages_GetActiveMessageSessions_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendsMessages_GetActiveMessageSessions_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class FriendMessages : UnifiedService {
  override val serviceName: String
    get() = "FriendMessages"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetRecentMessages" -> postResponseMsg<CFriendMessages_GetRecentMessages_Response.Builder>(
          CFriendMessages_GetRecentMessages_Response::class.java,
          packetMsg
          )
      "GetActiveMessageSessions" -> postResponseMsg<CFriendsMessages_GetActiveMessageSessions_Response.Builder>(
          CFriendsMessages_GetActiveMessageSessions_Response::class.java,
          packetMsg
          )
      "SendMessage" -> postResponseMsg<CFriendMessages_SendMessage_Response.Builder>(
          CFriendMessages_SendMessage_Response::class.java,
          packetMsg
          )
      "IsInFriendsUIBeta" -> postResponseMsg<CFriendMessages_IsInFriendsUIBeta_Response.Builder>(
          CFriendMessages_IsInFriendsUIBeta_Response::class.java,
          packetMsg
          )
      "UpdateMessageReaction" -> postResponseMsg<CFriendMessages_UpdateMessageReaction_Response.Builder>(
          CFriendMessages_UpdateMessageReaction_Response::class.java,
          packetMsg
          )
      "ReportMessage" -> postResponseMsg<CFriendMessages_ReportMessage_Response.Builder>(
          CFriendMessages_ReportMessage_Response::class.java,
          packetMsg
          )
      "ResolveReport" -> postResponseMsg<CFriendMessages_ResolveReport_Response.Builder>(
          CFriendMessages_ResolveReport_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "AckMessage" -> postNotificationMsg<CFriendMessages_AckMessage_Notification.Builder>(
          CFriendMessages_AckMessage_Notification::class.java,
          packetMsg
          )
      "DismissSessionNotice" -> postNotificationMsg<CFriendMessages_DismissSessionNotice_Notification.Builder>(
          CFriendMessages_DismissSessionNotice_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CFriendMessages_GetRecentMessages_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFriendMessages_GetRecentMessages_Response]>>
   */
  public fun getRecentMessages(request: CFriendMessages_GetRecentMessages_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFriendmessagesSteamclient.CFriendMessages_GetRecentMessages_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFriendMessages_GetRecentMessages_Response.Builder::class.java,
  "FriendMessages.GetRecentMessages#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFriendsMessages_GetActiveMessageSessions_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFriendsMessages_GetActiveMessageSessions_Response]>>
   */
  public fun getActiveMessageSessions(request: CFriendsMessages_GetActiveMessageSessions_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFriendmessagesSteamclient.CFriendsMessages_GetActiveMessageSessions_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFriendsMessages_GetActiveMessageSessions_Response.Builder::class.java,
  "FriendMessages.GetActiveMessageSessions#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFriendMessages_SendMessage_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFriendMessages_SendMessage_Response]>>
   */
  public fun sendMessage(request: CFriendMessages_SendMessage_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFriendmessagesSteamclient.CFriendMessages_SendMessage_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFriendMessages_SendMessage_Response.Builder::class.java,
  "FriendMessages.SendMessage#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFriendMessages_AckMessage_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun ackMessage(request: CFriendMessages_AckMessage_Notification) {
    unifiedMessages!!.sendNotification<CFriendMessages_AckMessage_Notification.Builder>(
        "FriendMessages.AckMessage#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CFriendMessages_IsInFriendsUIBeta_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFriendMessages_IsInFriendsUIBeta_Response]>>
   */
  public fun isInFriendsUIBeta(request: CFriendMessages_IsInFriendsUIBeta_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFriendmessagesSteamclient.CFriendMessages_IsInFriendsUIBeta_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFriendMessages_IsInFriendsUIBeta_Response.Builder::class.java,
  "FriendMessages.IsInFriendsUIBeta#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFriendMessages_UpdateMessageReaction_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFriendMessages_UpdateMessageReaction_Response]>>
   */
  public fun updateMessageReaction(request: CFriendMessages_UpdateMessageReaction_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFriendmessagesSteamclient.CFriendMessages_UpdateMessageReaction_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFriendMessages_UpdateMessageReaction_Response.Builder::class.java,
  "FriendMessages.UpdateMessageReaction#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFriendMessages_ReportMessage_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFriendMessages_ReportMessage_Response]>>
   */
  public fun reportMessage(request: CFriendMessages_ReportMessage_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFriendmessagesSteamclient.CFriendMessages_ReportMessage_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFriendMessages_ReportMessage_Response.Builder::class.java,
  "FriendMessages.ReportMessage#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFriendMessages_ResolveReport_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CFriendMessages_ResolveReport_Response]>>
   */
  public fun resolveReport(request: CFriendMessages_ResolveReport_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesFriendmessagesSteamclient.CFriendMessages_ResolveReport_Response.Builder>> = unifiedMessages!!.sendMessage(
  CFriendMessages_ResolveReport_Response.Builder::class.java,
  "FriendMessages.ResolveReport#1",
  request
  )

  /**
   * @param request The request.
   * @see [CFriendMessages_DismissSessionNotice_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun dismissSessionNotice(request: CFriendMessages_DismissSessionNotice_Notification) {
    unifiedMessages!!.sendNotification<CFriendMessages_DismissSessionNotice_Notification.Builder>(
        "FriendMessages.DismissSessionNotice#1",
        request
        )
  }
}
