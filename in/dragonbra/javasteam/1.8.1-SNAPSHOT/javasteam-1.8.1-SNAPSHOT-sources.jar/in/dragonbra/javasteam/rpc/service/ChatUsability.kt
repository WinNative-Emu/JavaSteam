package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatUsability_ClientUsabilityMetrics_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ChatUsability : UnifiedService {
  override val serviceName: String
    get() = "ChatUsability"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyClientUsabilityMetrics" -> postNotificationMsg<CChatUsability_ClientUsabilityMetrics_Notification.Builder>(
          CChatUsability_ClientUsabilityMetrics_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CChatUsability_ClientUsabilityMetrics_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyClientUsabilityMetrics(request: CChatUsability_ClientUsabilityMetrics_Notification) {
    unifiedMessages!!.sendNotification<CChatUsability_ClientUsabilityMetrics_Notification.Builder>(
        "ChatUsability.NotifyClientUsabilityMetrics#1",
        request
        )
  }
}
