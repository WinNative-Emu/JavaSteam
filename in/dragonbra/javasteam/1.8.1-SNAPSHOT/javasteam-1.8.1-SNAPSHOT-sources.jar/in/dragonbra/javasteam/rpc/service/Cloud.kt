package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_AppExitSyncDone_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_AppLaunchIntent_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_AppLaunchIntent_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_AppSessionResume_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_AppSessionResume_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_AppSessionSuspend_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_AppSessionSuspend_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_BeginAppUploadBatch_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_BeginAppUploadBatch_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_BeginHTTPUpload_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_BeginHTTPUpload_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_BeginUGCUpload_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_BeginUGCUpload_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CDNReport_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientBeginFileUpload_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientBeginFileUpload_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientCommitFileUpload_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientCommitFileUpload_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientConflictResolution_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientDeleteFile_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientDeleteFile_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientFileDownload_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientFileDownload_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientGetAppQuotaUsage_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientGetAppQuotaUsage_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientLogUploadCheck_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ClientLogUploadComplete_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CommitHTTPUpload_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CommitHTTPUpload_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CommitUGCUpload_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CommitUGCUpload_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CompleteAppUploadBatch_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CompleteAppUploadBatch_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_CompleteAppUploadBatch_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_Delete_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_Delete_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_EnumerateUserFiles_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_EnumerateUserFiles_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ExternalStorageTransferReport_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetAppFileChangelist_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetAppFileChangelist_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetClientEncryptionKey_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetClientEncryptionKey_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetFileDetails_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetFileDetails_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetSingleFileInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_GetSingleFileInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ShareFile_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesCloudSteamclient.CCloud_ShareFile_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class Cloud : UnifiedService {
  override val serviceName: String
    get() = "Cloud"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "BeginHTTPUpload" -> postResponseMsg<CCloud_BeginHTTPUpload_Response.Builder>(
          CCloud_BeginHTTPUpload_Response::class.java,
          packetMsg
          )
      "CommitHTTPUpload" -> postResponseMsg<CCloud_CommitHTTPUpload_Response.Builder>(
          CCloud_CommitHTTPUpload_Response::class.java,
          packetMsg
          )
      "BeginUGCUpload" -> postResponseMsg<CCloud_BeginUGCUpload_Response.Builder>(
          CCloud_BeginUGCUpload_Response::class.java,
          packetMsg
          )
      "CommitUGCUpload" -> postResponseMsg<CCloud_CommitUGCUpload_Response.Builder>(
          CCloud_CommitUGCUpload_Response::class.java,
          packetMsg
          )
      "GetFileDetails" -> postResponseMsg<CCloud_GetFileDetails_Response.Builder>(
          CCloud_GetFileDetails_Response::class.java,
          packetMsg
          )
      "GetSingleFileInfo" -> postResponseMsg<CCloud_GetSingleFileInfo_Response.Builder>(
          CCloud_GetSingleFileInfo_Response::class.java,
          packetMsg
          )
      "ShareFile" -> postResponseMsg<CCloud_ShareFile_Response.Builder>(
          CCloud_ShareFile_Response::class.java,
          packetMsg
          )
      "EnumerateUserFiles" -> postResponseMsg<CCloud_EnumerateUserFiles_Response.Builder>(
          CCloud_EnumerateUserFiles_Response::class.java,
          packetMsg
          )
      "Delete" -> postResponseMsg<CCloud_Delete_Response.Builder>(
          CCloud_Delete_Response::class.java,
          packetMsg
          )
      "GetClientEncryptionKey" -> postResponseMsg<CCloud_GetClientEncryptionKey_Response.Builder>(
          CCloud_GetClientEncryptionKey_Response::class.java,
          packetMsg
          )
      "BeginAppUploadBatch" -> postResponseMsg<CCloud_BeginAppUploadBatch_Response.Builder>(
          CCloud_BeginAppUploadBatch_Response::class.java,
          packetMsg
          )
      "CompleteAppUploadBatchBlocking" -> postResponseMsg<CCloud_CompleteAppUploadBatch_Response.Builder>(
          CCloud_CompleteAppUploadBatch_Response::class.java,
          packetMsg
          )
      "ClientBeginFileUpload" -> postResponseMsg<CCloud_ClientBeginFileUpload_Response.Builder>(
          CCloud_ClientBeginFileUpload_Response::class.java,
          packetMsg
          )
      "ClientCommitFileUpload" -> postResponseMsg<CCloud_ClientCommitFileUpload_Response.Builder>(
          CCloud_ClientCommitFileUpload_Response::class.java,
          packetMsg
          )
      "ClientFileDownload" -> postResponseMsg<CCloud_ClientFileDownload_Response.Builder>(
          CCloud_ClientFileDownload_Response::class.java,
          packetMsg
          )
      "ClientDeleteFile" -> postResponseMsg<CCloud_ClientDeleteFile_Response.Builder>(
          CCloud_ClientDeleteFile_Response::class.java,
          packetMsg
          )
      "GetAppFileChangelist" -> postResponseMsg<CCloud_GetAppFileChangelist_Response.Builder>(
          CCloud_GetAppFileChangelist_Response::class.java,
          packetMsg
          )
      "SuspendAppSession" -> postResponseMsg<CCloud_AppSessionSuspend_Response.Builder>(
          CCloud_AppSessionSuspend_Response::class.java,
          packetMsg
          )
      "ResumeAppSession" -> postResponseMsg<CCloud_AppSessionResume_Response.Builder>(
          CCloud_AppSessionResume_Response::class.java,
          packetMsg
          )
      "SignalAppLaunchIntent" -> postResponseMsg<CCloud_AppLaunchIntent_Response.Builder>(
          CCloud_AppLaunchIntent_Response::class.java,
          packetMsg
          )
      "ClientGetAppQuotaUsage" -> postResponseMsg<CCloud_ClientGetAppQuotaUsage_Response.Builder>(
          CCloud_ClientGetAppQuotaUsage_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "ClientLogUploadCheck" -> postNotificationMsg<CCloud_ClientLogUploadCheck_Notification.Builder>(
          CCloud_ClientLogUploadCheck_Notification::class.java,
          packetMsg
          )
      "ClientLogUploadComplete" -> postNotificationMsg<CCloud_ClientLogUploadComplete_Notification.Builder>(
          CCloud_ClientLogUploadComplete_Notification::class.java,
          packetMsg
          )
      "CDNReport" -> postNotificationMsg<CCloud_CDNReport_Notification.Builder>(
          CCloud_CDNReport_Notification::class.java,
          packetMsg
          )
      "ExternalStorageTransferReport" -> postNotificationMsg<CCloud_ExternalStorageTransferReport_Notification.Builder>(
          CCloud_ExternalStorageTransferReport_Notification::class.java,
          packetMsg
          )
      "CompleteAppUploadBatch" -> postNotificationMsg<CCloud_CompleteAppUploadBatch_Notification.Builder>(
          CCloud_CompleteAppUploadBatch_Notification::class.java,
          packetMsg
          )
      "ClientConflictResolution" -> postNotificationMsg<CCloud_ClientConflictResolution_Notification.Builder>(
          CCloud_ClientConflictResolution_Notification::class.java,
          packetMsg
          )
      "SignalAppExitSyncDone" -> postNotificationMsg<CCloud_AppExitSyncDone_Notification.Builder>(
          CCloud_AppExitSyncDone_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CCloud_ClientLogUploadCheck_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientLogUploadCheck(request: CCloud_ClientLogUploadCheck_Notification) {
    unifiedMessages!!.sendNotification<CCloud_ClientLogUploadCheck_Notification.Builder>(
        "Cloud.ClientLogUploadCheck#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CCloud_ClientLogUploadComplete_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientLogUploadComplete(request: CCloud_ClientLogUploadComplete_Notification) {
    unifiedMessages!!.sendNotification<CCloud_ClientLogUploadComplete_Notification.Builder>(
        "Cloud.ClientLogUploadComplete#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CCloud_BeginHTTPUpload_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_BeginHTTPUpload_Response]>>
   */
  public fun beginHTTPUpload(request: CCloud_BeginHTTPUpload_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_BeginHTTPUpload_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_BeginHTTPUpload_Response.Builder::class.java,
  "Cloud.BeginHTTPUpload#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_CommitHTTPUpload_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_CommitHTTPUpload_Response]>>
   */
  public fun commitHTTPUpload(request: CCloud_CommitHTTPUpload_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_CommitHTTPUpload_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_CommitHTTPUpload_Response.Builder::class.java,
  "Cloud.CommitHTTPUpload#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_BeginUGCUpload_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_BeginUGCUpload_Response]>>
   */
  public fun beginUGCUpload(request: CCloud_BeginUGCUpload_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_BeginUGCUpload_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_BeginUGCUpload_Response.Builder::class.java,
  "Cloud.BeginUGCUpload#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_CommitUGCUpload_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_CommitUGCUpload_Response]>>
   */
  public fun commitUGCUpload(request: CCloud_CommitUGCUpload_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_CommitUGCUpload_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_CommitUGCUpload_Response.Builder::class.java,
  "Cloud.CommitUGCUpload#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_GetFileDetails_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_GetFileDetails_Response]>>
   */
  public fun getFileDetails(request: CCloud_GetFileDetails_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_GetFileDetails_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_GetFileDetails_Response.Builder::class.java,
  "Cloud.GetFileDetails#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_GetSingleFileInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_GetSingleFileInfo_Response]>>
   */
  public fun getSingleFileInfo(request: CCloud_GetSingleFileInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_GetSingleFileInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_GetSingleFileInfo_Response.Builder::class.java,
  "Cloud.GetSingleFileInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_ShareFile_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_ShareFile_Response]>>
   */
  public fun shareFile(request: CCloud_ShareFile_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_ShareFile_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_ShareFile_Response.Builder::class.java,
  "Cloud.ShareFile#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_EnumerateUserFiles_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_EnumerateUserFiles_Response]>>
   */
  public fun enumerateUserFiles(request: CCloud_EnumerateUserFiles_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_EnumerateUserFiles_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_EnumerateUserFiles_Response.Builder::class.java,
  "Cloud.EnumerateUserFiles#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_Delete_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_Delete_Response]>>
   */
  public fun delete(request: CCloud_Delete_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_Delete_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_Delete_Response.Builder::class.java,
  "Cloud.Delete#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_GetClientEncryptionKey_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_GetClientEncryptionKey_Response]>>
   */
  public fun getClientEncryptionKey(request: CCloud_GetClientEncryptionKey_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_GetClientEncryptionKey_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_GetClientEncryptionKey_Response.Builder::class.java,
  "Cloud.GetClientEncryptionKey#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_CDNReport_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun cDNReport(request: CCloud_CDNReport_Notification) {
    unifiedMessages!!.sendNotification<CCloud_CDNReport_Notification.Builder>(
        "Cloud.CDNReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CCloud_ExternalStorageTransferReport_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun externalStorageTransferReport(request: CCloud_ExternalStorageTransferReport_Notification) {
    unifiedMessages!!.sendNotification<CCloud_ExternalStorageTransferReport_Notification.Builder>(
        "Cloud.ExternalStorageTransferReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CCloud_BeginAppUploadBatch_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_BeginAppUploadBatch_Response]>>
   */
  public fun beginAppUploadBatch(request: CCloud_BeginAppUploadBatch_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_BeginAppUploadBatch_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_BeginAppUploadBatch_Response.Builder::class.java,
  "Cloud.BeginAppUploadBatch#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_CompleteAppUploadBatch_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun completeAppUploadBatch(request: CCloud_CompleteAppUploadBatch_Notification) {
    unifiedMessages!!.sendNotification<CCloud_CompleteAppUploadBatch_Notification.Builder>(
        "Cloud.CompleteAppUploadBatch#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CCloud_CompleteAppUploadBatch_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_CompleteAppUploadBatch_Response]>>
   */
  public fun completeAppUploadBatchBlocking(request: CCloud_CompleteAppUploadBatch_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_CompleteAppUploadBatch_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_CompleteAppUploadBatch_Response.Builder::class.java,
  "Cloud.CompleteAppUploadBatchBlocking#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_ClientBeginFileUpload_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_ClientBeginFileUpload_Response]>>
   */
  public fun clientBeginFileUpload(request: CCloud_ClientBeginFileUpload_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_ClientBeginFileUpload_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_ClientBeginFileUpload_Response.Builder::class.java,
  "Cloud.ClientBeginFileUpload#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_ClientCommitFileUpload_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_ClientCommitFileUpload_Response]>>
   */
  public fun clientCommitFileUpload(request: CCloud_ClientCommitFileUpload_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_ClientCommitFileUpload_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_ClientCommitFileUpload_Response.Builder::class.java,
  "Cloud.ClientCommitFileUpload#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_ClientFileDownload_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_ClientFileDownload_Response]>>
   */
  public fun clientFileDownload(request: CCloud_ClientFileDownload_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_ClientFileDownload_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_ClientFileDownload_Response.Builder::class.java,
  "Cloud.ClientFileDownload#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_ClientDeleteFile_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_ClientDeleteFile_Response]>>
   */
  public fun clientDeleteFile(request: CCloud_ClientDeleteFile_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_ClientDeleteFile_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_ClientDeleteFile_Response.Builder::class.java,
  "Cloud.ClientDeleteFile#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_ClientConflictResolution_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientConflictResolution(request: CCloud_ClientConflictResolution_Notification) {
    unifiedMessages!!.sendNotification<CCloud_ClientConflictResolution_Notification.Builder>(
        "Cloud.ClientConflictResolution#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CCloud_GetAppFileChangelist_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_GetAppFileChangelist_Response]>>
   */
  public fun getAppFileChangelist(request: CCloud_GetAppFileChangelist_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_GetAppFileChangelist_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_GetAppFileChangelist_Response.Builder::class.java,
  "Cloud.GetAppFileChangelist#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_AppSessionSuspend_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_AppSessionSuspend_Response]>>
   */
  public fun suspendAppSession(request: CCloud_AppSessionSuspend_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_AppSessionSuspend_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_AppSessionSuspend_Response.Builder::class.java,
  "Cloud.SuspendAppSession#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_AppSessionResume_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_AppSessionResume_Response]>>
   */
  public fun resumeAppSession(request: CCloud_AppSessionResume_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_AppSessionResume_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_AppSessionResume_Response.Builder::class.java,
  "Cloud.ResumeAppSession#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_AppLaunchIntent_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_AppLaunchIntent_Response]>>
   */
  public fun signalAppLaunchIntent(request: CCloud_AppLaunchIntent_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_AppLaunchIntent_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_AppLaunchIntent_Response.Builder::class.java,
  "Cloud.SignalAppLaunchIntent#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloud_AppExitSyncDone_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun signalAppExitSyncDone(request: CCloud_AppExitSyncDone_Notification) {
    unifiedMessages!!.sendNotification<CCloud_AppExitSyncDone_Notification.Builder>(
        "Cloud.SignalAppExitSyncDone#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CCloud_ClientGetAppQuotaUsage_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloud_ClientGetAppQuotaUsage_Response]>>
   */
  public fun clientGetAppQuotaUsage(request: CCloud_ClientGetAppQuotaUsage_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesCloudSteamclient.CCloud_ClientGetAppQuotaUsage_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloud_ClientGetAppQuotaUsage_Response.Builder::class.java,
  "Cloud.ClientGetAppQuotaUsage#1",
  request
  )
}
