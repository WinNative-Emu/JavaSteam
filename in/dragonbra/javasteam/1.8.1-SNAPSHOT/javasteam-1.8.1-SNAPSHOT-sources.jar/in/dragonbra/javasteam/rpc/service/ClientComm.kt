package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_EnableOrDisableDownloads_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_EnableOrDisableDownloads_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetAllClientLogonInfo_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetAllClientLogonInfo_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetClientAppList_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetClientAppList_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetClientInfo_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetClientInfo_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetClientLogonInfo_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_GetClientLogonInfo_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_InstallClientApp_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_InstallClientApp_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_LaunchClientApp_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_LaunchClientApp_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_SetClientAppUpdateState_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_SetClientAppUpdateState_Response
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_UninstallClientApp_Request
import `in`.dragonbra.javasteam.protobufs.webui.ServiceClientcomm.CClientComm_UninstallClientApp_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ClientComm : UnifiedService {
  override val serviceName: String
    get() = "ClientComm"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "EnableOrDisableDownloads" -> postResponseMsg<CClientComm_EnableOrDisableDownloads_Response.Builder>(
          CClientComm_EnableOrDisableDownloads_Response::class.java,
          packetMsg
          )
      "GetAllClientLogonInfo" -> postResponseMsg<CClientComm_GetAllClientLogonInfo_Response.Builder>(
          CClientComm_GetAllClientLogonInfo_Response::class.java,
          packetMsg
          )
      "GetClientAppList" -> postResponseMsg<CClientComm_GetClientAppList_Response.Builder>(
          CClientComm_GetClientAppList_Response::class.java,
          packetMsg
          )
      "GetClientInfo" -> postResponseMsg<CClientComm_GetClientInfo_Response.Builder>(
          CClientComm_GetClientInfo_Response::class.java,
          packetMsg
          )
      "GetClientLogonInfo" -> postResponseMsg<CClientComm_GetClientLogonInfo_Response.Builder>(
          CClientComm_GetClientLogonInfo_Response::class.java,
          packetMsg
          )
      "InstallClientApp" -> postResponseMsg<CClientComm_InstallClientApp_Response.Builder>(
          CClientComm_InstallClientApp_Response::class.java,
          packetMsg
          )
      "LaunchClientApp" -> postResponseMsg<CClientComm_LaunchClientApp_Response.Builder>(
          CClientComm_LaunchClientApp_Response::class.java,
          packetMsg
          )
      "SetClientAppUpdateState" -> postResponseMsg<CClientComm_SetClientAppUpdateState_Response.Builder>(
          CClientComm_SetClientAppUpdateState_Response::class.java,
          packetMsg
          )
      "UninstallClientApp" -> postResponseMsg<CClientComm_UninstallClientApp_Response.Builder>(
          CClientComm_UninstallClientApp_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CClientComm_EnableOrDisableDownloads_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_EnableOrDisableDownloads_Response]>>
   */
  public fun enableOrDisableDownloads(request: CClientComm_EnableOrDisableDownloads_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_EnableOrDisableDownloads_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_EnableOrDisableDownloads_Response.Builder::class.java,
  "ClientComm.EnableOrDisableDownloads#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_GetAllClientLogonInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_GetAllClientLogonInfo_Response]>>
   */
  public fun getAllClientLogonInfo(request: CClientComm_GetAllClientLogonInfo_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_GetAllClientLogonInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_GetAllClientLogonInfo_Response.Builder::class.java,
  "ClientComm.GetAllClientLogonInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_GetClientAppList_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_GetClientAppList_Response]>>
   */
  public fun getClientAppList(request: CClientComm_GetClientAppList_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_GetClientAppList_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_GetClientAppList_Response.Builder::class.java,
  "ClientComm.GetClientAppList#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_GetClientInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_GetClientInfo_Response]>>
   */
  public fun getClientInfo(request: CClientComm_GetClientInfo_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_GetClientInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_GetClientInfo_Response.Builder::class.java,
  "ClientComm.GetClientInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_GetClientLogonInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_GetClientLogonInfo_Response]>>
   */
  public fun getClientLogonInfo(request: CClientComm_GetClientLogonInfo_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_GetClientLogonInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_GetClientLogonInfo_Response.Builder::class.java,
  "ClientComm.GetClientLogonInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_InstallClientApp_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_InstallClientApp_Response]>>
   */
  public fun installClientApp(request: CClientComm_InstallClientApp_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_InstallClientApp_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_InstallClientApp_Response.Builder::class.java,
  "ClientComm.InstallClientApp#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_LaunchClientApp_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_LaunchClientApp_Response]>>
   */
  public fun launchClientApp(request: CClientComm_LaunchClientApp_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_LaunchClientApp_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_LaunchClientApp_Response.Builder::class.java,
  "ClientComm.LaunchClientApp#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_SetClientAppUpdateState_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_SetClientAppUpdateState_Response]>>
   */
  public fun setClientAppUpdateState(request: CClientComm_SetClientAppUpdateState_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_SetClientAppUpdateState_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_SetClientAppUpdateState_Response.Builder::class.java,
  "ClientComm.SetClientAppUpdateState#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClientComm_UninstallClientApp_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClientComm_UninstallClientApp_Response]>>
   */
  public fun uninstallClientApp(request: CClientComm_UninstallClientApp_Request): AsyncJobSingle<ServiceMethodResponse<ServiceClientcomm.CClientComm_UninstallClientApp_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClientComm_UninstallClientApp_Response.Builder::class.java,
  "ClientComm.UninstallClientApp#1",
  request
  )
}
