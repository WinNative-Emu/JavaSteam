package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CEmbeddedClient_AuthorizeCurrentDevice_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CEmbeddedClient_AuthorizeDevice_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class EmbeddedClient : UnifiedService {
  override val serviceName: String
    get() = "EmbeddedClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "AuthorizeCurrentDevice" -> postResponseMsg<CEmbeddedClient_AuthorizeDevice_Response.Builder>(
          CEmbeddedClient_AuthorizeDevice_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CEmbeddedClient_AuthorizeCurrentDevice_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CEmbeddedClient_AuthorizeDevice_Response]>>
   */
  public fun authorizeCurrentDevice(request: CEmbeddedClient_AuthorizeCurrentDevice_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CEmbeddedClient_AuthorizeDevice_Response.Builder>> = unifiedMessages!!.sendMessage(
  CEmbeddedClient_AuthorizeDevice_Response.Builder::class.java,
  "EmbeddedClient.AuthorizeCurrentDevice#1",
  request
  )
}
