package in.dragonbra.javasteam.enums;


public enum EGamingDeviceType {

    Unknown(0),

    StandardPC(1),

    ConsoleLegacy(256),

    PS3(273),

    Steambox(288),

    Tesla(320),

    Handheld_Legacy(512),

    Phone(528),

    Console(540),

    SteamOSGeneric(541),

    SteamDeck(544),

    LegionGoS(545),

    Fremont(546),

    VR(768),

    SteamFrame(769),

    ;

    private final int code;

    EGamingDeviceType(int code) {
        this.code = code;
    }

    public int code() {
        return this.code;
    }

    public static EGamingDeviceType from(int code) {
        for (EGamingDeviceType e : EGamingDeviceType.values()) {
            if (e.code == code) {
                return e;
            }
        }
        return null;
    }
}
