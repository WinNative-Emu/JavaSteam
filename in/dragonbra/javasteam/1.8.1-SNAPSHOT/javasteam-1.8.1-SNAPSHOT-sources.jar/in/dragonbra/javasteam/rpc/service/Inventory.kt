package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_AddItem_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_CombineItemStacks_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_ConsumeItem_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_ConsumePlaytime_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_DevSetNextDrop_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_ExchangeItem_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_GetEligiblePromoItemDefIDs_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_GetEligiblePromoItemDefIDs_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_GetInventory_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_GetItemDefMeta_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_GetItemDefMeta_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_GetUserPurchaseInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_GetUserPurchaseInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_InspectItem_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_ModifyItems_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_PurchaseFinalize_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_PurchaseInit_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_PurchaseInit_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesInventorySteamclient.CInventory_SplitItemStack_Request
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class Inventory : UnifiedService {
  override val serviceName: String
    get() = "Inventory"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetInventory" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "ExchangeItem" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "GetEligiblePromoItemDefIDs" -> postResponseMsg<CInventory_GetEligiblePromoItemDefIDs_Response.Builder>(
          CInventory_GetEligiblePromoItemDefIDs_Response::class.java,
          packetMsg
          )
      "AddPromoItem" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "SafeModifyItems" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "ConsumePlaytime" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "ConsumeItem" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "DevGenerateItem" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "DevSetNextDrop" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "SplitItemStack" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "CombineItemStacks" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "GetItemDefMeta" -> postResponseMsg<CInventory_GetItemDefMeta_Response.Builder>(
          CInventory_GetItemDefMeta_Response::class.java,
          packetMsg
          )
      "GetUserPurchaseInfo" -> postResponseMsg<CInventory_GetUserPurchaseInfo_Response.Builder>(
          CInventory_GetUserPurchaseInfo_Response::class.java,
          packetMsg
          )
      "PurchaseInit" -> postResponseMsg<CInventory_PurchaseInit_Response.Builder>(
          CInventory_PurchaseInit_Response::class.java,
          packetMsg
          )
      "PurchaseFinalize" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
      "InspectItem" -> postResponseMsg<CInventory_Response.Builder>(
          CInventory_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CInventory_GetInventory_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun getInventory(request: CInventory_GetInventory_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.GetInventory#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_ExchangeItem_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun exchangeItem(request: CInventory_ExchangeItem_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.ExchangeItem#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_GetEligiblePromoItemDefIDs_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_GetEligiblePromoItemDefIDs_Response]>>
   */
  public fun getEligiblePromoItemDefIDs(request: CInventory_GetEligiblePromoItemDefIDs_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_GetEligiblePromoItemDefIDs_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_GetEligiblePromoItemDefIDs_Response.Builder::class.java,
  "Inventory.GetEligiblePromoItemDefIDs#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_AddItem_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun addPromoItem(request: CInventory_AddItem_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.AddPromoItem#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_ModifyItems_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun safeModifyItems(request: CInventory_ModifyItems_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.SafeModifyItems#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_ConsumePlaytime_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun consumePlaytime(request: CInventory_ConsumePlaytime_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.ConsumePlaytime#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_ConsumeItem_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun consumeItem(request: CInventory_ConsumeItem_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.ConsumeItem#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_AddItem_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun devGenerateItem(request: CInventory_AddItem_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.DevGenerateItem#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_DevSetNextDrop_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun devSetNextDrop(request: CInventory_DevSetNextDrop_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.DevSetNextDrop#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_SplitItemStack_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun splitItemStack(request: CInventory_SplitItemStack_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.SplitItemStack#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_CombineItemStacks_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun combineItemStacks(request: CInventory_CombineItemStacks_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.CombineItemStacks#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_GetItemDefMeta_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_GetItemDefMeta_Response]>>
   */
  public fun getItemDefMeta(request: CInventory_GetItemDefMeta_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_GetItemDefMeta_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_GetItemDefMeta_Response.Builder::class.java,
  "Inventory.GetItemDefMeta#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_GetUserPurchaseInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_GetUserPurchaseInfo_Response]>>
   */
  public fun getUserPurchaseInfo(request: CInventory_GetUserPurchaseInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_GetUserPurchaseInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_GetUserPurchaseInfo_Response.Builder::class.java,
  "Inventory.GetUserPurchaseInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_PurchaseInit_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_PurchaseInit_Response]>>
   */
  public fun purchaseInit(request: CInventory_PurchaseInit_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_PurchaseInit_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_PurchaseInit_Response.Builder::class.java,
  "Inventory.PurchaseInit#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_PurchaseFinalize_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun purchaseFinalize(request: CInventory_PurchaseFinalize_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.PurchaseFinalize#1",
  request
  )

  /**
   * @param request The request.
   * @see [CInventory_InspectItem_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CInventory_Response]>>
   */
  public fun inspectItem(request: CInventory_InspectItem_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesInventorySteamclient.CInventory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CInventory_Response.Builder::class.java,
  "Inventory.InspectItem#1",
  request
  )
}
