package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CCloudGaming_CreateNonce_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CCloudGaming_CreateNonce_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CCloudGaming_GetTimeRemaining_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CCloudGaming_GetTimeRemaining_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class CloudGaming : UnifiedService {
  override val serviceName: String
    get() = "CloudGaming"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "CreateNonce" -> postResponseMsg<CCloudGaming_CreateNonce_Response.Builder>(
          CCloudGaming_CreateNonce_Response::class.java,
          packetMsg
          )
      "GetTimeRemaining" -> postResponseMsg<CCloudGaming_GetTimeRemaining_Response.Builder>(
          CCloudGaming_GetTimeRemaining_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CCloudGaming_CreateNonce_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloudGaming_CreateNonce_Response]>>
   */
  public fun createNonce(request: CCloudGaming_CreateNonce_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CCloudGaming_CreateNonce_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloudGaming_CreateNonce_Response.Builder::class.java,
  "CloudGaming.CreateNonce#1",
  request
  )

  /**
   * @param request The request.
   * @see [CCloudGaming_GetTimeRemaining_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CCloudGaming_GetTimeRemaining_Response]>>
   */
  public fun getTimeRemaining(request: CCloudGaming_GetTimeRemaining_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CCloudGaming_GetTimeRemaining_Response.Builder>> = unifiedMessages!!.sendMessage(
  CCloudGaming_GetTimeRemaining_Response.Builder::class.java,
  "CloudGaming.GetTimeRemaining#1",
  request
  )
}
