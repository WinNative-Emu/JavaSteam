package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_CreateSession_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_CreateSession_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_DeleteSession_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_DeleteSession_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_EnumerateSessions_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_EnumerateSessions_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_GetSessionDetails_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_GetSessionDetails_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_UpdateNotificationSettings_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_UpdateNotificationSettings_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_UpdateSession_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesGamenotificationsSteamclient.CGameNotifications_UpdateSession_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class GameNotifications : UnifiedService {
  override val serviceName: String
    get() = "GameNotifications"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "UserCreateSession" -> postResponseMsg<CGameNotifications_CreateSession_Response.Builder>(
          CGameNotifications_CreateSession_Response::class.java,
          packetMsg
          )
      "UserDeleteSession" -> postResponseMsg<CGameNotifications_DeleteSession_Response.Builder>(
          CGameNotifications_DeleteSession_Response::class.java,
          packetMsg
          )
      "UserUpdateSession" -> postResponseMsg<CGameNotifications_UpdateSession_Response.Builder>(
          CGameNotifications_UpdateSession_Response::class.java,
          packetMsg
          )
      "EnumerateSessions" -> postResponseMsg<CGameNotifications_EnumerateSessions_Response.Builder>(
          CGameNotifications_EnumerateSessions_Response::class.java,
          packetMsg
          )
      "GetSessionDetails" -> postResponseMsg<CGameNotifications_GetSessionDetails_Response.Builder>(
          CGameNotifications_GetSessionDetails_Response::class.java,
          packetMsg
          )
      "UpdateNotificationSettings" -> postResponseMsg<CGameNotifications_UpdateNotificationSettings_Response.Builder>(
          CGameNotifications_UpdateNotificationSettings_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CGameNotifications_CreateSession_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CGameNotifications_CreateSession_Response]>>
   */
  public fun userCreateSession(request: CGameNotifications_CreateSession_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesGamenotificationsSteamclient.CGameNotifications_CreateSession_Response.Builder>> = unifiedMessages!!.sendMessage(
  CGameNotifications_CreateSession_Response.Builder::class.java,
  "GameNotifications.UserCreateSession#1",
  request
  )

  /**
   * @param request The request.
   * @see [CGameNotifications_DeleteSession_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CGameNotifications_DeleteSession_Response]>>
   */
  public fun userDeleteSession(request: CGameNotifications_DeleteSession_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesGamenotificationsSteamclient.CGameNotifications_DeleteSession_Response.Builder>> = unifiedMessages!!.sendMessage(
  CGameNotifications_DeleteSession_Response.Builder::class.java,
  "GameNotifications.UserDeleteSession#1",
  request
  )

  /**
   * @param request The request.
   * @see [CGameNotifications_UpdateSession_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CGameNotifications_UpdateSession_Response]>>
   */
  public fun userUpdateSession(request: CGameNotifications_UpdateSession_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesGamenotificationsSteamclient.CGameNotifications_UpdateSession_Response.Builder>> = unifiedMessages!!.sendMessage(
  CGameNotifications_UpdateSession_Response.Builder::class.java,
  "GameNotifications.UserUpdateSession#1",
  request
  )

  /**
   * @param request The request.
   * @see [CGameNotifications_EnumerateSessions_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CGameNotifications_EnumerateSessions_Response]>>
   */
  public fun enumerateSessions(request: CGameNotifications_EnumerateSessions_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesGamenotificationsSteamclient.CGameNotifications_EnumerateSessions_Response.Builder>> = unifiedMessages!!.sendMessage(
  CGameNotifications_EnumerateSessions_Response.Builder::class.java,
  "GameNotifications.EnumerateSessions#1",
  request
  )

  /**
   * @param request The request.
   * @see [CGameNotifications_GetSessionDetails_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CGameNotifications_GetSessionDetails_Response]>>
   */
  public fun getSessionDetails(request: CGameNotifications_GetSessionDetails_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesGamenotificationsSteamclient.CGameNotifications_GetSessionDetails_Response.Builder>> = unifiedMessages!!.sendMessage(
  CGameNotifications_GetSessionDetails_Response.Builder::class.java,
  "GameNotifications.GetSessionDetails#1",
  request
  )

  /**
   * @param request The request.
   * @see [CGameNotifications_UpdateNotificationSettings_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CGameNotifications_UpdateNotificationSettings_Response]>>
   */
  public fun updateNotificationSettings(request: CGameNotifications_UpdateNotificationSettings_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesGamenotificationsSteamclient.CGameNotifications_UpdateNotificationSettings_Response.Builder>> = unifiedMessages!!.sendMessage(
  CGameNotifications_UpdateNotificationSettings_Response.Builder::class.java,
  "GameNotifications.UpdateNotificationSettings#1",
  request
  )
}
