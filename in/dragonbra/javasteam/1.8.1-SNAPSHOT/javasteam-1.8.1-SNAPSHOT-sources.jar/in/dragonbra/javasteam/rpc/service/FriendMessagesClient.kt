package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_AckMessage_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_IncomingMessage_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_MessageReaction_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFriendmessagesSteamclient.CFriendMessages_SessionNotice_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class FriendMessagesClient : UnifiedService {
  override val serviceName: String
    get() = "FriendMessagesClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "IncomingMessage" -> postNotificationMsg<CFriendMessages_IncomingMessage_Notification.Builder>(
          CFriendMessages_IncomingMessage_Notification::class.java,
          packetMsg
          )
      "NotifyAckMessageEcho" -> postNotificationMsg<CFriendMessages_AckMessage_Notification.Builder>(
          CFriendMessages_AckMessage_Notification::class.java,
          packetMsg
          )
      "MessageReaction" -> postNotificationMsg<CFriendMessages_MessageReaction_Notification.Builder>(
          CFriendMessages_MessageReaction_Notification::class.java,
          packetMsg
          )
      "SessionNotice" -> postNotificationMsg<CFriendMessages_SessionNotice_Notification.Builder>(
          CFriendMessages_SessionNotice_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CFriendMessages_IncomingMessage_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun incomingMessage(request: CFriendMessages_IncomingMessage_Notification) {
    unifiedMessages!!.sendNotification<CFriendMessages_IncomingMessage_Notification.Builder>(
        "FriendMessagesClient.IncomingMessage#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CFriendMessages_AckMessage_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyAckMessageEcho(request: CFriendMessages_AckMessage_Notification) {
    unifiedMessages!!.sendNotification<CFriendMessages_AckMessage_Notification.Builder>(
        "FriendMessagesClient.NotifyAckMessageEcho#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CFriendMessages_MessageReaction_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun messageReaction(request: CFriendMessages_MessageReaction_Notification) {
    unifiedMessages!!.sendNotification<CFriendMessages_MessageReaction_Notification.Builder>(
        "FriendMessagesClient.MessageReaction#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CFriendMessages_SessionNotice_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun sessionNotice(request: CFriendMessages_SessionNotice_Notification) {
    unifiedMessages!!.sendNotification<CFriendMessages_SessionNotice_Notification.Builder>(
        "FriendMessagesClient.SessionNotice#1",
        request
        )
  }
}
