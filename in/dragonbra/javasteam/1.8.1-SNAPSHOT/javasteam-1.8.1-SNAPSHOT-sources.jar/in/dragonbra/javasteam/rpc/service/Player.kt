package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_AcceptSSA_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_AcceptSSA_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_AddFriend_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_AddFriend_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_DeletePostedStatus_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_DeletePostedStatus_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetAchievementsProgress_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetAchievementsProgress_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetAnimatedAvatar_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetAnimatedAvatar_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetAvatarFrame_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetAvatarFrame_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetCommunityBadgeProgress_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetCommunityBadgeProgress_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetCommunityPreferences_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetCommunityPreferences_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetDurationControl_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetDurationControl_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetEmoticonList_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetEmoticonList_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetFavoriteBadge_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetFavoriteBadge_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetFriendsGameplayInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetFriendsGameplayInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetGameAchievements_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetGameAchievements_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetGameBadgeLevels_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetGameBadgeLevels_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetLastPlayedTimes_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetLastPlayedTimes_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetMiniProfileBackground_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetMiniProfileBackground_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetMutualFriendsForIncomingInvites_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetMutualFriendsForIncomingInvites_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetNewSteamAnnouncementState_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetNewSteamAnnouncementState_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetNicknameList_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetNicknameList_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetOwnedGames_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetOwnedGames_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPerFriendPreferences_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPerFriendPreferences_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPlayNext_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPlayNext_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPlayerLinkDetails_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPlayerLinkDetails_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPostedStatus_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPostedStatus_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPrivacySettings_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPrivacySettings_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileBackground_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileBackground_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileCustomization_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileCustomization_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileItemsEquipped_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileItemsEquipped_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileItemsOwned_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileItemsOwned_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileThemesAvailable_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetProfileThemesAvailable_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPurchasedProfileCustomizations_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetPurchasedProfileCustomizations_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetRecentPlaytimeSessionsForChild_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetRecentPlaytimeSessionsForChild_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetSteamDeckKeyboardSkin_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetSteamDeckKeyboardSkin_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetTextFilterWords_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetTextFilterWords_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetTimeSSAAccepted_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetTimeSSAAccepted_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetTopAchievementsForGames_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_GetTopAchievementsForGames_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_IgnoreFriend_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_IgnoreFriend_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_PostStatusToFriends_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_PostStatusToFriends_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_RecordDisconnectedPlaytime_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_RecordDisconnectedPlaytime_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_RemoveFriend_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_RemoveFriend_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetAnimatedAvatar_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetAnimatedAvatar_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetAvatarFrame_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetAvatarFrame_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetCommunityPreferences_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetCommunityPreferences_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetEquippedProfileItemFlags_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetEquippedProfileItemFlags_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetFavoriteBadge_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetFavoriteBadge_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetMiniProfileBackground_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetMiniProfileBackground_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetPerFriendPreferences_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetPerFriendPreferences_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetProfileBackground_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetProfileBackground_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetProfilePreferences_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetProfilePreferences_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetProfileTheme_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetProfileTheme_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetSteamDeckKeyboardSkin_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_SetSteamDeckKeyboardSkin_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_UpdateSteamAnnouncementLastRead_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPlayerSteamclient.CPlayer_UpdateSteamAnnouncementLastRead_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class Player : UnifiedService {
  override val serviceName: String
    get() = "Player"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetRecentPlaytimeSessionsForChild" -> postResponseMsg<CPlayer_GetRecentPlaytimeSessionsForChild_Response.Builder>(
          CPlayer_GetRecentPlaytimeSessionsForChild_Response::class.java,
          packetMsg
          )
      "GetPlayerLinkDetails" -> postResponseMsg<CPlayer_GetPlayerLinkDetails_Response.Builder>(
          CPlayer_GetPlayerLinkDetails_Response::class.java,
          packetMsg
          )
      "GetMutualFriendsForIncomingInvites" -> postResponseMsg<CPlayer_GetMutualFriendsForIncomingInvites_Response.Builder>(
          CPlayer_GetMutualFriendsForIncomingInvites_Response::class.java,
          packetMsg
          )
      "GetOwnedGames" -> postResponseMsg<CPlayer_GetOwnedGames_Response.Builder>(
          CPlayer_GetOwnedGames_Response::class.java,
          packetMsg
          )
      "GetPlayNext" -> postResponseMsg<CPlayer_GetPlayNext_Response.Builder>(
          CPlayer_GetPlayNext_Response::class.java,
          packetMsg
          )
      "GetFriendsGameplayInfo" -> postResponseMsg<CPlayer_GetFriendsGameplayInfo_Response.Builder>(
          CPlayer_GetFriendsGameplayInfo_Response::class.java,
          packetMsg
          )
      "GetGameBadgeLevels" -> postResponseMsg<CPlayer_GetGameBadgeLevels_Response.Builder>(
          CPlayer_GetGameBadgeLevels_Response::class.java,
          packetMsg
          )
      "GetProfileBackground" -> postResponseMsg<CPlayer_GetProfileBackground_Response.Builder>(
          CPlayer_GetProfileBackground_Response::class.java,
          packetMsg
          )
      "SetProfileBackground" -> postResponseMsg<CPlayer_SetProfileBackground_Response.Builder>(
          CPlayer_SetProfileBackground_Response::class.java,
          packetMsg
          )
      "GetMiniProfileBackground" -> postResponseMsg<CPlayer_GetMiniProfileBackground_Response.Builder>(
          CPlayer_GetMiniProfileBackground_Response::class.java,
          packetMsg
          )
      "SetMiniProfileBackground" -> postResponseMsg<CPlayer_SetMiniProfileBackground_Response.Builder>(
          CPlayer_SetMiniProfileBackground_Response::class.java,
          packetMsg
          )
      "GetAvatarFrame" -> postResponseMsg<CPlayer_GetAvatarFrame_Response.Builder>(
          CPlayer_GetAvatarFrame_Response::class.java,
          packetMsg
          )
      "SetAvatarFrame" -> postResponseMsg<CPlayer_SetAvatarFrame_Response.Builder>(
          CPlayer_SetAvatarFrame_Response::class.java,
          packetMsg
          )
      "GetAnimatedAvatar" -> postResponseMsg<CPlayer_GetAnimatedAvatar_Response.Builder>(
          CPlayer_GetAnimatedAvatar_Response::class.java,
          packetMsg
          )
      "SetAnimatedAvatar" -> postResponseMsg<CPlayer_SetAnimatedAvatar_Response.Builder>(
          CPlayer_SetAnimatedAvatar_Response::class.java,
          packetMsg
          )
      "GetSteamDeckKeyboardSkin" -> postResponseMsg<CPlayer_GetSteamDeckKeyboardSkin_Response.Builder>(
          CPlayer_GetSteamDeckKeyboardSkin_Response::class.java,
          packetMsg
          )
      "SetSteamDeckKeyboardSkin" -> postResponseMsg<CPlayer_SetSteamDeckKeyboardSkin_Response.Builder>(
          CPlayer_SetSteamDeckKeyboardSkin_Response::class.java,
          packetMsg
          )
      "GetProfileItemsOwned" -> postResponseMsg<CPlayer_GetProfileItemsOwned_Response.Builder>(
          CPlayer_GetProfileItemsOwned_Response::class.java,
          packetMsg
          )
      "GetProfileItemsEquipped" -> postResponseMsg<CPlayer_GetProfileItemsEquipped_Response.Builder>(
          CPlayer_GetProfileItemsEquipped_Response::class.java,
          packetMsg
          )
      "SetEquippedProfileItemFlags" -> postResponseMsg<CPlayer_SetEquippedProfileItemFlags_Response.Builder>(
          CPlayer_SetEquippedProfileItemFlags_Response::class.java,
          packetMsg
          )
      "GetEmoticonList" -> postResponseMsg<CPlayer_GetEmoticonList_Response.Builder>(
          CPlayer_GetEmoticonList_Response::class.java,
          packetMsg
          )
      "GetCommunityBadgeProgress" -> postResponseMsg<CPlayer_GetCommunityBadgeProgress_Response.Builder>(
          CPlayer_GetCommunityBadgeProgress_Response::class.java,
          packetMsg
          )
      "GetTopAchievementsForGames" -> postResponseMsg<CPlayer_GetTopAchievementsForGames_Response.Builder>(
          CPlayer_GetTopAchievementsForGames_Response::class.java,
          packetMsg
          )
      "GetAchievementsProgress" -> postResponseMsg<CPlayer_GetAchievementsProgress_Response.Builder>(
          CPlayer_GetAchievementsProgress_Response::class.java,
          packetMsg
          )
      "GetGameAchievements" -> postResponseMsg<CPlayer_GetGameAchievements_Response.Builder>(
          CPlayer_GetGameAchievements_Response::class.java,
          packetMsg
          )
      "GetFavoriteBadge" -> postResponseMsg<CPlayer_GetFavoriteBadge_Response.Builder>(
          CPlayer_GetFavoriteBadge_Response::class.java,
          packetMsg
          )
      "SetFavoriteBadge" -> postResponseMsg<CPlayer_SetFavoriteBadge_Response.Builder>(
          CPlayer_SetFavoriteBadge_Response::class.java,
          packetMsg
          )
      "GetProfileCustomization" -> postResponseMsg<CPlayer_GetProfileCustomization_Response.Builder>(
          CPlayer_GetProfileCustomization_Response::class.java,
          packetMsg
          )
      "GetPurchasedProfileCustomizations" -> postResponseMsg<CPlayer_GetPurchasedProfileCustomizations_Response.Builder>(
          CPlayer_GetPurchasedProfileCustomizations_Response::class.java,
          packetMsg
          )
      "GetPurchasedAndUpgradedProfileCustomizations" -> postResponseMsg<CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Response.Builder>(
          CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Response::class.java,
          packetMsg
          )
      "GetProfileThemesAvailable" -> postResponseMsg<CPlayer_GetProfileThemesAvailable_Response.Builder>(
          CPlayer_GetProfileThemesAvailable_Response::class.java,
          packetMsg
          )
      "SetProfileTheme" -> postResponseMsg<CPlayer_SetProfileTheme_Response.Builder>(
          CPlayer_SetProfileTheme_Response::class.java,
          packetMsg
          )
      "SetProfilePreferences" -> postResponseMsg<CPlayer_SetProfilePreferences_Response.Builder>(
          CPlayer_SetProfilePreferences_Response::class.java,
          packetMsg
          )
      "PostStatusToFriends" -> postResponseMsg<CPlayer_PostStatusToFriends_Response.Builder>(
          CPlayer_PostStatusToFriends_Response::class.java,
          packetMsg
          )
      "GetPostedStatus" -> postResponseMsg<CPlayer_GetPostedStatus_Response.Builder>(
          CPlayer_GetPostedStatus_Response::class.java,
          packetMsg
          )
      "DeletePostedStatus" -> postResponseMsg<CPlayer_DeletePostedStatus_Response.Builder>(
          CPlayer_DeletePostedStatus_Response::class.java,
          packetMsg
          )
      "ClientGetLastPlayedTimes" -> postResponseMsg<CPlayer_GetLastPlayedTimes_Response.Builder>(
          CPlayer_GetLastPlayedTimes_Response::class.java,
          packetMsg
          )
      "GetTimeSSAAccepted" -> postResponseMsg<CPlayer_GetTimeSSAAccepted_Response.Builder>(
          CPlayer_GetTimeSSAAccepted_Response::class.java,
          packetMsg
          )
      "AcceptSSA" -> postResponseMsg<CPlayer_AcceptSSA_Response.Builder>(
          CPlayer_AcceptSSA_Response::class.java,
          packetMsg
          )
      "GetNicknameList" -> postResponseMsg<CPlayer_GetNicknameList_Response.Builder>(
          CPlayer_GetNicknameList_Response::class.java,
          packetMsg
          )
      "GetPerFriendPreferences" -> postResponseMsg<CPlayer_GetPerFriendPreferences_Response.Builder>(
          CPlayer_GetPerFriendPreferences_Response::class.java,
          packetMsg
          )
      "SetPerFriendPreferences" -> postResponseMsg<CPlayer_SetPerFriendPreferences_Response.Builder>(
          CPlayer_SetPerFriendPreferences_Response::class.java,
          packetMsg
          )
      "AddFriend" -> postResponseMsg<CPlayer_AddFriend_Response.Builder>(
          CPlayer_AddFriend_Response::class.java,
          packetMsg
          )
      "RemoveFriend" -> postResponseMsg<CPlayer_RemoveFriend_Response.Builder>(
          CPlayer_RemoveFriend_Response::class.java,
          packetMsg
          )
      "IgnoreFriend" -> postResponseMsg<CPlayer_IgnoreFriend_Response.Builder>(
          CPlayer_IgnoreFriend_Response::class.java,
          packetMsg
          )
      "GetCommunityPreferences" -> postResponseMsg<CPlayer_GetCommunityPreferences_Response.Builder>(
          CPlayer_GetCommunityPreferences_Response::class.java,
          packetMsg
          )
      "SetCommunityPreferences" -> postResponseMsg<CPlayer_SetCommunityPreferences_Response.Builder>(
          CPlayer_SetCommunityPreferences_Response::class.java,
          packetMsg
          )
      "GetTextFilterWords" -> postResponseMsg<CPlayer_GetTextFilterWords_Response.Builder>(
          CPlayer_GetTextFilterWords_Response::class.java,
          packetMsg
          )
      "GetNewSteamAnnouncementState" -> postResponseMsg<CPlayer_GetNewSteamAnnouncementState_Response.Builder>(
          CPlayer_GetNewSteamAnnouncementState_Response::class.java,
          packetMsg
          )
      "UpdateSteamAnnouncementLastRead" -> postResponseMsg<CPlayer_UpdateSteamAnnouncementLastRead_Response.Builder>(
          CPlayer_UpdateSteamAnnouncementLastRead_Response::class.java,
          packetMsg
          )
      "GetPrivacySettings" -> postResponseMsg<CPlayer_GetPrivacySettings_Response.Builder>(
          CPlayer_GetPrivacySettings_Response::class.java,
          packetMsg
          )
      "GetDurationControl" -> postResponseMsg<CPlayer_GetDurationControl_Response.Builder>(
          CPlayer_GetDurationControl_Response::class.java,
          packetMsg
          )
      "RecordDisconnectedPlaytime" -> postResponseMsg<CPlayer_RecordDisconnectedPlaytime_Response.Builder>(
          CPlayer_RecordDisconnectedPlaytime_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CPlayer_GetRecentPlaytimeSessionsForChild_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetRecentPlaytimeSessionsForChild_Response]>>
   */
  public fun getRecentPlaytimeSessionsForChild(request: CPlayer_GetRecentPlaytimeSessionsForChild_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetRecentPlaytimeSessionsForChild_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetRecentPlaytimeSessionsForChild_Response.Builder::class.java,
  "Player.GetRecentPlaytimeSessionsForChild#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetPlayerLinkDetails_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetPlayerLinkDetails_Response]>>
   */
  public fun getPlayerLinkDetails(request: CPlayer_GetPlayerLinkDetails_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetPlayerLinkDetails_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetPlayerLinkDetails_Response.Builder::class.java,
  "Player.GetPlayerLinkDetails#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetMutualFriendsForIncomingInvites_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetMutualFriendsForIncomingInvites_Response]>>
   */
  public fun getMutualFriendsForIncomingInvites(request: CPlayer_GetMutualFriendsForIncomingInvites_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetMutualFriendsForIncomingInvites_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetMutualFriendsForIncomingInvites_Response.Builder::class.java,
  "Player.GetMutualFriendsForIncomingInvites#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetOwnedGames_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetOwnedGames_Response]>>
   */
  public fun getOwnedGames(request: CPlayer_GetOwnedGames_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetOwnedGames_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetOwnedGames_Response.Builder::class.java,
  "Player.GetOwnedGames#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetPlayNext_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetPlayNext_Response]>>
   */
  public fun getPlayNext(request: CPlayer_GetPlayNext_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetPlayNext_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetPlayNext_Response.Builder::class.java,
  "Player.GetPlayNext#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetFriendsGameplayInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetFriendsGameplayInfo_Response]>>
   */
  public fun getFriendsGameplayInfo(request: CPlayer_GetFriendsGameplayInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetFriendsGameplayInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetFriendsGameplayInfo_Response.Builder::class.java,
  "Player.GetFriendsGameplayInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetGameBadgeLevels_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetGameBadgeLevels_Response]>>
   */
  public fun getGameBadgeLevels(request: CPlayer_GetGameBadgeLevels_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetGameBadgeLevels_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetGameBadgeLevels_Response.Builder::class.java,
  "Player.GetGameBadgeLevels#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetProfileBackground_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetProfileBackground_Response]>>
   */
  public fun getProfileBackground(request: CPlayer_GetProfileBackground_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetProfileBackground_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetProfileBackground_Response.Builder::class.java,
  "Player.GetProfileBackground#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetProfileBackground_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetProfileBackground_Response]>>
   */
  public fun setProfileBackground(request: CPlayer_SetProfileBackground_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetProfileBackground_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetProfileBackground_Response.Builder::class.java,
  "Player.SetProfileBackground#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetMiniProfileBackground_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetMiniProfileBackground_Response]>>
   */
  public fun getMiniProfileBackground(request: CPlayer_GetMiniProfileBackground_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetMiniProfileBackground_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetMiniProfileBackground_Response.Builder::class.java,
  "Player.GetMiniProfileBackground#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetMiniProfileBackground_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetMiniProfileBackground_Response]>>
   */
  public fun setMiniProfileBackground(request: CPlayer_SetMiniProfileBackground_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetMiniProfileBackground_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetMiniProfileBackground_Response.Builder::class.java,
  "Player.SetMiniProfileBackground#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetAvatarFrame_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetAvatarFrame_Response]>>
   */
  public fun getAvatarFrame(request: CPlayer_GetAvatarFrame_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetAvatarFrame_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetAvatarFrame_Response.Builder::class.java,
  "Player.GetAvatarFrame#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetAvatarFrame_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetAvatarFrame_Response]>>
   */
  public fun setAvatarFrame(request: CPlayer_SetAvatarFrame_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetAvatarFrame_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetAvatarFrame_Response.Builder::class.java,
  "Player.SetAvatarFrame#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetAnimatedAvatar_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetAnimatedAvatar_Response]>>
   */
  public fun getAnimatedAvatar(request: CPlayer_GetAnimatedAvatar_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetAnimatedAvatar_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetAnimatedAvatar_Response.Builder::class.java,
  "Player.GetAnimatedAvatar#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetAnimatedAvatar_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetAnimatedAvatar_Response]>>
   */
  public fun setAnimatedAvatar(request: CPlayer_SetAnimatedAvatar_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetAnimatedAvatar_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetAnimatedAvatar_Response.Builder::class.java,
  "Player.SetAnimatedAvatar#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetSteamDeckKeyboardSkin_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetSteamDeckKeyboardSkin_Response]>>
   */
  public fun getSteamDeckKeyboardSkin(request: CPlayer_GetSteamDeckKeyboardSkin_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetSteamDeckKeyboardSkin_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetSteamDeckKeyboardSkin_Response.Builder::class.java,
  "Player.GetSteamDeckKeyboardSkin#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetSteamDeckKeyboardSkin_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetSteamDeckKeyboardSkin_Response]>>
   */
  public fun setSteamDeckKeyboardSkin(request: CPlayer_SetSteamDeckKeyboardSkin_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetSteamDeckKeyboardSkin_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetSteamDeckKeyboardSkin_Response.Builder::class.java,
  "Player.SetSteamDeckKeyboardSkin#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetProfileItemsOwned_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetProfileItemsOwned_Response]>>
   */
  public fun getProfileItemsOwned(request: CPlayer_GetProfileItemsOwned_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetProfileItemsOwned_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetProfileItemsOwned_Response.Builder::class.java,
  "Player.GetProfileItemsOwned#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetProfileItemsEquipped_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetProfileItemsEquipped_Response]>>
   */
  public fun getProfileItemsEquipped(request: CPlayer_GetProfileItemsEquipped_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetProfileItemsEquipped_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetProfileItemsEquipped_Response.Builder::class.java,
  "Player.GetProfileItemsEquipped#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetEquippedProfileItemFlags_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetEquippedProfileItemFlags_Response]>>
   */
  public fun setEquippedProfileItemFlags(request: CPlayer_SetEquippedProfileItemFlags_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetEquippedProfileItemFlags_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetEquippedProfileItemFlags_Response.Builder::class.java,
  "Player.SetEquippedProfileItemFlags#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetEmoticonList_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetEmoticonList_Response]>>
   */
  public fun getEmoticonList(request: CPlayer_GetEmoticonList_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetEmoticonList_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetEmoticonList_Response.Builder::class.java,
  "Player.GetEmoticonList#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetCommunityBadgeProgress_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetCommunityBadgeProgress_Response]>>
   */
  public fun getCommunityBadgeProgress(request: CPlayer_GetCommunityBadgeProgress_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetCommunityBadgeProgress_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetCommunityBadgeProgress_Response.Builder::class.java,
  "Player.GetCommunityBadgeProgress#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetTopAchievementsForGames_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetTopAchievementsForGames_Response]>>
   */
  public fun getTopAchievementsForGames(request: CPlayer_GetTopAchievementsForGames_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetTopAchievementsForGames_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetTopAchievementsForGames_Response.Builder::class.java,
  "Player.GetTopAchievementsForGames#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetAchievementsProgress_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetAchievementsProgress_Response]>>
   */
  public fun getAchievementsProgress(request: CPlayer_GetAchievementsProgress_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetAchievementsProgress_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetAchievementsProgress_Response.Builder::class.java,
  "Player.GetAchievementsProgress#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetGameAchievements_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetGameAchievements_Response]>>
   */
  public fun getGameAchievements(request: CPlayer_GetGameAchievements_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetGameAchievements_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetGameAchievements_Response.Builder::class.java,
  "Player.GetGameAchievements#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetFavoriteBadge_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetFavoriteBadge_Response]>>
   */
  public fun getFavoriteBadge(request: CPlayer_GetFavoriteBadge_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetFavoriteBadge_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetFavoriteBadge_Response.Builder::class.java,
  "Player.GetFavoriteBadge#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetFavoriteBadge_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetFavoriteBadge_Response]>>
   */
  public fun setFavoriteBadge(request: CPlayer_SetFavoriteBadge_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetFavoriteBadge_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetFavoriteBadge_Response.Builder::class.java,
  "Player.SetFavoriteBadge#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetProfileCustomization_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetProfileCustomization_Response]>>
   */
  public fun getProfileCustomization(request: CPlayer_GetProfileCustomization_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetProfileCustomization_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetProfileCustomization_Response.Builder::class.java,
  "Player.GetProfileCustomization#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetPurchasedProfileCustomizations_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetPurchasedProfileCustomizations_Response]>>
   */
  public fun getPurchasedProfileCustomizations(request: CPlayer_GetPurchasedProfileCustomizations_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetPurchasedProfileCustomizations_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetPurchasedProfileCustomizations_Response.Builder::class.java,
  "Player.GetPurchasedProfileCustomizations#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Response]>>
   */
  public fun getPurchasedAndUpgradedProfileCustomizations(request: CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetPurchasedAndUpgradedProfileCustomizations_Response.Builder::class.java,
  "Player.GetPurchasedAndUpgradedProfileCustomizations#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetProfileThemesAvailable_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetProfileThemesAvailable_Response]>>
   */
  public fun getProfileThemesAvailable(request: CPlayer_GetProfileThemesAvailable_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetProfileThemesAvailable_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetProfileThemesAvailable_Response.Builder::class.java,
  "Player.GetProfileThemesAvailable#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetProfileTheme_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetProfileTheme_Response]>>
   */
  public fun setProfileTheme(request: CPlayer_SetProfileTheme_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetProfileTheme_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetProfileTheme_Response.Builder::class.java,
  "Player.SetProfileTheme#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetProfilePreferences_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetProfilePreferences_Response]>>
   */
  public fun setProfilePreferences(request: CPlayer_SetProfilePreferences_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetProfilePreferences_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetProfilePreferences_Response.Builder::class.java,
  "Player.SetProfilePreferences#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_PostStatusToFriends_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_PostStatusToFriends_Response]>>
   */
  public fun postStatusToFriends(request: CPlayer_PostStatusToFriends_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_PostStatusToFriends_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_PostStatusToFriends_Response.Builder::class.java,
  "Player.PostStatusToFriends#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetPostedStatus_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetPostedStatus_Response]>>
   */
  public fun getPostedStatus(request: CPlayer_GetPostedStatus_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetPostedStatus_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetPostedStatus_Response.Builder::class.java,
  "Player.GetPostedStatus#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_DeletePostedStatus_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_DeletePostedStatus_Response]>>
   */
  public fun deletePostedStatus(request: CPlayer_DeletePostedStatus_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_DeletePostedStatus_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_DeletePostedStatus_Response.Builder::class.java,
  "Player.DeletePostedStatus#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetLastPlayedTimes_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetLastPlayedTimes_Response]>>
   */
  public fun clientGetLastPlayedTimes(request: CPlayer_GetLastPlayedTimes_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetLastPlayedTimes_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetLastPlayedTimes_Response.Builder::class.java,
  "Player.ClientGetLastPlayedTimes#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetTimeSSAAccepted_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetTimeSSAAccepted_Response]>>
   */
  public fun getTimeSSAAccepted(request: CPlayer_GetTimeSSAAccepted_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetTimeSSAAccepted_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetTimeSSAAccepted_Response.Builder::class.java,
  "Player.GetTimeSSAAccepted#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_AcceptSSA_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_AcceptSSA_Response]>>
   */
  public fun acceptSSA(request: CPlayer_AcceptSSA_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_AcceptSSA_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_AcceptSSA_Response.Builder::class.java,
  "Player.AcceptSSA#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetNicknameList_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetNicknameList_Response]>>
   */
  public fun getNicknameList(request: CPlayer_GetNicknameList_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetNicknameList_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetNicknameList_Response.Builder::class.java,
  "Player.GetNicknameList#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetPerFriendPreferences_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetPerFriendPreferences_Response]>>
   */
  public fun getPerFriendPreferences(request: CPlayer_GetPerFriendPreferences_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetPerFriendPreferences_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetPerFriendPreferences_Response.Builder::class.java,
  "Player.GetPerFriendPreferences#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetPerFriendPreferences_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetPerFriendPreferences_Response]>>
   */
  public fun setPerFriendPreferences(request: CPlayer_SetPerFriendPreferences_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetPerFriendPreferences_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetPerFriendPreferences_Response.Builder::class.java,
  "Player.SetPerFriendPreferences#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_AddFriend_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_AddFriend_Response]>>
   */
  public fun addFriend(request: CPlayer_AddFriend_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_AddFriend_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_AddFriend_Response.Builder::class.java,
  "Player.AddFriend#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_RemoveFriend_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_RemoveFriend_Response]>>
   */
  public fun removeFriend(request: CPlayer_RemoveFriend_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_RemoveFriend_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_RemoveFriend_Response.Builder::class.java,
  "Player.RemoveFriend#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_IgnoreFriend_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_IgnoreFriend_Response]>>
   */
  public fun ignoreFriend(request: CPlayer_IgnoreFriend_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_IgnoreFriend_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_IgnoreFriend_Response.Builder::class.java,
  "Player.IgnoreFriend#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetCommunityPreferences_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetCommunityPreferences_Response]>>
   */
  public fun getCommunityPreferences(request: CPlayer_GetCommunityPreferences_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetCommunityPreferences_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetCommunityPreferences_Response.Builder::class.java,
  "Player.GetCommunityPreferences#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_SetCommunityPreferences_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_SetCommunityPreferences_Response]>>
   */
  public fun setCommunityPreferences(request: CPlayer_SetCommunityPreferences_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_SetCommunityPreferences_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_SetCommunityPreferences_Response.Builder::class.java,
  "Player.SetCommunityPreferences#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetTextFilterWords_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetTextFilterWords_Response]>>
   */
  public fun getTextFilterWords(request: CPlayer_GetTextFilterWords_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetTextFilterWords_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetTextFilterWords_Response.Builder::class.java,
  "Player.GetTextFilterWords#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetNewSteamAnnouncementState_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetNewSteamAnnouncementState_Response]>>
   */
  public fun getNewSteamAnnouncementState(request: CPlayer_GetNewSteamAnnouncementState_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetNewSteamAnnouncementState_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetNewSteamAnnouncementState_Response.Builder::class.java,
  "Player.GetNewSteamAnnouncementState#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_UpdateSteamAnnouncementLastRead_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_UpdateSteamAnnouncementLastRead_Response]>>
   */
  public fun updateSteamAnnouncementLastRead(request: CPlayer_UpdateSteamAnnouncementLastRead_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_UpdateSteamAnnouncementLastRead_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_UpdateSteamAnnouncementLastRead_Response.Builder::class.java,
  "Player.UpdateSteamAnnouncementLastRead#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetPrivacySettings_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetPrivacySettings_Response]>>
   */
  public fun getPrivacySettings(request: CPlayer_GetPrivacySettings_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetPrivacySettings_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetPrivacySettings_Response.Builder::class.java,
  "Player.GetPrivacySettings#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_GetDurationControl_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_GetDurationControl_Response]>>
   */
  public fun getDurationControl(request: CPlayer_GetDurationControl_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_GetDurationControl_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_GetDurationControl_Response.Builder::class.java,
  "Player.GetDurationControl#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPlayer_RecordDisconnectedPlaytime_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPlayer_RecordDisconnectedPlaytime_Response]>>
   */
  public fun recordDisconnectedPlaytime(request: CPlayer_RecordDisconnectedPlaytime_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPlayerSteamclient.CPlayer_RecordDisconnectedPlaytime_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPlayer_RecordDisconnectedPlaytime_Response.Builder::class.java,
  "Player.RecordDisconnectedPlaytime#1",
  request
  )
}
