package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoomClient_MemberListViewUpdated_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_AckChatMessage_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ChatMessageModified_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ChatRoomGroupRoomsChange_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ChatRoomHeaderState_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_IncomingChatMessage_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_MemberStateChange_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_MessageReaction_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_NotifyShouldRejoinChatRoomVoiceChat_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.ChatRoomClient_NotifyChatGroupUserStateChanged_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.ChatRoomClient_NotifyChatRoomDisconnect_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ChatRoomClient : UnifiedService {
  override val serviceName: String
    get() = "ChatRoomClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyIncomingChatMessage" -> postNotificationMsg<CChatRoom_IncomingChatMessage_Notification.Builder>(
          CChatRoom_IncomingChatMessage_Notification::class.java,
          packetMsg
          )
      "NotifyChatMessageModified" -> postNotificationMsg<CChatRoom_ChatMessageModified_Notification.Builder>(
          CChatRoom_ChatMessageModified_Notification::class.java,
          packetMsg
          )
      "NotifyMemberStateChange" -> postNotificationMsg<CChatRoom_MemberStateChange_Notification.Builder>(
          CChatRoom_MemberStateChange_Notification::class.java,
          packetMsg
          )
      "NotifyChatRoomHeaderStateChange" -> postNotificationMsg<CChatRoom_ChatRoomHeaderState_Notification.Builder>(
          CChatRoom_ChatRoomHeaderState_Notification::class.java,
          packetMsg
          )
      "NotifyChatRoomGroupRoomsChange" -> postNotificationMsg<CChatRoom_ChatRoomGroupRoomsChange_Notification.Builder>(
          CChatRoom_ChatRoomGroupRoomsChange_Notification::class.java,
          packetMsg
          )
      "NotifyShouldRejoinChatRoomVoiceChat" -> postNotificationMsg<CChatRoom_NotifyShouldRejoinChatRoomVoiceChat_Notification.Builder>(
          CChatRoom_NotifyShouldRejoinChatRoomVoiceChat_Notification::class.java,
          packetMsg
          )
      "NotifyChatGroupUserStateChanged" -> postNotificationMsg<ChatRoomClient_NotifyChatGroupUserStateChanged_Notification.Builder>(
          ChatRoomClient_NotifyChatGroupUserStateChanged_Notification::class.java,
          packetMsg
          )
      "NotifyAckChatMessageEcho" -> postNotificationMsg<CChatRoom_AckChatMessage_Notification.Builder>(
          CChatRoom_AckChatMessage_Notification::class.java,
          packetMsg
          )
      "NotifyChatRoomDisconnect" -> postNotificationMsg<ChatRoomClient_NotifyChatRoomDisconnect_Notification.Builder>(
          ChatRoomClient_NotifyChatRoomDisconnect_Notification::class.java,
          packetMsg
          )
      "NotifyMemberListViewUpdated" -> postNotificationMsg<CChatRoomClient_MemberListViewUpdated_Notification.Builder>(
          CChatRoomClient_MemberListViewUpdated_Notification::class.java,
          packetMsg
          )
      "NotifyMessageReaction" -> postNotificationMsg<CChatRoom_MessageReaction_Notification.Builder>(
          CChatRoom_MessageReaction_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CChatRoom_IncomingChatMessage_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyIncomingChatMessage(request: CChatRoom_IncomingChatMessage_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_IncomingChatMessage_Notification.Builder>(
        "ChatRoomClient.NotifyIncomingChatMessage#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_ChatMessageModified_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyChatMessageModified(request: CChatRoom_ChatMessageModified_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_ChatMessageModified_Notification.Builder>(
        "ChatRoomClient.NotifyChatMessageModified#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_MemberStateChange_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyMemberStateChange(request: CChatRoom_MemberStateChange_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_MemberStateChange_Notification.Builder>(
        "ChatRoomClient.NotifyMemberStateChange#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_ChatRoomHeaderState_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyChatRoomHeaderStateChange(request: CChatRoom_ChatRoomHeaderState_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_ChatRoomHeaderState_Notification.Builder>(
        "ChatRoomClient.NotifyChatRoomHeaderStateChange#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_ChatRoomGroupRoomsChange_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyChatRoomGroupRoomsChange(request: CChatRoom_ChatRoomGroupRoomsChange_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_ChatRoomGroupRoomsChange_Notification.Builder>(
        "ChatRoomClient.NotifyChatRoomGroupRoomsChange#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_NotifyShouldRejoinChatRoomVoiceChat_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyShouldRejoinChatRoomVoiceChat(request: CChatRoom_NotifyShouldRejoinChatRoomVoiceChat_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_NotifyShouldRejoinChatRoomVoiceChat_Notification.Builder>(
        "ChatRoomClient.NotifyShouldRejoinChatRoomVoiceChat#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [ChatRoomClient_NotifyChatGroupUserStateChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyChatGroupUserStateChanged(request: ChatRoomClient_NotifyChatGroupUserStateChanged_Notification) {
    unifiedMessages!!.sendNotification<ChatRoomClient_NotifyChatGroupUserStateChanged_Notification.Builder>(
        "ChatRoomClient.NotifyChatGroupUserStateChanged#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_AckChatMessage_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyAckChatMessageEcho(request: CChatRoom_AckChatMessage_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_AckChatMessage_Notification.Builder>(
        "ChatRoomClient.NotifyAckChatMessageEcho#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [ChatRoomClient_NotifyChatRoomDisconnect_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyChatRoomDisconnect(request: ChatRoomClient_NotifyChatRoomDisconnect_Notification) {
    unifiedMessages!!.sendNotification<ChatRoomClient_NotifyChatRoomDisconnect_Notification.Builder>(
        "ChatRoomClient.NotifyChatRoomDisconnect#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoomClient_MemberListViewUpdated_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyMemberListViewUpdated(request: CChatRoomClient_MemberListViewUpdated_Notification) {
    unifiedMessages!!.sendNotification<CChatRoomClient_MemberListViewUpdated_Notification.Builder>(
        "ChatRoomClient.NotifyMemberListViewUpdated#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_MessageReaction_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyMessageReaction(request: CChatRoom_MessageReaction_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_MessageReaction_Notification.Builder>(
        "ChatRoomClient.NotifyMessageReaction#1",
        request
        )
  }
}
