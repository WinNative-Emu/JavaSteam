package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatUsability_RequestClientUsabilityMetrics_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ChatUsabilityClient : UnifiedService {
  override val serviceName: String
    get() = "ChatUsabilityClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyRequestClientUsabilityMetrics" -> postNotificationMsg<CChatUsability_RequestClientUsabilityMetrics_Notification.Builder>(
          CChatUsability_RequestClientUsabilityMetrics_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CChatUsability_RequestClientUsabilityMetrics_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyRequestClientUsabilityMetrics(request: CChatUsability_RequestClientUsabilityMetrics_Notification) {
    unifiedMessages!!.sendNotification<CChatUsability_RequestClientUsabilityMetrics_Notification.Builder>(
        "ChatUsabilityClient.NotifyRequestClientUsabilityMetrics#1",
        request
        )
  }
}
