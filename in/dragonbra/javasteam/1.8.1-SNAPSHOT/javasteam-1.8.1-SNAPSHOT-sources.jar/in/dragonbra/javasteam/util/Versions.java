package in.dragonbra.javasteam.util;

public class Versions {
    public static String getVersion() {
        return "1.8.1-SNAPSHOT";
    }
}
