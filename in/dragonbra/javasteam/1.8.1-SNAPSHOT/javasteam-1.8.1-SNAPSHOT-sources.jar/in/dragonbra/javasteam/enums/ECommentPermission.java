package in.dragonbra.javasteam.enums;


public enum ECommentPermission {

    Invalid(-1),

    FriendsOnly(0),

    Anyone(1),

    SelfOnly(2),

    ;

    private final int code;

    ECommentPermission(int code) {
        this.code = code;
    }

    public int code() {
        return this.code;
    }

    public static ECommentPermission from(int code) {
        for (ECommentPermission e : ECommentPermission.values()) {
            if (e.code == code) {
                return e;
            }
        }
        return null;
    }
}
