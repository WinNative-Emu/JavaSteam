package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_FileDeleted_Client_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_FileSubscribed_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_FileUnsubscribed_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class PublishedFileClient : UnifiedService {
  override val serviceName: String
    get() = "PublishedFileClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyFileSubscribed" -> postNotificationMsg<CPublishedFile_FileSubscribed_Notification.Builder>(
          CPublishedFile_FileSubscribed_Notification::class.java,
          packetMsg
          )
      "NotifyFileUnsubscribed" -> postNotificationMsg<CPublishedFile_FileUnsubscribed_Notification.Builder>(
          CPublishedFile_FileUnsubscribed_Notification::class.java,
          packetMsg
          )
      "NotifyFileDeleted" -> postNotificationMsg<CPublishedFile_FileDeleted_Client_Notification.Builder>(
          CPublishedFile_FileDeleted_Client_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CPublishedFile_FileSubscribed_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyFileSubscribed(request: CPublishedFile_FileSubscribed_Notification) {
    unifiedMessages!!.sendNotification<CPublishedFile_FileSubscribed_Notification.Builder>(
        "PublishedFileClient.NotifyFileSubscribed#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPublishedFile_FileUnsubscribed_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyFileUnsubscribed(request: CPublishedFile_FileUnsubscribed_Notification) {
    unifiedMessages!!.sendNotification<CPublishedFile_FileUnsubscribed_Notification.Builder>(
        "PublishedFileClient.NotifyFileUnsubscribed#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CPublishedFile_FileDeleted_Client_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyFileDeleted(request: CPublishedFile_FileDeleted_Client_Notification) {
    unifiedMessages!!.sendNotification<CPublishedFile_FileDeleted_Client_Notification.Builder>(
        "PublishedFileClient.NotifyFileDeleted#1",
        request
        )
  }
}
