package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_AddAppRelationship_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_AddAppRelationship_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_AddChild_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_AddChild_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_AreFilesInSubscriptionList_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_AreFilesInSubscriptionList_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_CanSubscribe_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_CanSubscribe_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Delete_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Delete_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetAppRelationshipsBatched_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetAppRelationshipsBatched_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetAppRelationships_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetAppRelationships_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetChangeHistoryEntry_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetChangeHistoryEntry_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetChangeHistory_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetChangeHistory_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetContentDescriptors_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetContentDescriptors_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetDetails_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetDetails_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetItemChanges_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetItemChanges_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetItemInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetItemInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetSubSectionData_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetSubSectionData_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetUserFiles_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetUserFiles_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetUserVoteSummary_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_GetUserVoteSummary_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Publish_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Publish_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_QueryFiles_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_QueryFiles_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_RefreshVotingQueue_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_RefreshVotingQueue_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_RemoveAppRelationship_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_RemoveAppRelationship_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_RemoveChild_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_RemoveChild_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_SetCollectionChildren_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_SetCollectionChildren_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_SetPlaytimeForControllerConfigs_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_SetPlaytimeForControllerConfigs_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_SetSubscriptionListFromCollection_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_SetSubscriptionListFromCollection_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_StartPlaytimeTracking_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_StartPlaytimeTracking_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_StopPlaytimeTrackingForAllAppItems_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_StopPlaytimeTrackingForAllAppItems_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_StopPlaytimeTracking_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_StopPlaytimeTracking_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Subscribe_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Subscribe_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Unsubscribe_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Unsubscribe_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_UpdateContentDescriptors_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_UpdateContentDescriptors_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Update_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Update_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Vote_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesPublishedfileSteamclient.CPublishedFile_Vote_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class PublishedFile : UnifiedService {
  override val serviceName: String
    get() = "PublishedFile"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "Vote" -> postResponseMsg<CPublishedFile_Vote_Response.Builder>(
          CPublishedFile_Vote_Response::class.java,
          packetMsg
          )
      "Subscribe" -> postResponseMsg<CPublishedFile_Subscribe_Response.Builder>(
          CPublishedFile_Subscribe_Response::class.java,
          packetMsg
          )
      "Unsubscribe" -> postResponseMsg<CPublishedFile_Unsubscribe_Response.Builder>(
          CPublishedFile_Unsubscribe_Response::class.java,
          packetMsg
          )
      "CanSubscribe" -> postResponseMsg<CPublishedFile_CanSubscribe_Response.Builder>(
          CPublishedFile_CanSubscribe_Response::class.java,
          packetMsg
          )
      "GetSubSectionData" -> postResponseMsg<CPublishedFile_GetSubSectionData_Response.Builder>(
          CPublishedFile_GetSubSectionData_Response::class.java,
          packetMsg
          )
      "Publish" -> postResponseMsg<CPublishedFile_Publish_Response.Builder>(
          CPublishedFile_Publish_Response::class.java,
          packetMsg
          )
      "GetDetails" -> postResponseMsg<CPublishedFile_GetDetails_Response.Builder>(
          CPublishedFile_GetDetails_Response::class.java,
          packetMsg
          )
      "GetItemInfo" -> postResponseMsg<CPublishedFile_GetItemInfo_Response.Builder>(
          CPublishedFile_GetItemInfo_Response::class.java,
          packetMsg
          )
      "GetUserFiles" -> postResponseMsg<CPublishedFile_GetUserFiles_Response.Builder>(
          CPublishedFile_GetUserFiles_Response::class.java,
          packetMsg
          )
      "GetUserFileCount" -> postResponseMsg<CPublishedFile_GetUserFiles_Response.Builder>(
          CPublishedFile_GetUserFiles_Response::class.java,
          packetMsg
          )
      "AreFilesInSubscriptionList" -> postResponseMsg<CPublishedFile_AreFilesInSubscriptionList_Response.Builder>(
          CPublishedFile_AreFilesInSubscriptionList_Response::class.java,
          packetMsg
          )
      "Update" -> postResponseMsg<CPublishedFile_Update_Response.Builder>(
          CPublishedFile_Update_Response::class.java,
          packetMsg
          )
      "Delete" -> postResponseMsg<CPublishedFile_Delete_Response.Builder>(
          CPublishedFile_Delete_Response::class.java,
          packetMsg
          )
      "GetChangeHistoryEntry" -> postResponseMsg<CPublishedFile_GetChangeHistoryEntry_Response.Builder>(
          CPublishedFile_GetChangeHistoryEntry_Response::class.java,
          packetMsg
          )
      "GetChangeHistory" -> postResponseMsg<CPublishedFile_GetChangeHistory_Response.Builder>(
          CPublishedFile_GetChangeHistory_Response::class.java,
          packetMsg
          )
      "RefreshVotingQueue" -> postResponseMsg<CPublishedFile_RefreshVotingQueue_Response.Builder>(
          CPublishedFile_RefreshVotingQueue_Response::class.java,
          packetMsg
          )
      "QueryFiles" -> postResponseMsg<CPublishedFile_QueryFiles_Response.Builder>(
          CPublishedFile_QueryFiles_Response::class.java,
          packetMsg
          )
      "AddAppRelationship" -> postResponseMsg<CPublishedFile_AddAppRelationship_Response.Builder>(
          CPublishedFile_AddAppRelationship_Response::class.java,
          packetMsg
          )
      "RemoveAppRelationship" -> postResponseMsg<CPublishedFile_RemoveAppRelationship_Response.Builder>(
          CPublishedFile_RemoveAppRelationship_Response::class.java,
          packetMsg
          )
      "GetAppRelationships" -> postResponseMsg<CPublishedFile_GetAppRelationships_Response.Builder>(
          CPublishedFile_GetAppRelationships_Response::class.java,
          packetMsg
          )
      "GetAppRelationshipsBatched" -> postResponseMsg<CPublishedFile_GetAppRelationshipsBatched_Response.Builder>(
          CPublishedFile_GetAppRelationshipsBatched_Response::class.java,
          packetMsg
          )
      "StartPlaytimeTracking" -> postResponseMsg<CPublishedFile_StartPlaytimeTracking_Response.Builder>(
          CPublishedFile_StartPlaytimeTracking_Response::class.java,
          packetMsg
          )
      "StopPlaytimeTracking" -> postResponseMsg<CPublishedFile_StopPlaytimeTracking_Response.Builder>(
          CPublishedFile_StopPlaytimeTracking_Response::class.java,
          packetMsg
          )
      "StopPlaytimeTrackingForAllAppItems" -> postResponseMsg<CPublishedFile_StopPlaytimeTrackingForAllAppItems_Response.Builder>(
          CPublishedFile_StopPlaytimeTrackingForAllAppItems_Response::class.java,
          packetMsg
          )
      "SetPlaytimeForControllerConfigs" -> postResponseMsg<CPublishedFile_SetPlaytimeForControllerConfigs_Response.Builder>(
          CPublishedFile_SetPlaytimeForControllerConfigs_Response::class.java,
          packetMsg
          )
      "AddChild" -> postResponseMsg<CPublishedFile_AddChild_Response.Builder>(
          CPublishedFile_AddChild_Response::class.java,
          packetMsg
          )
      "RemoveChild" -> postResponseMsg<CPublishedFile_RemoveChild_Response.Builder>(
          CPublishedFile_RemoveChild_Response::class.java,
          packetMsg
          )
      "SetCollectionChildren" -> postResponseMsg<CPublishedFile_SetCollectionChildren_Response.Builder>(
          CPublishedFile_SetCollectionChildren_Response::class.java,
          packetMsg
          )
      "SetSubscriptionListFromCollection" -> postResponseMsg<CPublishedFile_SetSubscriptionListFromCollection_Response.Builder>(
          CPublishedFile_SetSubscriptionListFromCollection_Response::class.java,
          packetMsg
          )
      "GetUserVoteSummary" -> postResponseMsg<CPublishedFile_GetUserVoteSummary_Response.Builder>(
          CPublishedFile_GetUserVoteSummary_Response::class.java,
          packetMsg
          )
      "GetItemChanges" -> postResponseMsg<CPublishedFile_GetItemChanges_Response.Builder>(
          CPublishedFile_GetItemChanges_Response::class.java,
          packetMsg
          )
      "GetContentDescriptors" -> postResponseMsg<CPublishedFile_GetContentDescriptors_Response.Builder>(
          CPublishedFile_GetContentDescriptors_Response::class.java,
          packetMsg
          )
      "UpdateContentDescriptors" -> postResponseMsg<CPublishedFile_UpdateContentDescriptors_Response.Builder>(
          CPublishedFile_UpdateContentDescriptors_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CPublishedFile_Vote_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_Vote_Response]>>
   */
  public fun vote(request: CPublishedFile_Vote_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_Vote_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_Vote_Response.Builder::class.java,
  "PublishedFile.Vote#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_Subscribe_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_Subscribe_Response]>>
   */
  public fun subscribe(request: CPublishedFile_Subscribe_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_Subscribe_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_Subscribe_Response.Builder::class.java,
  "PublishedFile.Subscribe#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_Unsubscribe_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_Unsubscribe_Response]>>
   */
  public fun unsubscribe(request: CPublishedFile_Unsubscribe_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_Unsubscribe_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_Unsubscribe_Response.Builder::class.java,
  "PublishedFile.Unsubscribe#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_CanSubscribe_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_CanSubscribe_Response]>>
   */
  public fun canSubscribe(request: CPublishedFile_CanSubscribe_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_CanSubscribe_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_CanSubscribe_Response.Builder::class.java,
  "PublishedFile.CanSubscribe#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetSubSectionData_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetSubSectionData_Response]>>
   */
  public fun getSubSectionData(request: CPublishedFile_GetSubSectionData_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetSubSectionData_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetSubSectionData_Response.Builder::class.java,
  "PublishedFile.GetSubSectionData#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_Publish_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_Publish_Response]>>
   */
  public fun publish(request: CPublishedFile_Publish_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_Publish_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_Publish_Response.Builder::class.java,
  "PublishedFile.Publish#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetDetails_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetDetails_Response]>>
   */
  public fun getDetails(request: CPublishedFile_GetDetails_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetDetails_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetDetails_Response.Builder::class.java,
  "PublishedFile.GetDetails#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetItemInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetItemInfo_Response]>>
   */
  public fun getItemInfo(request: CPublishedFile_GetItemInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetItemInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetItemInfo_Response.Builder::class.java,
  "PublishedFile.GetItemInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetUserFiles_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetUserFiles_Response]>>
   */
  public fun getUserFiles(request: CPublishedFile_GetUserFiles_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetUserFiles_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetUserFiles_Response.Builder::class.java,
  "PublishedFile.GetUserFiles#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetUserFiles_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetUserFiles_Response]>>
   */
  public fun getUserFileCount(request: CPublishedFile_GetUserFiles_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetUserFiles_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetUserFiles_Response.Builder::class.java,
  "PublishedFile.GetUserFileCount#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_AreFilesInSubscriptionList_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_AreFilesInSubscriptionList_Response]>>
   */
  public fun areFilesInSubscriptionList(request: CPublishedFile_AreFilesInSubscriptionList_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_AreFilesInSubscriptionList_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_AreFilesInSubscriptionList_Response.Builder::class.java,
  "PublishedFile.AreFilesInSubscriptionList#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_Update_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_Update_Response]>>
   */
  public fun update(request: CPublishedFile_Update_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_Update_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_Update_Response.Builder::class.java,
  "PublishedFile.Update#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_Delete_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_Delete_Response]>>
   */
  public fun delete(request: CPublishedFile_Delete_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_Delete_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_Delete_Response.Builder::class.java,
  "PublishedFile.Delete#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetChangeHistoryEntry_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetChangeHistoryEntry_Response]>>
   */
  public fun getChangeHistoryEntry(request: CPublishedFile_GetChangeHistoryEntry_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetChangeHistoryEntry_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetChangeHistoryEntry_Response.Builder::class.java,
  "PublishedFile.GetChangeHistoryEntry#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetChangeHistory_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetChangeHistory_Response]>>
   */
  public fun getChangeHistory(request: CPublishedFile_GetChangeHistory_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetChangeHistory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetChangeHistory_Response.Builder::class.java,
  "PublishedFile.GetChangeHistory#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_RefreshVotingQueue_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_RefreshVotingQueue_Response]>>
   */
  public fun refreshVotingQueue(request: CPublishedFile_RefreshVotingQueue_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_RefreshVotingQueue_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_RefreshVotingQueue_Response.Builder::class.java,
  "PublishedFile.RefreshVotingQueue#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_QueryFiles_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_QueryFiles_Response]>>
   */
  public fun queryFiles(request: CPublishedFile_QueryFiles_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_QueryFiles_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_QueryFiles_Response.Builder::class.java,
  "PublishedFile.QueryFiles#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_AddAppRelationship_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_AddAppRelationship_Response]>>
   */
  public fun addAppRelationship(request: CPublishedFile_AddAppRelationship_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_AddAppRelationship_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_AddAppRelationship_Response.Builder::class.java,
  "PublishedFile.AddAppRelationship#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_RemoveAppRelationship_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_RemoveAppRelationship_Response]>>
   */
  public fun removeAppRelationship(request: CPublishedFile_RemoveAppRelationship_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_RemoveAppRelationship_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_RemoveAppRelationship_Response.Builder::class.java,
  "PublishedFile.RemoveAppRelationship#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetAppRelationships_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetAppRelationships_Response]>>
   */
  public fun getAppRelationships(request: CPublishedFile_GetAppRelationships_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetAppRelationships_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetAppRelationships_Response.Builder::class.java,
  "PublishedFile.GetAppRelationships#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetAppRelationshipsBatched_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetAppRelationshipsBatched_Response]>>
   */
  public fun getAppRelationshipsBatched(request: CPublishedFile_GetAppRelationshipsBatched_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetAppRelationshipsBatched_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetAppRelationshipsBatched_Response.Builder::class.java,
  "PublishedFile.GetAppRelationshipsBatched#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_StartPlaytimeTracking_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_StartPlaytimeTracking_Response]>>
   */
  public fun startPlaytimeTracking(request: CPublishedFile_StartPlaytimeTracking_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_StartPlaytimeTracking_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_StartPlaytimeTracking_Response.Builder::class.java,
  "PublishedFile.StartPlaytimeTracking#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_StopPlaytimeTracking_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_StopPlaytimeTracking_Response]>>
   */
  public fun stopPlaytimeTracking(request: CPublishedFile_StopPlaytimeTracking_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_StopPlaytimeTracking_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_StopPlaytimeTracking_Response.Builder::class.java,
  "PublishedFile.StopPlaytimeTracking#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_StopPlaytimeTrackingForAllAppItems_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_StopPlaytimeTrackingForAllAppItems_Response]>>
   */
  public fun stopPlaytimeTrackingForAllAppItems(request: CPublishedFile_StopPlaytimeTrackingForAllAppItems_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_StopPlaytimeTrackingForAllAppItems_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_StopPlaytimeTrackingForAllAppItems_Response.Builder::class.java,
  "PublishedFile.StopPlaytimeTrackingForAllAppItems#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_SetPlaytimeForControllerConfigs_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_SetPlaytimeForControllerConfigs_Response]>>
   */
  public fun setPlaytimeForControllerConfigs(request: CPublishedFile_SetPlaytimeForControllerConfigs_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_SetPlaytimeForControllerConfigs_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_SetPlaytimeForControllerConfigs_Response.Builder::class.java,
  "PublishedFile.SetPlaytimeForControllerConfigs#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_AddChild_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_AddChild_Response]>>
   */
  public fun addChild(request: CPublishedFile_AddChild_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_AddChild_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_AddChild_Response.Builder::class.java,
  "PublishedFile.AddChild#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_RemoveChild_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_RemoveChild_Response]>>
   */
  public fun removeChild(request: CPublishedFile_RemoveChild_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_RemoveChild_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_RemoveChild_Response.Builder::class.java,
  "PublishedFile.RemoveChild#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_SetCollectionChildren_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_SetCollectionChildren_Response]>>
   */
  public fun setCollectionChildren(request: CPublishedFile_SetCollectionChildren_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_SetCollectionChildren_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_SetCollectionChildren_Response.Builder::class.java,
  "PublishedFile.SetCollectionChildren#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_SetSubscriptionListFromCollection_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_SetSubscriptionListFromCollection_Response]>>
   */
  public fun setSubscriptionListFromCollection(request: CPublishedFile_SetSubscriptionListFromCollection_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_SetSubscriptionListFromCollection_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_SetSubscriptionListFromCollection_Response.Builder::class.java,
  "PublishedFile.SetSubscriptionListFromCollection#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetUserVoteSummary_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetUserVoteSummary_Response]>>
   */
  public fun getUserVoteSummary(request: CPublishedFile_GetUserVoteSummary_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetUserVoteSummary_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetUserVoteSummary_Response.Builder::class.java,
  "PublishedFile.GetUserVoteSummary#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetItemChanges_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetItemChanges_Response]>>
   */
  public fun getItemChanges(request: CPublishedFile_GetItemChanges_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetItemChanges_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetItemChanges_Response.Builder::class.java,
  "PublishedFile.GetItemChanges#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_GetContentDescriptors_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_GetContentDescriptors_Response]>>
   */
  public fun getContentDescriptors(request: CPublishedFile_GetContentDescriptors_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_GetContentDescriptors_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_GetContentDescriptors_Response.Builder::class.java,
  "PublishedFile.GetContentDescriptors#1",
  request
  )

  /**
   * @param request The request.
   * @see [CPublishedFile_UpdateContentDescriptors_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CPublishedFile_UpdateContentDescriptors_Response]>>
   */
  public fun updateContentDescriptors(request: CPublishedFile_UpdateContentDescriptors_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesPublishedfileSteamclient.CPublishedFile_UpdateContentDescriptors_Response.Builder>> = unifiedMessages!!.sendMessage(
  CPublishedFile_UpdateContentDescriptors_Response.Builder::class.java,
  "PublishedFile.UpdateContentDescriptors#1",
  request
  )
}
