package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CClanChatRooms_GetClanChatRoomInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CClanChatRooms_GetClanChatRoomInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CClanChatRooms_SetClanChatRoomPrivate_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CClanChatRooms_SetClanChatRoomPrivate_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ClanChatRooms : UnifiedService {
  override val serviceName: String
    get() = "ClanChatRooms"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetClanChatRoomInfo" -> postResponseMsg<CClanChatRooms_GetClanChatRoomInfo_Response.Builder>(
          CClanChatRooms_GetClanChatRoomInfo_Response::class.java,
          packetMsg
          )
      "SetClanChatRoomPrivate" -> postResponseMsg<CClanChatRooms_SetClanChatRoomPrivate_Response.Builder>(
          CClanChatRooms_SetClanChatRoomPrivate_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CClanChatRooms_GetClanChatRoomInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClanChatRooms_GetClanChatRoomInfo_Response]>>
   */
  public fun getClanChatRoomInfo(request: CClanChatRooms_GetClanChatRoomInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CClanChatRooms_GetClanChatRoomInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClanChatRooms_GetClanChatRoomInfo_Response.Builder::class.java,
  "ClanChatRooms.GetClanChatRoomInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CClanChatRooms_SetClanChatRoomPrivate_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CClanChatRooms_SetClanChatRoomPrivate_Response]>>
   */
  public fun setClanChatRoomPrivate(request: CClanChatRooms_SetClanChatRoomPrivate_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CClanChatRooms_SetClanChatRoomPrivate_Response.Builder>> = unifiedMessages!!.sendMessage(
  CClanChatRooms_SetClanChatRoomPrivate_Response.Builder::class.java,
  "ClanChatRooms.SetClanChatRoomPrivate#1",
  request
  )
}
