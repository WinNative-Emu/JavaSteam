package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CDepotContentDetection_GetAllDetectedAppContent_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CDepotContentDetection_GetAllDetectedAppContent_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class DepotContentDetection : UnifiedService {
  override val serviceName: String
    get() = "DepotContentDetection"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetAllDetectedAppContent" -> postResponseMsg<CDepotContentDetection_GetAllDetectedAppContent_Response.Builder>(
          CDepotContentDetection_GetAllDetectedAppContent_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CDepotContentDetection_GetAllDetectedAppContent_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CDepotContentDetection_GetAllDetectedAppContent_Response]>>
   */
  public fun getAllDetectedAppContent(request: CDepotContentDetection_GetAllDetectedAppContent_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CDepotContentDetection_GetAllDetectedAppContent_Response.Builder>> = unifiedMessages!!.sendMessage(
  CDepotContentDetection_GetAllDetectedAppContent_Response.Builder::class.java,
  "DepotContentDetection.GetAllDetectedAppContent#1",
  request
  )
}
