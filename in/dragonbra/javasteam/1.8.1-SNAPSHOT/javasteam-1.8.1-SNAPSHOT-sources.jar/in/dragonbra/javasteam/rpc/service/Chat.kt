package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChat_RequestFriendPersonaStates_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChat_RequestFriendPersonaStates_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class Chat : UnifiedService {
  override val serviceName: String
    get() = "Chat"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "RequestFriendPersonaStates" -> postResponseMsg<CChat_RequestFriendPersonaStates_Response.Builder>(
          CChat_RequestFriendPersonaStates_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CChat_RequestFriendPersonaStates_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChat_RequestFriendPersonaStates_Response]>>
   */
  public fun requestFriendPersonaStates(request: CChat_RequestFriendPersonaStates_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChat_RequestFriendPersonaStates_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChat_RequestFriendPersonaStates_Response.Builder::class.java,
  "Chat.RequestFriendPersonaStates#1",
  request
  )
}
