package in.dragonbra.javasteam.enums;


public enum ECommunityPrivacy {

    Invalid(0),

    Private(1),

    FriendsOnly(2),

    Public(3),

    ;

    private final int code;

    ECommunityPrivacy(int code) {
        this.code = code;
    }

    public int code() {
        return this.code;
    }

    public static ECommunityPrivacy from(int code) {
        for (ECommunityPrivacy e : ECommunityPrivacy.values()) {
            if (e.code == code) {
                return e;
            }
        }
        return null;
    }
}
