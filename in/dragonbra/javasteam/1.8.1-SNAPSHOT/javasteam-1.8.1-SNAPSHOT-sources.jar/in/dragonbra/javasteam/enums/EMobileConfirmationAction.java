package in.dragonbra.javasteam.enums;


public enum EMobileConfirmationAction {

    None(0),

    Allow(1),

    Cancel(2),

    ;

    private final int code;

    EMobileConfirmationAction(int code) {
        this.code = code;
    }

    public int code() {
        return this.code;
    }

    public static EMobileConfirmationAction from(int code) {
        for (EMobileConfirmationAction e : EMobileConfirmationAction.values()) {
            if (e.code == code) {
                return e;
            }
        }
        return null;
    }
}
