package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ParentalLock_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ParentalSettingsChange_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_ParentalUnlock_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesParentalSteamclient.CParental_PlaytimeUsed_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ParentalClient : UnifiedService {
  override val serviceName: String
    get() = "ParentalClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifySettingsChange" -> postNotificationMsg<CParental_ParentalSettingsChange_Notification.Builder>(
          CParental_ParentalSettingsChange_Notification::class.java,
          packetMsg
          )
      "NotifyUnlock" -> postNotificationMsg<CParental_ParentalUnlock_Notification.Builder>(
          CParental_ParentalUnlock_Notification::class.java,
          packetMsg
          )
      "NotifyLock" -> postNotificationMsg<CParental_ParentalLock_Notification.Builder>(
          CParental_ParentalLock_Notification::class.java,
          packetMsg
          )
      "NotifyPlaytimeUsed" -> postNotificationMsg<CParental_PlaytimeUsed_Notification.Builder>(
          CParental_PlaytimeUsed_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CParental_ParentalSettingsChange_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifySettingsChange(request: CParental_ParentalSettingsChange_Notification) {
    unifiedMessages!!.sendNotification<CParental_ParentalSettingsChange_Notification.Builder>(
        "ParentalClient.NotifySettingsChange#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CParental_ParentalUnlock_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyUnlock(request: CParental_ParentalUnlock_Notification) {
    unifiedMessages!!.sendNotification<CParental_ParentalUnlock_Notification.Builder>(
        "ParentalClient.NotifyUnlock#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CParental_ParentalLock_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyLock(request: CParental_ParentalLock_Notification) {
    unifiedMessages!!.sendNotification<CParental_ParentalLock_Notification.Builder>(
        "ParentalClient.NotifyLock#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CParental_PlaytimeUsed_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyPlaytimeUsed(request: CParental_PlaytimeUsed_Notification) {
    unifiedMessages!!.sendNotification<CParental_PlaytimeUsed_Notification.Builder>(
        "ParentalClient.NotifyPlaytimeUsed#1",
        request
        )
  }
}
