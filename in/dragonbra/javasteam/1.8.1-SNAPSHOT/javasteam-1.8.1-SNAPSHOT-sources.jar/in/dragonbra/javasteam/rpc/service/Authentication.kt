package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_AccessToken_GenerateForApp_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_AccessToken_GenerateForApp_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_BeginAuthSessionViaCredentials_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_BeginAuthSessionViaCredentials_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_BeginAuthSessionViaQR_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_BeginAuthSessionViaQR_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionRiskInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionRiskInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionsForAccount_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionsForAccount_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetPasswordRSAPublicKey_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_GetPasswordRSAPublicKey_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_NotifyRiskQuizResults_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_PollAuthSessionStatus_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_PollAuthSessionStatus_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_RefreshToken_Enumerate_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_RefreshToken_Enumerate_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_RefreshToken_Revoke_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_RefreshToken_Revoke_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_Token_Revoke_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_Token_Revoke_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_UpdateAuthSessionWithMobileConfirmation_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_UpdateAuthSessionWithMobileConfirmation_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_UpdateAuthSessionWithSteamGuardCode_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthentication_UpdateAuthSessionWithSteamGuardCode_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class Authentication : UnifiedService {
  override val serviceName: String
    get() = "Authentication"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetPasswordRSAPublicKey" -> postResponseMsg<CAuthentication_GetPasswordRSAPublicKey_Response.Builder>(
          CAuthentication_GetPasswordRSAPublicKey_Response::class.java,
          packetMsg
          )
      "BeginAuthSessionViaQR" -> postResponseMsg<CAuthentication_BeginAuthSessionViaQR_Response.Builder>(
          CAuthentication_BeginAuthSessionViaQR_Response::class.java,
          packetMsg
          )
      "BeginAuthSessionViaCredentials" -> postResponseMsg<CAuthentication_BeginAuthSessionViaCredentials_Response.Builder>(
          CAuthentication_BeginAuthSessionViaCredentials_Response::class.java,
          packetMsg
          )
      "PollAuthSessionStatus" -> postResponseMsg<CAuthentication_PollAuthSessionStatus_Response.Builder>(
          CAuthentication_PollAuthSessionStatus_Response::class.java,
          packetMsg
          )
      "GetAuthSessionInfo" -> postResponseMsg<CAuthentication_GetAuthSessionInfo_Response.Builder>(
          CAuthentication_GetAuthSessionInfo_Response::class.java,
          packetMsg
          )
      "GetAuthSessionRiskInfo" -> postResponseMsg<CAuthentication_GetAuthSessionRiskInfo_Response.Builder>(
          CAuthentication_GetAuthSessionRiskInfo_Response::class.java,
          packetMsg
          )
      "UpdateAuthSessionWithMobileConfirmation" -> postResponseMsg<CAuthentication_UpdateAuthSessionWithMobileConfirmation_Response.Builder>(
          CAuthentication_UpdateAuthSessionWithMobileConfirmation_Response::class.java,
          packetMsg
          )
      "UpdateAuthSessionWithSteamGuardCode" -> postResponseMsg<CAuthentication_UpdateAuthSessionWithSteamGuardCode_Response.Builder>(
          CAuthentication_UpdateAuthSessionWithSteamGuardCode_Response::class.java,
          packetMsg
          )
      "GenerateAccessTokenForApp" -> postResponseMsg<CAuthentication_AccessToken_GenerateForApp_Response.Builder>(
          CAuthentication_AccessToken_GenerateForApp_Response::class.java,
          packetMsg
          )
      "EnumerateTokens" -> postResponseMsg<CAuthentication_RefreshToken_Enumerate_Response.Builder>(
          CAuthentication_RefreshToken_Enumerate_Response::class.java,
          packetMsg
          )
      "GetAuthSessionsForAccount" -> postResponseMsg<CAuthentication_GetAuthSessionsForAccount_Response.Builder>(
          CAuthentication_GetAuthSessionsForAccount_Response::class.java,
          packetMsg
          )
      "RevokeToken" -> postResponseMsg<CAuthentication_Token_Revoke_Response.Builder>(
          CAuthentication_Token_Revoke_Response::class.java,
          packetMsg
          )
      "RevokeRefreshToken" -> postResponseMsg<CAuthentication_RefreshToken_Revoke_Response.Builder>(
          CAuthentication_RefreshToken_Revoke_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyRiskQuizResults" -> postNotificationMsg<CAuthentication_NotifyRiskQuizResults_Notification.Builder>(
          CAuthentication_NotifyRiskQuizResults_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CAuthentication_GetPasswordRSAPublicKey_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_GetPasswordRSAPublicKey_Response]>>
   */
  public fun getPasswordRSAPublicKey(request: CAuthentication_GetPasswordRSAPublicKey_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_GetPasswordRSAPublicKey_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_GetPasswordRSAPublicKey_Response.Builder::class.java,
  "Authentication.GetPasswordRSAPublicKey#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_BeginAuthSessionViaQR_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_BeginAuthSessionViaQR_Response]>>
   */
  public fun beginAuthSessionViaQR(request: CAuthentication_BeginAuthSessionViaQR_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_BeginAuthSessionViaQR_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_BeginAuthSessionViaQR_Response.Builder::class.java,
  "Authentication.BeginAuthSessionViaQR#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_BeginAuthSessionViaCredentials_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_BeginAuthSessionViaCredentials_Response]>>
   */
  public fun beginAuthSessionViaCredentials(request: CAuthentication_BeginAuthSessionViaCredentials_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_BeginAuthSessionViaCredentials_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_BeginAuthSessionViaCredentials_Response.Builder::class.java,
  "Authentication.BeginAuthSessionViaCredentials#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_PollAuthSessionStatus_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_PollAuthSessionStatus_Response]>>
   */
  public fun pollAuthSessionStatus(request: CAuthentication_PollAuthSessionStatus_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_PollAuthSessionStatus_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_PollAuthSessionStatus_Response.Builder::class.java,
  "Authentication.PollAuthSessionStatus#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_GetAuthSessionInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_GetAuthSessionInfo_Response]>>
   */
  public fun getAuthSessionInfo(request: CAuthentication_GetAuthSessionInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_GetAuthSessionInfo_Response.Builder::class.java,
  "Authentication.GetAuthSessionInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_GetAuthSessionRiskInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_GetAuthSessionRiskInfo_Response]>>
   */
  public fun getAuthSessionRiskInfo(request: CAuthentication_GetAuthSessionRiskInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionRiskInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_GetAuthSessionRiskInfo_Response.Builder::class.java,
  "Authentication.GetAuthSessionRiskInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_NotifyRiskQuizResults_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyRiskQuizResults(request: CAuthentication_NotifyRiskQuizResults_Notification) {
    unifiedMessages!!.sendNotification<CAuthentication_NotifyRiskQuizResults_Notification.Builder>(
        "Authentication.NotifyRiskQuizResults#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CAuthentication_UpdateAuthSessionWithMobileConfirmation_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_UpdateAuthSessionWithMobileConfirmation_Response]>>
   */
  public fun updateAuthSessionWithMobileConfirmation(request: CAuthentication_UpdateAuthSessionWithMobileConfirmation_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_UpdateAuthSessionWithMobileConfirmation_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_UpdateAuthSessionWithMobileConfirmation_Response.Builder::class.java,
  "Authentication.UpdateAuthSessionWithMobileConfirmation#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_UpdateAuthSessionWithSteamGuardCode_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_UpdateAuthSessionWithSteamGuardCode_Response]>>
   */
  public fun updateAuthSessionWithSteamGuardCode(request: CAuthentication_UpdateAuthSessionWithSteamGuardCode_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_UpdateAuthSessionWithSteamGuardCode_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_UpdateAuthSessionWithSteamGuardCode_Response.Builder::class.java,
  "Authentication.UpdateAuthSessionWithSteamGuardCode#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_AccessToken_GenerateForApp_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_AccessToken_GenerateForApp_Response]>>
   */
  public fun generateAccessTokenForApp(request: CAuthentication_AccessToken_GenerateForApp_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_AccessToken_GenerateForApp_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_AccessToken_GenerateForApp_Response.Builder::class.java,
  "Authentication.GenerateAccessTokenForApp#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_RefreshToken_Enumerate_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_RefreshToken_Enumerate_Response]>>
   */
  public fun enumerateTokens(request: CAuthentication_RefreshToken_Enumerate_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_RefreshToken_Enumerate_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_RefreshToken_Enumerate_Response.Builder::class.java,
  "Authentication.EnumerateTokens#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_GetAuthSessionsForAccount_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_GetAuthSessionsForAccount_Response]>>
   */
  public fun getAuthSessionsForAccount(request: CAuthentication_GetAuthSessionsForAccount_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_GetAuthSessionsForAccount_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_GetAuthSessionsForAccount_Response.Builder::class.java,
  "Authentication.GetAuthSessionsForAccount#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_Token_Revoke_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_Token_Revoke_Response]>>
   */
  public fun revokeToken(request: CAuthentication_Token_Revoke_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_Token_Revoke_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_Token_Revoke_Response.Builder::class.java,
  "Authentication.RevokeToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthentication_RefreshToken_Revoke_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthentication_RefreshToken_Revoke_Response]>>
   */
  public fun revokeRefreshToken(request: CAuthentication_RefreshToken_Revoke_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthentication_RefreshToken_Revoke_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthentication_RefreshToken_Revoke_Response.Builder::class.java,
  "Authentication.RevokeRefreshToken#1",
  request
  )
}
