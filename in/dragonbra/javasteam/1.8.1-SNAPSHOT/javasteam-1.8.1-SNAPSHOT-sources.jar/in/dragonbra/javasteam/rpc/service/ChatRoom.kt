package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_AckChatMessage_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_AddRoleToUser_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_AddRoleToUser_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateChatRoom_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateChatRoom_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateInviteLink_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateInviteLink_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateRole_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_CreateRole_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteChatMessages_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteChatMessages_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteChatRoom_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteChatRoom_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteInviteLink_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteInviteLink_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteRoleFromUser_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteRoleFromUser_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteRole_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_DeleteRole_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_EndMiniGameForChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_EndMiniGameForChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetBanList_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetBanList_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetChatRoomGroupState_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetChatRoomGroupState_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteLinkInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteLinkInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteLinksForGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteLinksForGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteList_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetInviteList_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetMessageHistory_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetMessageHistory_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetMessageReactionReactors_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetMessageReactionReactors_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetMyChatRoomGroups_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetMyChatRoomGroups_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetRoleActions_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetRoleActions_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetRolesForUser_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetRolesForUser_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetRoles_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_GetRoles_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_InviteFriendToChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_InviteFriendToChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_JoinChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_JoinChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_JoinMiniGameForChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_JoinMiniGameForChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_JoinVoiceChat_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_JoinVoiceChat_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_KickUser_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_KickUser_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_LeaveChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_LeaveChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_LeaveVoiceChat_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_LeaveVoiceChat_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_MuteUser_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_MuteUser_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RenameChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RenameChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RenameChatRoom_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RenameChatRoom_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RenameRole_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RenameRole_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReorderChatRoom_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReorderChatRoom_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReorderRole_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReorderRole_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReplaceRoleActions_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReplaceRoleActions_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReportMessage_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ReportMessage_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ResolveReport_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_ResolveReport_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RevokeInvite_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_RevokeInvite_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SaveChatRoomGroup_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SaveChatRoomGroup_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SearchMembers_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SearchMembers_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SendChatMessage_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SendChatMessage_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetAppChatRoomGroupForceActive_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetAppChatRoomGroupForceActive_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetAppChatRoomGroupStopForceActive_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupAvatar_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupAvatar_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupTagline_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupTagline_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupWatchingBroadcast_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupWatchingBroadcast_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetSessionActiveChatRoomGroups_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetSessionActiveChatRoomGroups_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetUserBanState_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetUserBanState_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetUserChatGroupPreferences_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_SetUserChatGroupPreferences_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_UpdateMemberListView_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_UpdateMessageReaction_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesChatSteamclient.CChatRoom_UpdateMessageReaction_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ChatRoom : UnifiedService {
  override val serviceName: String
    get() = "ChatRoom"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "CreateChatRoomGroup" -> postResponseMsg<CChatRoom_CreateChatRoomGroup_Response.Builder>(
          CChatRoom_CreateChatRoomGroup_Response::class.java,
          packetMsg
          )
      "SaveChatRoomGroup" -> postResponseMsg<CChatRoom_SaveChatRoomGroup_Response.Builder>(
          CChatRoom_SaveChatRoomGroup_Response::class.java,
          packetMsg
          )
      "RenameChatRoomGroup" -> postResponseMsg<CChatRoom_RenameChatRoomGroup_Response.Builder>(
          CChatRoom_RenameChatRoomGroup_Response::class.java,
          packetMsg
          )
      "SetChatRoomGroupTagline" -> postResponseMsg<CChatRoom_SetChatRoomGroupTagline_Response.Builder>(
          CChatRoom_SetChatRoomGroupTagline_Response::class.java,
          packetMsg
          )
      "SetChatRoomGroupAvatar" -> postResponseMsg<CChatRoom_SetChatRoomGroupAvatar_Response.Builder>(
          CChatRoom_SetChatRoomGroupAvatar_Response::class.java,
          packetMsg
          )
      "SetChatRoomGroupWatchingBroadcast" -> postResponseMsg<CChatRoom_SetChatRoomGroupWatchingBroadcast_Response.Builder>(
          CChatRoom_SetChatRoomGroupWatchingBroadcast_Response::class.java,
          packetMsg
          )
      "JoinMiniGameForChatRoomGroup" -> postResponseMsg<CChatRoom_JoinMiniGameForChatRoomGroup_Response.Builder>(
          CChatRoom_JoinMiniGameForChatRoomGroup_Response::class.java,
          packetMsg
          )
      "EndMiniGameForChatRoomGroup" -> postResponseMsg<CChatRoom_EndMiniGameForChatRoomGroup_Response.Builder>(
          CChatRoom_EndMiniGameForChatRoomGroup_Response::class.java,
          packetMsg
          )
      "MuteUserInGroup" -> postResponseMsg<CChatRoom_MuteUser_Response.Builder>(
          CChatRoom_MuteUser_Response::class.java,
          packetMsg
          )
      "KickUserFromGroup" -> postResponseMsg<CChatRoom_KickUser_Response.Builder>(
          CChatRoom_KickUser_Response::class.java,
          packetMsg
          )
      "SetUserBanState" -> postResponseMsg<CChatRoom_SetUserBanState_Response.Builder>(
          CChatRoom_SetUserBanState_Response::class.java,
          packetMsg
          )
      "RevokeInviteToGroup" -> postResponseMsg<CChatRoom_RevokeInvite_Response.Builder>(
          CChatRoom_RevokeInvite_Response::class.java,
          packetMsg
          )
      "CreateRole" -> postResponseMsg<CChatRoom_CreateRole_Response.Builder>(
          CChatRoom_CreateRole_Response::class.java,
          packetMsg
          )
      "GetRoles" -> postResponseMsg<CChatRoom_GetRoles_Response.Builder>(
          CChatRoom_GetRoles_Response::class.java,
          packetMsg
          )
      "RenameRole" -> postResponseMsg<CChatRoom_RenameRole_Response.Builder>(
          CChatRoom_RenameRole_Response::class.java,
          packetMsg
          )
      "ReorderRole" -> postResponseMsg<CChatRoom_ReorderRole_Response.Builder>(
          CChatRoom_ReorderRole_Response::class.java,
          packetMsg
          )
      "DeleteRole" -> postResponseMsg<CChatRoom_DeleteRole_Response.Builder>(
          CChatRoom_DeleteRole_Response::class.java,
          packetMsg
          )
      "GetRoleActions" -> postResponseMsg<CChatRoom_GetRoleActions_Response.Builder>(
          CChatRoom_GetRoleActions_Response::class.java,
          packetMsg
          )
      "ReplaceRoleActions" -> postResponseMsg<CChatRoom_ReplaceRoleActions_Response.Builder>(
          CChatRoom_ReplaceRoleActions_Response::class.java,
          packetMsg
          )
      "AddRoleToUser" -> postResponseMsg<CChatRoom_AddRoleToUser_Response.Builder>(
          CChatRoom_AddRoleToUser_Response::class.java,
          packetMsg
          )
      "GetRolesForUser" -> postResponseMsg<CChatRoom_GetRolesForUser_Response.Builder>(
          CChatRoom_GetRolesForUser_Response::class.java,
          packetMsg
          )
      "DeleteRoleFromUser" -> postResponseMsg<CChatRoom_DeleteRoleFromUser_Response.Builder>(
          CChatRoom_DeleteRoleFromUser_Response::class.java,
          packetMsg
          )
      "JoinChatRoomGroup" -> postResponseMsg<CChatRoom_JoinChatRoomGroup_Response.Builder>(
          CChatRoom_JoinChatRoomGroup_Response::class.java,
          packetMsg
          )
      "InviteFriendToChatRoomGroup" -> postResponseMsg<CChatRoom_InviteFriendToChatRoomGroup_Response.Builder>(
          CChatRoom_InviteFriendToChatRoomGroup_Response::class.java,
          packetMsg
          )
      "LeaveChatRoomGroup" -> postResponseMsg<CChatRoom_LeaveChatRoomGroup_Response.Builder>(
          CChatRoom_LeaveChatRoomGroup_Response::class.java,
          packetMsg
          )
      "CreateChatRoom" -> postResponseMsg<CChatRoom_CreateChatRoom_Response.Builder>(
          CChatRoom_CreateChatRoom_Response::class.java,
          packetMsg
          )
      "DeleteChatRoom" -> postResponseMsg<CChatRoom_DeleteChatRoom_Response.Builder>(
          CChatRoom_DeleteChatRoom_Response::class.java,
          packetMsg
          )
      "RenameChatRoom" -> postResponseMsg<CChatRoom_RenameChatRoom_Response.Builder>(
          CChatRoom_RenameChatRoom_Response::class.java,
          packetMsg
          )
      "ReorderChatRoom" -> postResponseMsg<CChatRoom_ReorderChatRoom_Response.Builder>(
          CChatRoom_ReorderChatRoom_Response::class.java,
          packetMsg
          )
      "SendChatMessage" -> postResponseMsg<CChatRoom_SendChatMessage_Response.Builder>(
          CChatRoom_SendChatMessage_Response::class.java,
          packetMsg
          )
      "JoinVoiceChat" -> postResponseMsg<CChatRoom_JoinVoiceChat_Response.Builder>(
          CChatRoom_JoinVoiceChat_Response::class.java,
          packetMsg
          )
      "LeaveVoiceChat" -> postResponseMsg<CChatRoom_LeaveVoiceChat_Response.Builder>(
          CChatRoom_LeaveVoiceChat_Response::class.java,
          packetMsg
          )
      "GetMessageHistory" -> postResponseMsg<CChatRoom_GetMessageHistory_Response.Builder>(
          CChatRoom_GetMessageHistory_Response::class.java,
          packetMsg
          )
      "GetMyChatRoomGroups" -> postResponseMsg<CChatRoom_GetMyChatRoomGroups_Response.Builder>(
          CChatRoom_GetMyChatRoomGroups_Response::class.java,
          packetMsg
          )
      "GetChatRoomGroupState" -> postResponseMsg<CChatRoom_GetChatRoomGroupState_Response.Builder>(
          CChatRoom_GetChatRoomGroupState_Response::class.java,
          packetMsg
          )
      "SetAppChatRoomGroupForceActive" -> postResponseMsg<CChatRoom_SetAppChatRoomGroupForceActive_Response.Builder>(
          CChatRoom_SetAppChatRoomGroupForceActive_Response::class.java,
          packetMsg
          )
      "CreateInviteLink" -> postResponseMsg<CChatRoom_CreateInviteLink_Response.Builder>(
          CChatRoom_CreateInviteLink_Response::class.java,
          packetMsg
          )
      "GetInviteLinkInfo" -> postResponseMsg<CChatRoom_GetInviteLinkInfo_Response.Builder>(
          CChatRoom_GetInviteLinkInfo_Response::class.java,
          packetMsg
          )
      "GetInviteInfo" -> postResponseMsg<CChatRoom_GetInviteInfo_Response.Builder>(
          CChatRoom_GetInviteInfo_Response::class.java,
          packetMsg
          )
      "GetInviteLinksForGroup" -> postResponseMsg<CChatRoom_GetInviteLinksForGroup_Response.Builder>(
          CChatRoom_GetInviteLinksForGroup_Response::class.java,
          packetMsg
          )
      "GetBanList" -> postResponseMsg<CChatRoom_GetBanList_Response.Builder>(
          CChatRoom_GetBanList_Response::class.java,
          packetMsg
          )
      "GetInviteList" -> postResponseMsg<CChatRoom_GetInviteList_Response.Builder>(
          CChatRoom_GetInviteList_Response::class.java,
          packetMsg
          )
      "DeleteInviteLink" -> postResponseMsg<CChatRoom_DeleteInviteLink_Response.Builder>(
          CChatRoom_DeleteInviteLink_Response::class.java,
          packetMsg
          )
      "SetSessionActiveChatRoomGroups" -> postResponseMsg<CChatRoom_SetSessionActiveChatRoomGroups_Response.Builder>(
          CChatRoom_SetSessionActiveChatRoomGroups_Response::class.java,
          packetMsg
          )
      "SetUserChatGroupPreferences" -> postResponseMsg<CChatRoom_SetUserChatGroupPreferences_Response.Builder>(
          CChatRoom_SetUserChatGroupPreferences_Response::class.java,
          packetMsg
          )
      "DeleteChatMessages" -> postResponseMsg<CChatRoom_DeleteChatMessages_Response.Builder>(
          CChatRoom_DeleteChatMessages_Response::class.java,
          packetMsg
          )
      "SearchMembers" -> postResponseMsg<CChatRoom_SearchMembers_Response.Builder>(
          CChatRoom_SearchMembers_Response::class.java,
          packetMsg
          )
      "UpdateMessageReaction" -> postResponseMsg<CChatRoom_UpdateMessageReaction_Response.Builder>(
          CChatRoom_UpdateMessageReaction_Response::class.java,
          packetMsg
          )
      "GetMessageReactionReactors" -> postResponseMsg<CChatRoom_GetMessageReactionReactors_Response.Builder>(
          CChatRoom_GetMessageReactionReactors_Response::class.java,
          packetMsg
          )
      "ReportMessage" -> postResponseMsg<CChatRoom_ReportMessage_Response.Builder>(
          CChatRoom_ReportMessage_Response::class.java,
          packetMsg
          )
      "ResolveReport" -> postResponseMsg<CChatRoom_ResolveReport_Response.Builder>(
          CChatRoom_ResolveReport_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "SetAppChatRoomGroupStopForceActive" -> postNotificationMsg<CChatRoom_SetAppChatRoomGroupStopForceActive_Notification.Builder>(
          CChatRoom_SetAppChatRoomGroupStopForceActive_Notification::class.java,
          packetMsg
          )
      "AckChatMessage" -> postNotificationMsg<CChatRoom_AckChatMessage_Notification.Builder>(
          CChatRoom_AckChatMessage_Notification::class.java,
          packetMsg
          )
      "UpdateMemberListView" -> postNotificationMsg<CChatRoom_UpdateMemberListView_Notification.Builder>(
          CChatRoom_UpdateMemberListView_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CChatRoom_CreateChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_CreateChatRoomGroup_Response]>>
   */
  public fun createChatRoomGroup(request: CChatRoom_CreateChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_CreateChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_CreateChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.CreateChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SaveChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SaveChatRoomGroup_Response]>>
   */
  public fun saveChatRoomGroup(request: CChatRoom_SaveChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SaveChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SaveChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.SaveChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_RenameChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_RenameChatRoomGroup_Response]>>
   */
  public fun renameChatRoomGroup(request: CChatRoom_RenameChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_RenameChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_RenameChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.RenameChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetChatRoomGroupTagline_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SetChatRoomGroupTagline_Response]>>
   */
  public fun setChatRoomGroupTagline(request: CChatRoom_SetChatRoomGroupTagline_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupTagline_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SetChatRoomGroupTagline_Response.Builder::class.java,
  "ChatRoom.SetChatRoomGroupTagline#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetChatRoomGroupAvatar_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SetChatRoomGroupAvatar_Response]>>
   */
  public fun setChatRoomGroupAvatar(request: CChatRoom_SetChatRoomGroupAvatar_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupAvatar_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SetChatRoomGroupAvatar_Response.Builder::class.java,
  "ChatRoom.SetChatRoomGroupAvatar#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetChatRoomGroupWatchingBroadcast_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SetChatRoomGroupWatchingBroadcast_Response]>>
   */
  public fun setChatRoomGroupWatchingBroadcast(request: CChatRoom_SetChatRoomGroupWatchingBroadcast_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SetChatRoomGroupWatchingBroadcast_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SetChatRoomGroupWatchingBroadcast_Response.Builder::class.java,
  "ChatRoom.SetChatRoomGroupWatchingBroadcast#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_JoinMiniGameForChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_JoinMiniGameForChatRoomGroup_Response]>>
   */
  public fun joinMiniGameForChatRoomGroup(request: CChatRoom_JoinMiniGameForChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_JoinMiniGameForChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_JoinMiniGameForChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.JoinMiniGameForChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_EndMiniGameForChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_EndMiniGameForChatRoomGroup_Response]>>
   */
  public fun endMiniGameForChatRoomGroup(request: CChatRoom_EndMiniGameForChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_EndMiniGameForChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_EndMiniGameForChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.EndMiniGameForChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_MuteUser_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_MuteUser_Response]>>
   */
  public fun muteUserInGroup(request: CChatRoom_MuteUser_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_MuteUser_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_MuteUser_Response.Builder::class.java,
  "ChatRoom.MuteUserInGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_KickUser_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_KickUser_Response]>>
   */
  public fun kickUserFromGroup(request: CChatRoom_KickUser_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_KickUser_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_KickUser_Response.Builder::class.java,
  "ChatRoom.KickUserFromGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetUserBanState_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SetUserBanState_Response]>>
   */
  public fun setUserBanState(request: CChatRoom_SetUserBanState_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SetUserBanState_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SetUserBanState_Response.Builder::class.java,
  "ChatRoom.SetUserBanState#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_RevokeInvite_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_RevokeInvite_Response]>>
   */
  public fun revokeInviteToGroup(request: CChatRoom_RevokeInvite_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_RevokeInvite_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_RevokeInvite_Response.Builder::class.java,
  "ChatRoom.RevokeInviteToGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_CreateRole_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_CreateRole_Response]>>
   */
  public fun createRole(request: CChatRoom_CreateRole_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_CreateRole_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_CreateRole_Response.Builder::class.java,
  "ChatRoom.CreateRole#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetRoles_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetRoles_Response]>>
   */
  public fun getRoles(request: CChatRoom_GetRoles_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetRoles_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetRoles_Response.Builder::class.java,
  "ChatRoom.GetRoles#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_RenameRole_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_RenameRole_Response]>>
   */
  public fun renameRole(request: CChatRoom_RenameRole_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_RenameRole_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_RenameRole_Response.Builder::class.java,
  "ChatRoom.RenameRole#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_ReorderRole_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_ReorderRole_Response]>>
   */
  public fun reorderRole(request: CChatRoom_ReorderRole_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_ReorderRole_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_ReorderRole_Response.Builder::class.java,
  "ChatRoom.ReorderRole#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_DeleteRole_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_DeleteRole_Response]>>
   */
  public fun deleteRole(request: CChatRoom_DeleteRole_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_DeleteRole_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_DeleteRole_Response.Builder::class.java,
  "ChatRoom.DeleteRole#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetRoleActions_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetRoleActions_Response]>>
   */
  public fun getRoleActions(request: CChatRoom_GetRoleActions_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetRoleActions_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetRoleActions_Response.Builder::class.java,
  "ChatRoom.GetRoleActions#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_ReplaceRoleActions_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_ReplaceRoleActions_Response]>>
   */
  public fun replaceRoleActions(request: CChatRoom_ReplaceRoleActions_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_ReplaceRoleActions_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_ReplaceRoleActions_Response.Builder::class.java,
  "ChatRoom.ReplaceRoleActions#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_AddRoleToUser_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_AddRoleToUser_Response]>>
   */
  public fun addRoleToUser(request: CChatRoom_AddRoleToUser_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_AddRoleToUser_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_AddRoleToUser_Response.Builder::class.java,
  "ChatRoom.AddRoleToUser#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetRolesForUser_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetRolesForUser_Response]>>
   */
  public fun getRolesForUser(request: CChatRoom_GetRolesForUser_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetRolesForUser_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetRolesForUser_Response.Builder::class.java,
  "ChatRoom.GetRolesForUser#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_DeleteRoleFromUser_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_DeleteRoleFromUser_Response]>>
   */
  public fun deleteRoleFromUser(request: CChatRoom_DeleteRoleFromUser_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_DeleteRoleFromUser_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_DeleteRoleFromUser_Response.Builder::class.java,
  "ChatRoom.DeleteRoleFromUser#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_JoinChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_JoinChatRoomGroup_Response]>>
   */
  public fun joinChatRoomGroup(request: CChatRoom_JoinChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_JoinChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_JoinChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.JoinChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_InviteFriendToChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_InviteFriendToChatRoomGroup_Response]>>
   */
  public fun inviteFriendToChatRoomGroup(request: CChatRoom_InviteFriendToChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_InviteFriendToChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_InviteFriendToChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.InviteFriendToChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_LeaveChatRoomGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_LeaveChatRoomGroup_Response]>>
   */
  public fun leaveChatRoomGroup(request: CChatRoom_LeaveChatRoomGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_LeaveChatRoomGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_LeaveChatRoomGroup_Response.Builder::class.java,
  "ChatRoom.LeaveChatRoomGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_CreateChatRoom_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_CreateChatRoom_Response]>>
   */
  public fun createChatRoom(request: CChatRoom_CreateChatRoom_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_CreateChatRoom_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_CreateChatRoom_Response.Builder::class.java,
  "ChatRoom.CreateChatRoom#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_DeleteChatRoom_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_DeleteChatRoom_Response]>>
   */
  public fun deleteChatRoom(request: CChatRoom_DeleteChatRoom_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_DeleteChatRoom_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_DeleteChatRoom_Response.Builder::class.java,
  "ChatRoom.DeleteChatRoom#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_RenameChatRoom_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_RenameChatRoom_Response]>>
   */
  public fun renameChatRoom(request: CChatRoom_RenameChatRoom_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_RenameChatRoom_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_RenameChatRoom_Response.Builder::class.java,
  "ChatRoom.RenameChatRoom#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_ReorderChatRoom_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_ReorderChatRoom_Response]>>
   */
  public fun reorderChatRoom(request: CChatRoom_ReorderChatRoom_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_ReorderChatRoom_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_ReorderChatRoom_Response.Builder::class.java,
  "ChatRoom.ReorderChatRoom#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SendChatMessage_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SendChatMessage_Response]>>
   */
  public fun sendChatMessage(request: CChatRoom_SendChatMessage_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SendChatMessage_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SendChatMessage_Response.Builder::class.java,
  "ChatRoom.SendChatMessage#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_JoinVoiceChat_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_JoinVoiceChat_Response]>>
   */
  public fun joinVoiceChat(request: CChatRoom_JoinVoiceChat_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_JoinVoiceChat_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_JoinVoiceChat_Response.Builder::class.java,
  "ChatRoom.JoinVoiceChat#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_LeaveVoiceChat_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_LeaveVoiceChat_Response]>>
   */
  public fun leaveVoiceChat(request: CChatRoom_LeaveVoiceChat_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_LeaveVoiceChat_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_LeaveVoiceChat_Response.Builder::class.java,
  "ChatRoom.LeaveVoiceChat#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetMessageHistory_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetMessageHistory_Response]>>
   */
  public fun getMessageHistory(request: CChatRoom_GetMessageHistory_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetMessageHistory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetMessageHistory_Response.Builder::class.java,
  "ChatRoom.GetMessageHistory#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetMyChatRoomGroups_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetMyChatRoomGroups_Response]>>
   */
  public fun getMyChatRoomGroups(request: CChatRoom_GetMyChatRoomGroups_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetMyChatRoomGroups_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetMyChatRoomGroups_Response.Builder::class.java,
  "ChatRoom.GetMyChatRoomGroups#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetChatRoomGroupState_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetChatRoomGroupState_Response]>>
   */
  public fun getChatRoomGroupState(request: CChatRoom_GetChatRoomGroupState_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetChatRoomGroupState_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetChatRoomGroupState_Response.Builder::class.java,
  "ChatRoom.GetChatRoomGroupState#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetAppChatRoomGroupForceActive_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SetAppChatRoomGroupForceActive_Response]>>
   */
  public fun setAppChatRoomGroupForceActive(request: CChatRoom_SetAppChatRoomGroupForceActive_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SetAppChatRoomGroupForceActive_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SetAppChatRoomGroupForceActive_Response.Builder::class.java,
  "ChatRoom.SetAppChatRoomGroupForceActive#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetAppChatRoomGroupStopForceActive_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun setAppChatRoomGroupStopForceActive(request: CChatRoom_SetAppChatRoomGroupStopForceActive_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_SetAppChatRoomGroupStopForceActive_Notification.Builder>(
        "ChatRoom.SetAppChatRoomGroupStopForceActive#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_AckChatMessage_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun ackChatMessage(request: CChatRoom_AckChatMessage_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_AckChatMessage_Notification.Builder>(
        "ChatRoom.AckChatMessage#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_CreateInviteLink_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_CreateInviteLink_Response]>>
   */
  public fun createInviteLink(request: CChatRoom_CreateInviteLink_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_CreateInviteLink_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_CreateInviteLink_Response.Builder::class.java,
  "ChatRoom.CreateInviteLink#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetInviteLinkInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetInviteLinkInfo_Response]>>
   */
  public fun getInviteLinkInfo(request: CChatRoom_GetInviteLinkInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetInviteLinkInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetInviteLinkInfo_Response.Builder::class.java,
  "ChatRoom.GetInviteLinkInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetInviteInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetInviteInfo_Response]>>
   */
  public fun getInviteInfo(request: CChatRoom_GetInviteInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetInviteInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetInviteInfo_Response.Builder::class.java,
  "ChatRoom.GetInviteInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetInviteLinksForGroup_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetInviteLinksForGroup_Response]>>
   */
  public fun getInviteLinksForGroup(request: CChatRoom_GetInviteLinksForGroup_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetInviteLinksForGroup_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetInviteLinksForGroup_Response.Builder::class.java,
  "ChatRoom.GetInviteLinksForGroup#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetBanList_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetBanList_Response]>>
   */
  public fun getBanList(request: CChatRoom_GetBanList_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetBanList_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetBanList_Response.Builder::class.java,
  "ChatRoom.GetBanList#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetInviteList_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetInviteList_Response]>>
   */
  public fun getInviteList(request: CChatRoom_GetInviteList_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetInviteList_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetInviteList_Response.Builder::class.java,
  "ChatRoom.GetInviteList#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_DeleteInviteLink_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_DeleteInviteLink_Response]>>
   */
  public fun deleteInviteLink(request: CChatRoom_DeleteInviteLink_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_DeleteInviteLink_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_DeleteInviteLink_Response.Builder::class.java,
  "ChatRoom.DeleteInviteLink#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetSessionActiveChatRoomGroups_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SetSessionActiveChatRoomGroups_Response]>>
   */
  public fun setSessionActiveChatRoomGroups(request: CChatRoom_SetSessionActiveChatRoomGroups_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SetSessionActiveChatRoomGroups_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SetSessionActiveChatRoomGroups_Response.Builder::class.java,
  "ChatRoom.SetSessionActiveChatRoomGroups#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_SetUserChatGroupPreferences_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SetUserChatGroupPreferences_Response]>>
   */
  public fun setUserChatGroupPreferences(request: CChatRoom_SetUserChatGroupPreferences_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SetUserChatGroupPreferences_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SetUserChatGroupPreferences_Response.Builder::class.java,
  "ChatRoom.SetUserChatGroupPreferences#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_DeleteChatMessages_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_DeleteChatMessages_Response]>>
   */
  public fun deleteChatMessages(request: CChatRoom_DeleteChatMessages_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_DeleteChatMessages_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_DeleteChatMessages_Response.Builder::class.java,
  "ChatRoom.DeleteChatMessages#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_UpdateMemberListView_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun updateMemberListView(request: CChatRoom_UpdateMemberListView_Notification) {
    unifiedMessages!!.sendNotification<CChatRoom_UpdateMemberListView_Notification.Builder>(
        "ChatRoom.UpdateMemberListView#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CChatRoom_SearchMembers_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_SearchMembers_Response]>>
   */
  public fun searchMembers(request: CChatRoom_SearchMembers_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_SearchMembers_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_SearchMembers_Response.Builder::class.java,
  "ChatRoom.SearchMembers#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_UpdateMessageReaction_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_UpdateMessageReaction_Response]>>
   */
  public fun updateMessageReaction(request: CChatRoom_UpdateMessageReaction_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_UpdateMessageReaction_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_UpdateMessageReaction_Response.Builder::class.java,
  "ChatRoom.UpdateMessageReaction#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_GetMessageReactionReactors_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_GetMessageReactionReactors_Response]>>
   */
  public fun getMessageReactionReactors(request: CChatRoom_GetMessageReactionReactors_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_GetMessageReactionReactors_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_GetMessageReactionReactors_Response.Builder::class.java,
  "ChatRoom.GetMessageReactionReactors#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_ReportMessage_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_ReportMessage_Response]>>
   */
  public fun reportMessage(request: CChatRoom_ReportMessage_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_ReportMessage_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_ReportMessage_Response.Builder::class.java,
  "ChatRoom.ReportMessage#1",
  request
  )

  /**
   * @param request The request.
   * @see [CChatRoom_ResolveReport_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CChatRoom_ResolveReport_Response]>>
   */
  public fun resolveReport(request: CChatRoom_ResolveReport_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesChatSteamclient.CChatRoom_ResolveReport_Response.Builder>> = unifiedMessages!!.sendMessage(
  CChatRoom_ResolveReport_Response.Builder::class.java,
  "ChatRoom.ResolveReport#1",
  request
  )
}
