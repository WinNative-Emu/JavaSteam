package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_GetTokenHistory_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_GetTokenHistory_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_MarkTokenCompromised_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_MarkTokenCompromised_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_QueryRefreshTokenByID_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_QueryRefreshTokenByID_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_QueryRefreshTokensByAccount_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_QueryRefreshTokensByAccount_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_RevokeToken_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesAuthSteamclient.CAuthenticationSupport_RevokeToken_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class AuthenticationSupport : UnifiedService {
  override val serviceName: String
    get() = "AuthenticationSupport"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "QueryRefreshTokensByAccount" -> postResponseMsg<CAuthenticationSupport_QueryRefreshTokensByAccount_Response.Builder>(
          CAuthenticationSupport_QueryRefreshTokensByAccount_Response::class.java,
          packetMsg
          )
      "QueryRefreshTokenByID" -> postResponseMsg<CAuthenticationSupport_QueryRefreshTokenByID_Response.Builder>(
          CAuthenticationSupport_QueryRefreshTokenByID_Response::class.java,
          packetMsg
          )
      "RevokeToken" -> postResponseMsg<CAuthenticationSupport_RevokeToken_Response.Builder>(
          CAuthenticationSupport_RevokeToken_Response::class.java,
          packetMsg
          )
      "GetTokenHistory" -> postResponseMsg<CAuthenticationSupport_GetTokenHistory_Response.Builder>(
          CAuthenticationSupport_GetTokenHistory_Response::class.java,
          packetMsg
          )
      "MarkTokenCompromised" -> postResponseMsg<CAuthenticationSupport_MarkTokenCompromised_Response.Builder>(
          CAuthenticationSupport_MarkTokenCompromised_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CAuthenticationSupport_QueryRefreshTokensByAccount_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthenticationSupport_QueryRefreshTokensByAccount_Response]>>
   */
  public fun queryRefreshTokensByAccount(request: CAuthenticationSupport_QueryRefreshTokensByAccount_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthenticationSupport_QueryRefreshTokensByAccount_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthenticationSupport_QueryRefreshTokensByAccount_Response.Builder::class.java,
  "AuthenticationSupport.QueryRefreshTokensByAccount#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthenticationSupport_QueryRefreshTokenByID_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthenticationSupport_QueryRefreshTokenByID_Response]>>
   */
  public fun queryRefreshTokenByID(request: CAuthenticationSupport_QueryRefreshTokenByID_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthenticationSupport_QueryRefreshTokenByID_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthenticationSupport_QueryRefreshTokenByID_Response.Builder::class.java,
  "AuthenticationSupport.QueryRefreshTokenByID#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthenticationSupport_RevokeToken_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthenticationSupport_RevokeToken_Response]>>
   */
  public fun revokeToken(request: CAuthenticationSupport_RevokeToken_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthenticationSupport_RevokeToken_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthenticationSupport_RevokeToken_Response.Builder::class.java,
  "AuthenticationSupport.RevokeToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthenticationSupport_GetTokenHistory_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthenticationSupport_GetTokenHistory_Response]>>
   */
  public fun getTokenHistory(request: CAuthenticationSupport_GetTokenHistory_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthenticationSupport_GetTokenHistory_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthenticationSupport_GetTokenHistory_Response.Builder::class.java,
  "AuthenticationSupport.GetTokenHistory#1",
  request
  )

  /**
   * @param request The request.
   * @see [CAuthenticationSupport_MarkTokenCompromised_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CAuthenticationSupport_MarkTokenCompromised_Response]>>
   */
  public fun markTokenCompromised(request: CAuthenticationSupport_MarkTokenCompromised_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesAuthSteamclient.CAuthenticationSupport_MarkTokenCompromised_Response.Builder>> = unifiedMessages!!.sendMessage(
  CAuthenticationSupport_MarkTokenCompromised_Response.Builder::class.java,
  "AuthenticationSupport.MarkTokenCompromised#1",
  request
  )
}
