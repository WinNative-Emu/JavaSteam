package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetCDNAuthToken_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetCDNAuthToken_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetClientUpdateHosts_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetClientUpdateHosts_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetDepotPatchInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetDepotPatchInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetManifestRequestCode_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetManifestRequestCode_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetPeerContentInfo_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetPeerContentInfo_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetServersForSteamPipe_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_GetServersForSteamPipe_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_RequestPeerContentServer_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesContentsystemSteamclient.CContentServerDirectory_RequestPeerContentServer_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ContentServerDirectory : UnifiedService {
  override val serviceName: String
    get() = "ContentServerDirectory"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetServersForSteamPipe" -> postResponseMsg<CContentServerDirectory_GetServersForSteamPipe_Response.Builder>(
          CContentServerDirectory_GetServersForSteamPipe_Response::class.java,
          packetMsg
          )
      "GetDepotPatchInfo" -> postResponseMsg<CContentServerDirectory_GetDepotPatchInfo_Response.Builder>(
          CContentServerDirectory_GetDepotPatchInfo_Response::class.java,
          packetMsg
          )
      "GetClientUpdateHosts" -> postResponseMsg<CContentServerDirectory_GetClientUpdateHosts_Response.Builder>(
          CContentServerDirectory_GetClientUpdateHosts_Response::class.java,
          packetMsg
          )
      "GetManifestRequestCode" -> postResponseMsg<CContentServerDirectory_GetManifestRequestCode_Response.Builder>(
          CContentServerDirectory_GetManifestRequestCode_Response::class.java,
          packetMsg
          )
      "GetCDNAuthToken" -> postResponseMsg<CContentServerDirectory_GetCDNAuthToken_Response.Builder>(
          CContentServerDirectory_GetCDNAuthToken_Response::class.java,
          packetMsg
          )
      "RequestPeerContentServer" -> postResponseMsg<CContentServerDirectory_RequestPeerContentServer_Response.Builder>(
          CContentServerDirectory_RequestPeerContentServer_Response::class.java,
          packetMsg
          )
      "GetPeerContentInfo" -> postResponseMsg<CContentServerDirectory_GetPeerContentInfo_Response.Builder>(
          CContentServerDirectory_GetPeerContentInfo_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CContentServerDirectory_GetServersForSteamPipe_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CContentServerDirectory_GetServersForSteamPipe_Response]>>
   */
  public fun getServersForSteamPipe(request: CContentServerDirectory_GetServersForSteamPipe_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CContentServerDirectory_GetServersForSteamPipe_Response.Builder>> = unifiedMessages!!.sendMessage(
  CContentServerDirectory_GetServersForSteamPipe_Response.Builder::class.java,
  "ContentServerDirectory.GetServersForSteamPipe#1",
  request
  )

  /**
   * @param request The request.
   * @see [CContentServerDirectory_GetDepotPatchInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CContentServerDirectory_GetDepotPatchInfo_Response]>>
   */
  public fun getDepotPatchInfo(request: CContentServerDirectory_GetDepotPatchInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CContentServerDirectory_GetDepotPatchInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CContentServerDirectory_GetDepotPatchInfo_Response.Builder::class.java,
  "ContentServerDirectory.GetDepotPatchInfo#1",
  request
  )

  /**
   * @param request The request.
   * @see [CContentServerDirectory_GetClientUpdateHosts_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CContentServerDirectory_GetClientUpdateHosts_Response]>>
   */
  public fun getClientUpdateHosts(request: CContentServerDirectory_GetClientUpdateHosts_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CContentServerDirectory_GetClientUpdateHosts_Response.Builder>> = unifiedMessages!!.sendMessage(
  CContentServerDirectory_GetClientUpdateHosts_Response.Builder::class.java,
  "ContentServerDirectory.GetClientUpdateHosts#1",
  request
  )

  /**
   * @param request The request.
   * @see [CContentServerDirectory_GetManifestRequestCode_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CContentServerDirectory_GetManifestRequestCode_Response]>>
   */
  public fun getManifestRequestCode(request: CContentServerDirectory_GetManifestRequestCode_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CContentServerDirectory_GetManifestRequestCode_Response.Builder>> = unifiedMessages!!.sendMessage(
  CContentServerDirectory_GetManifestRequestCode_Response.Builder::class.java,
  "ContentServerDirectory.GetManifestRequestCode#1",
  request
  )

  /**
   * @param request The request.
   * @see [CContentServerDirectory_GetCDNAuthToken_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CContentServerDirectory_GetCDNAuthToken_Response]>>
   */
  public fun getCDNAuthToken(request: CContentServerDirectory_GetCDNAuthToken_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CContentServerDirectory_GetCDNAuthToken_Response.Builder>> = unifiedMessages!!.sendMessage(
  CContentServerDirectory_GetCDNAuthToken_Response.Builder::class.java,
  "ContentServerDirectory.GetCDNAuthToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CContentServerDirectory_RequestPeerContentServer_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CContentServerDirectory_RequestPeerContentServer_Response]>>
   */
  public fun requestPeerContentServer(request: CContentServerDirectory_RequestPeerContentServer_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CContentServerDirectory_RequestPeerContentServer_Response.Builder>> = unifiedMessages!!.sendMessage(
  CContentServerDirectory_RequestPeerContentServer_Response.Builder::class.java,
  "ContentServerDirectory.RequestPeerContentServer#1",
  request
  )

  /**
   * @param request The request.
   * @see [CContentServerDirectory_GetPeerContentInfo_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CContentServerDirectory_GetPeerContentInfo_Response]>>
   */
  public fun getPeerContentInfo(request: CContentServerDirectory_GetPeerContentInfo_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesContentsystemSteamclient.CContentServerDirectory_GetPeerContentInfo_Response.Builder>> = unifiedMessages!!.sendMessage(
  CContentServerDirectory_GetPeerContentInfo_Response.Builder::class.java,
  "ContentServerDirectory.GetPeerContentInfo#1",
  request
  )
}
