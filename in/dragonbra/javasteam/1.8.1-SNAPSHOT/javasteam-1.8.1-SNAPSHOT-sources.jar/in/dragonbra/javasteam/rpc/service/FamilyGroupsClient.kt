package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroupsClient_GroupChanged_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroupsClient_InviteStatus_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesFamilygroupsSteamclient.CFamilyGroupsClient_NotifyRunningApps_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class FamilyGroupsClient : UnifiedService {
  override val serviceName: String
    get() = "FamilyGroupsClient"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "NotifyRunningApps" -> postNotificationMsg<CFamilyGroupsClient_NotifyRunningApps_Notification.Builder>(
          CFamilyGroupsClient_NotifyRunningApps_Notification::class.java,
          packetMsg
          )
      "NotifyInviteStatus" -> postNotificationMsg<CFamilyGroupsClient_InviteStatus_Notification.Builder>(
          CFamilyGroupsClient_InviteStatus_Notification::class.java,
          packetMsg
          )
      "NotifyGroupChanged" -> postNotificationMsg<CFamilyGroupsClient_GroupChanged_Notification.Builder>(
          CFamilyGroupsClient_GroupChanged_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CFamilyGroupsClient_NotifyRunningApps_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyRunningApps(request: CFamilyGroupsClient_NotifyRunningApps_Notification) {
    unifiedMessages!!.sendNotification<CFamilyGroupsClient_NotifyRunningApps_Notification.Builder>(
        "FamilyGroupsClient.NotifyRunningApps#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CFamilyGroupsClient_InviteStatus_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyInviteStatus(request: CFamilyGroupsClient_InviteStatus_Notification) {
    unifiedMessages!!.sendNotification<CFamilyGroupsClient_InviteStatus_Notification.Builder>(
        "FamilyGroupsClient.NotifyInviteStatus#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CFamilyGroupsClient_GroupChanged_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun notifyGroupChanged(request: CFamilyGroupsClient_GroupChanged_Notification) {
    unifiedMessages!!.sendNotification<CFamilyGroupsClient_GroupChanged_Notification.Builder>(
        "FamilyGroupsClient.NotifyGroupChanged#1",
        request
        )
  }
}
