package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_AddAuthenticator_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_AddAuthenticator_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_FinalizeAddAuthenticator_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_FinalizeAddAuthenticator_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticatorViaChallengeStart_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticatorViaChallengeStart_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticator_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticator_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_Status_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_Status_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_Time_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_Time_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_UpdateTokenVersion_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesTwofactorSteamclient.CTwoFactor_UpdateTokenVersion_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class TwoFactor : UnifiedService {
  override val serviceName: String
    get() = "TwoFactor"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "QueryTime" -> postResponseMsg<CTwoFactor_Time_Response.Builder>(
          CTwoFactor_Time_Response::class.java,
          packetMsg
          )
      "QueryStatus" -> postResponseMsg<CTwoFactor_Status_Response.Builder>(
          CTwoFactor_Status_Response::class.java,
          packetMsg
          )
      "AddAuthenticator" -> postResponseMsg<CTwoFactor_AddAuthenticator_Response.Builder>(
          CTwoFactor_AddAuthenticator_Response::class.java,
          packetMsg
          )
      "FinalizeAddAuthenticator" -> postResponseMsg<CTwoFactor_FinalizeAddAuthenticator_Response.Builder>(
          CTwoFactor_FinalizeAddAuthenticator_Response::class.java,
          packetMsg
          )
      "UpdateTokenVersion" -> postResponseMsg<CTwoFactor_UpdateTokenVersion_Response.Builder>(
          CTwoFactor_UpdateTokenVersion_Response::class.java,
          packetMsg
          )
      "RemoveAuthenticator" -> postResponseMsg<CTwoFactor_RemoveAuthenticator_Response.Builder>(
          CTwoFactor_RemoveAuthenticator_Response::class.java,
          packetMsg
          )
      "RemoveAuthenticatorViaChallengeStart" -> postResponseMsg<CTwoFactor_RemoveAuthenticatorViaChallengeStart_Response.Builder>(
          CTwoFactor_RemoveAuthenticatorViaChallengeStart_Response::class.java,
          packetMsg
          )
      "RemoveAuthenticatorViaChallengeContinue" -> postResponseMsg<CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Response.Builder>(
          CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CTwoFactor_Time_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_Time_Response]>>
   */
  public fun queryTime(request: CTwoFactor_Time_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_Time_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_Time_Response.Builder::class.java,
  "TwoFactor.QueryTime#1",
  request
  )

  /**
   * @param request The request.
   * @see [CTwoFactor_Status_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_Status_Response]>>
   */
  public fun queryStatus(request: CTwoFactor_Status_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_Status_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_Status_Response.Builder::class.java,
  "TwoFactor.QueryStatus#1",
  request
  )

  /**
   * @param request The request.
   * @see [CTwoFactor_AddAuthenticator_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_AddAuthenticator_Response]>>
   */
  public fun addAuthenticator(request: CTwoFactor_AddAuthenticator_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_AddAuthenticator_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_AddAuthenticator_Response.Builder::class.java,
  "TwoFactor.AddAuthenticator#1",
  request
  )

  /**
   * @param request The request.
   * @see [CTwoFactor_FinalizeAddAuthenticator_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_FinalizeAddAuthenticator_Response]>>
   */
  public fun finalizeAddAuthenticator(request: CTwoFactor_FinalizeAddAuthenticator_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_FinalizeAddAuthenticator_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_FinalizeAddAuthenticator_Response.Builder::class.java,
  "TwoFactor.FinalizeAddAuthenticator#1",
  request
  )

  /**
   * @param request The request.
   * @see [CTwoFactor_UpdateTokenVersion_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_UpdateTokenVersion_Response]>>
   */
  public fun updateTokenVersion(request: CTwoFactor_UpdateTokenVersion_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_UpdateTokenVersion_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_UpdateTokenVersion_Response.Builder::class.java,
  "TwoFactor.UpdateTokenVersion#1",
  request
  )

  /**
   * @param request The request.
   * @see [CTwoFactor_RemoveAuthenticator_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_RemoveAuthenticator_Response]>>
   */
  public fun removeAuthenticator(request: CTwoFactor_RemoveAuthenticator_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticator_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_RemoveAuthenticator_Response.Builder::class.java,
  "TwoFactor.RemoveAuthenticator#1",
  request
  )

  /**
   * @param request The request.
   * @see [CTwoFactor_RemoveAuthenticatorViaChallengeStart_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_RemoveAuthenticatorViaChallengeStart_Response]>>
   */
  public fun removeAuthenticatorViaChallengeStart(request: CTwoFactor_RemoveAuthenticatorViaChallengeStart_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticatorViaChallengeStart_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_RemoveAuthenticatorViaChallengeStart_Response.Builder::class.java,
  "TwoFactor.RemoveAuthenticatorViaChallengeStart#1",
  request
  )

  /**
   * @param request The request.
   * @see [CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Response]>>
   */
  public fun removeAuthenticatorViaChallengeContinue(request: CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesTwofactorSteamclient.CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Response.Builder>> = unifiedMessages!!.sendMessage(
  CTwoFactor_RemoveAuthenticatorViaChallengeContinue_Response.Builder::class.java,
  "TwoFactor.RemoveAuthenticatorViaChallengeContinue#1",
  request
  )
}
