package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_AppInterfaceStats_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ClientBootstrap_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ClipRange_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ClipShare_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_CloudAppSyncStats_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ContentDownloadResponse_Counts_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ContentValidation_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_DownloadRates_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_EndGameRecording_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_GamePerformance_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_IPv6Connectivity_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ReportAccessibilitySettings_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ReportClientArgs_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ReportClientError_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ReportLinuxStats_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_ReportReactUsage_Notification
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesClientmetricsSteamclient.CClientMetrics_SteamPipeWorkStats_Notification
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class ClientMetrics : UnifiedService {
  override val serviceName: String
    get() = "ClientMetrics"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "ClientAppInterfaceStatsReport" -> postNotificationMsg<CClientMetrics_AppInterfaceStats_Notification.Builder>(
          CClientMetrics_AppInterfaceStats_Notification::class.java,
          packetMsg
          )
      "ClientIPv6ConnectivityReport" -> postNotificationMsg<CClientMetrics_IPv6Connectivity_Notification.Builder>(
          CClientMetrics_IPv6Connectivity_Notification::class.java,
          packetMsg
          )
      "SteamPipeWorkStatsReport" -> postNotificationMsg<CClientMetrics_SteamPipeWorkStats_Notification.Builder>(
          CClientMetrics_SteamPipeWorkStats_Notification::class.java,
          packetMsg
          )
      "ReportReactUsage" -> postNotificationMsg<CClientMetrics_ReportReactUsage_Notification.Builder>(
          CClientMetrics_ReportReactUsage_Notification::class.java,
          packetMsg
          )
      "ReportClientError" -> postNotificationMsg<CClientMetrics_ReportClientError_Notification.Builder>(
          CClientMetrics_ReportClientError_Notification::class.java,
          packetMsg
          )
      "ClientBootstrapReport" -> postNotificationMsg<CClientMetrics_ClientBootstrap_Notification.Builder>(
          CClientMetrics_ClientBootstrap_Notification::class.java,
          packetMsg
          )
      "ClientDownloadRatesReport" -> postNotificationMsg<CClientMetrics_DownloadRates_Notification.Builder>(
          CClientMetrics_DownloadRates_Notification::class.java,
          packetMsg
          )
      "ClientContentValidationReport" -> postNotificationMsg<CClientMetrics_ContentValidation_Notification.Builder>(
          CClientMetrics_ContentValidation_Notification::class.java,
          packetMsg
          )
      "ClientCloudAppSyncStats" -> postNotificationMsg<CClientMetrics_CloudAppSyncStats_Notification.Builder>(
          CClientMetrics_CloudAppSyncStats_Notification::class.java,
          packetMsg
          )
      "ClientDownloadResponseCodeCounts" -> postNotificationMsg<CClientMetrics_ContentDownloadResponse_Counts_Notification.Builder>(
          CClientMetrics_ContentDownloadResponse_Counts_Notification::class.java,
          packetMsg
          )
      "ReportClientArgs" -> postNotificationMsg<CClientMetrics_ReportClientArgs_Notification.Builder>(
          CClientMetrics_ReportClientArgs_Notification::class.java,
          packetMsg
          )
      "ReportLinuxStats" -> postNotificationMsg<CClientMetrics_ReportLinuxStats_Notification.Builder>(
          CClientMetrics_ReportLinuxStats_Notification::class.java,
          packetMsg
          )
      "ReportAccessibilitySettings" -> postNotificationMsg<CClientMetrics_ReportAccessibilitySettings_Notification.Builder>(
          CClientMetrics_ReportAccessibilitySettings_Notification::class.java,
          packetMsg
          )
      "ReportClipShare" -> postNotificationMsg<CClientMetrics_ClipShare_Notification.Builder>(
          CClientMetrics_ClipShare_Notification::class.java,
          packetMsg
          )
      "ReportClipRange" -> postNotificationMsg<CClientMetrics_ClipRange_Notification.Builder>(
          CClientMetrics_ClipRange_Notification::class.java,
          packetMsg
          )
      "ReportEndGameRecording" -> postNotificationMsg<CClientMetrics_EndGameRecording_Notification.Builder>(
          CClientMetrics_EndGameRecording_Notification::class.java,
          packetMsg
          )
      "ReportGamePerformance" -> postNotificationMsg<CClientMetrics_GamePerformance_Notification.Builder>(
          CClientMetrics_GamePerformance_Notification::class.java,
          packetMsg
          )
    }
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_AppInterfaceStats_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientAppInterfaceStatsReport(request: CClientMetrics_AppInterfaceStats_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_AppInterfaceStats_Notification.Builder>(
        "ClientMetrics.ClientAppInterfaceStatsReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_IPv6Connectivity_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientIPv6ConnectivityReport(request: CClientMetrics_IPv6Connectivity_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_IPv6Connectivity_Notification.Builder>(
        "ClientMetrics.ClientIPv6ConnectivityReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_SteamPipeWorkStats_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun steamPipeWorkStatsReport(request: CClientMetrics_SteamPipeWorkStats_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_SteamPipeWorkStats_Notification.Builder>(
        "ClientMetrics.SteamPipeWorkStatsReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ReportReactUsage_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportReactUsage(request: CClientMetrics_ReportReactUsage_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ReportReactUsage_Notification.Builder>(
        "ClientMetrics.ReportReactUsage#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ReportClientError_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportClientError(request: CClientMetrics_ReportClientError_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ReportClientError_Notification.Builder>(
        "ClientMetrics.ReportClientError#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ClientBootstrap_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientBootstrapReport(request: CClientMetrics_ClientBootstrap_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ClientBootstrap_Notification.Builder>(
        "ClientMetrics.ClientBootstrapReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_DownloadRates_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientDownloadRatesReport(request: CClientMetrics_DownloadRates_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_DownloadRates_Notification.Builder>(
        "ClientMetrics.ClientDownloadRatesReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ContentValidation_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientContentValidationReport(request: CClientMetrics_ContentValidation_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ContentValidation_Notification.Builder>(
        "ClientMetrics.ClientContentValidationReport#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_CloudAppSyncStats_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientCloudAppSyncStats(request: CClientMetrics_CloudAppSyncStats_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_CloudAppSyncStats_Notification.Builder>(
        "ClientMetrics.ClientCloudAppSyncStats#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ContentDownloadResponse_Counts_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun clientDownloadResponseCodeCounts(request: CClientMetrics_ContentDownloadResponse_Counts_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ContentDownloadResponse_Counts_Notification.Builder>(
        "ClientMetrics.ClientDownloadResponseCodeCounts#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ReportClientArgs_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportClientArgs(request: CClientMetrics_ReportClientArgs_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ReportClientArgs_Notification.Builder>(
        "ClientMetrics.ReportClientArgs#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ReportLinuxStats_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportLinuxStats(request: CClientMetrics_ReportLinuxStats_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ReportLinuxStats_Notification.Builder>(
        "ClientMetrics.ReportLinuxStats#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ReportAccessibilitySettings_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportAccessibilitySettings(request: CClientMetrics_ReportAccessibilitySettings_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ReportAccessibilitySettings_Notification.Builder>(
        "ClientMetrics.ReportAccessibilitySettings#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ClipShare_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportClipShare(request: CClientMetrics_ClipShare_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ClipShare_Notification.Builder>(
        "ClientMetrics.ReportClipShare#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_ClipRange_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportClipRange(request: CClientMetrics_ClipRange_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_ClipRange_Notification.Builder>(
        "ClientMetrics.ReportClipRange#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_EndGameRecording_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportEndGameRecording(request: CClientMetrics_EndGameRecording_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_EndGameRecording_Notification.Builder>(
        "ClientMetrics.ReportEndGameRecording#1",
        request
        )
  }

  /**
   * @param request The request.
   * @see [CClientMetrics_GamePerformance_Notification]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[NoResponse]>>
   */
  public fun reportGamePerformance(request: CClientMetrics_GamePerformance_Notification) {
    unifiedMessages!!.sendNotification<CClientMetrics_GamePerformance_Notification.Builder>(
        "ClientMetrics.ReportGamePerformance#1",
        request
        )
  }
}
