package `in`.dragonbra.javasteam.rpc.service

import `in`.dragonbra.javasteam.base.PacketClientMsgProtobuf
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_CancelLicenseForApp_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_CancelLicenseForApp_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_CreateFriendInviteToken_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_CreateFriendInviteToken_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetAccountLinkStatus_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetAccountLinkStatus_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetAvailableValveDiscountPromotions_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetAvailableValveDiscountPromotions_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetClientWalletDetails_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetFriendInviteTokens_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetFriendInviteTokens_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetUserCountry_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetUserCountry_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_GetWalletDetails_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_RedeemFriendInviteToken_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_RedeemFriendInviteToken_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_RegisterCompatTool_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_RegisterCompatTool_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_RevokeFriendInviteToken_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_RevokeFriendInviteToken_Response
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_ViewFriendInviteToken_Request
import `in`.dragonbra.javasteam.protobufs.steamclient.SteammessagesUseraccountSteamclient.CUserAccount_ViewFriendInviteToken_Response
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.SteamUnifiedMessages
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.UnifiedService
import `in`.dragonbra.javasteam.steam.handlers.steamunifiedmessages.callback.ServiceMethodResponse
import `in`.dragonbra.javasteam.types.AsyncJobSingle
import kotlin.String
import kotlin.Suppress

/**
 * This class is auto-generated
 */
@Suppress(
  "KDocUnresolvedReference",
  "RemoveRedundantQualifierName",
  "RedundantVisibilityModifier",
  "unused",
)
public class UserAccount : UnifiedService {
  override val serviceName: String
    get() = "UserAccount"

  public constructor(unifiedMessages: SteamUnifiedMessages) : super(unifiedMessages)

  override fun handleResponseMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
    when (methodName) {
      "GetAvailableValveDiscountPromotions" -> postResponseMsg<CUserAccount_GetAvailableValveDiscountPromotions_Response.Builder>(
          CUserAccount_GetAvailableValveDiscountPromotions_Response::class.java,
          packetMsg
          )
      "GetClientWalletDetails" -> postResponseMsg<CUserAccount_GetWalletDetails_Response.Builder>(
          CUserAccount_GetWalletDetails_Response::class.java,
          packetMsg
          )
      "GetAccountLinkStatus" -> postResponseMsg<CUserAccount_GetAccountLinkStatus_Response.Builder>(
          CUserAccount_GetAccountLinkStatus_Response::class.java,
          packetMsg
          )
      "CancelLicenseForApp" -> postResponseMsg<CUserAccount_CancelLicenseForApp_Response.Builder>(
          CUserAccount_CancelLicenseForApp_Response::class.java,
          packetMsg
          )
      "GetUserCountry" -> postResponseMsg<CUserAccount_GetUserCountry_Response.Builder>(
          CUserAccount_GetUserCountry_Response::class.java,
          packetMsg
          )
      "CreateFriendInviteToken" -> postResponseMsg<CUserAccount_CreateFriendInviteToken_Response.Builder>(
          CUserAccount_CreateFriendInviteToken_Response::class.java,
          packetMsg
          )
      "GetFriendInviteTokens" -> postResponseMsg<CUserAccount_GetFriendInviteTokens_Response.Builder>(
          CUserAccount_GetFriendInviteTokens_Response::class.java,
          packetMsg
          )
      "ViewFriendInviteToken" -> postResponseMsg<CUserAccount_ViewFriendInviteToken_Response.Builder>(
          CUserAccount_ViewFriendInviteToken_Response::class.java,
          packetMsg
          )
      "RedeemFriendInviteToken" -> postResponseMsg<CUserAccount_RedeemFriendInviteToken_Response.Builder>(
          CUserAccount_RedeemFriendInviteToken_Response::class.java,
          packetMsg
          )
      "RevokeFriendInviteToken" -> postResponseMsg<CUserAccount_RevokeFriendInviteToken_Response.Builder>(
          CUserAccount_RevokeFriendInviteToken_Response::class.java,
          packetMsg
          )
      "RegisterCompatTool" -> postResponseMsg<CUserAccount_RegisterCompatTool_Response.Builder>(
          CUserAccount_RegisterCompatTool_Response::class.java,
          packetMsg
          )
    }
  }

  override fun handleNotificationMsg(methodName: String, packetMsg: PacketClientMsgProtobuf) {
  }

  /**
   * @param request The request.
   * @see [CUserAccount_GetAvailableValveDiscountPromotions_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_GetAvailableValveDiscountPromotions_Response]>>
   */
  public fun getAvailableValveDiscountPromotions(request: CUserAccount_GetAvailableValveDiscountPromotions_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_GetAvailableValveDiscountPromotions_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_GetAvailableValveDiscountPromotions_Response.Builder::class.java,
  "UserAccount.GetAvailableValveDiscountPromotions#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_GetClientWalletDetails_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_GetWalletDetails_Response]>>
   */
  public fun getClientWalletDetails(request: CUserAccount_GetClientWalletDetails_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_GetWalletDetails_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_GetWalletDetails_Response.Builder::class.java,
  "UserAccount.GetClientWalletDetails#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_GetAccountLinkStatus_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_GetAccountLinkStatus_Response]>>
   */
  public fun getAccountLinkStatus(request: CUserAccount_GetAccountLinkStatus_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_GetAccountLinkStatus_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_GetAccountLinkStatus_Response.Builder::class.java,
  "UserAccount.GetAccountLinkStatus#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_CancelLicenseForApp_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_CancelLicenseForApp_Response]>>
   */
  public fun cancelLicenseForApp(request: CUserAccount_CancelLicenseForApp_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_CancelLicenseForApp_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_CancelLicenseForApp_Response.Builder::class.java,
  "UserAccount.CancelLicenseForApp#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_GetUserCountry_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_GetUserCountry_Response]>>
   */
  public fun getUserCountry(request: CUserAccount_GetUserCountry_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_GetUserCountry_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_GetUserCountry_Response.Builder::class.java,
  "UserAccount.GetUserCountry#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_CreateFriendInviteToken_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_CreateFriendInviteToken_Response]>>
   */
  public fun createFriendInviteToken(request: CUserAccount_CreateFriendInviteToken_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_CreateFriendInviteToken_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_CreateFriendInviteToken_Response.Builder::class.java,
  "UserAccount.CreateFriendInviteToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_GetFriendInviteTokens_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_GetFriendInviteTokens_Response]>>
   */
  public fun getFriendInviteTokens(request: CUserAccount_GetFriendInviteTokens_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_GetFriendInviteTokens_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_GetFriendInviteTokens_Response.Builder::class.java,
  "UserAccount.GetFriendInviteTokens#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_ViewFriendInviteToken_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_ViewFriendInviteToken_Response]>>
   */
  public fun viewFriendInviteToken(request: CUserAccount_ViewFriendInviteToken_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_ViewFriendInviteToken_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_ViewFriendInviteToken_Response.Builder::class.java,
  "UserAccount.ViewFriendInviteToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_RedeemFriendInviteToken_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_RedeemFriendInviteToken_Response]>>
   */
  public fun redeemFriendInviteToken(request: CUserAccount_RedeemFriendInviteToken_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_RedeemFriendInviteToken_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_RedeemFriendInviteToken_Response.Builder::class.java,
  "UserAccount.RedeemFriendInviteToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_RevokeFriendInviteToken_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_RevokeFriendInviteToken_Response]>>
   */
  public fun revokeFriendInviteToken(request: CUserAccount_RevokeFriendInviteToken_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_RevokeFriendInviteToken_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_RevokeFriendInviteToken_Response.Builder::class.java,
  "UserAccount.RevokeFriendInviteToken#1",
  request
  )

  /**
   * @param request The request.
   * @see [CUserAccount_RegisterCompatTool_Request]
   * @returns [AsyncJobSingle]<[ServiceMethodResponse]<[CUserAccount_RegisterCompatTool_Response]>>
   */
  public fun registerCompatTool(request: CUserAccount_RegisterCompatTool_Request): AsyncJobSingle<ServiceMethodResponse<SteammessagesUseraccountSteamclient.CUserAccount_RegisterCompatTool_Response.Builder>> = unifiedMessages!!.sendMessage(
  CUserAccount_RegisterCompatTool_Response.Builder::class.java,
  "UserAccount.RegisterCompatTool#1",
  request
  )
}
